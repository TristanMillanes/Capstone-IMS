/* Fixed emerald surroundings and light forms. No stored or system appearance settings. */
(() => {
  'use strict';
  let leaving=false;
  let exitAnimation=null;
  const canAnimate = () => !matchMedia('(prefers-reduced-motion: reduce)').matches && !navigator.connection?.saveData;
  function restorePage() {
    leaving=false;
    exitAnimation?.cancel();
    exitAnimation=null;
    document.body.dataset.routeMotion='ready';
  }
  async function navigate(destination) {
    if(leaving)return;
    leaving=true;
    const viewport=document.querySelector('.portal-viewport');
    if(canAnimate()&&viewport?.animate){
      document.body.dataset.routeMotion='leaving';
      exitAnimation=viewport.animate([{opacity:1,transform:'translateY(0)'},{opacity:0,transform:'translateY(-8px)'}],{duration:170,easing:'ease-in',fill:'forwards'});
      try{await exitAnimation.finished;}catch{}
    }
    window.location.assign(destination);
    // Restore the old document if a navigation is cancelled or fails to leave it.
    setTimeout(()=>{if(!document.hidden)restorePage();},1800);
  }
  function init() {
    const protectedPasswords=[...document.querySelectorAll('input[data-empty-on-open]')];
    function clearPassword(field) {
      field.value='';field.defaultValue='';field.type='password';field.readOnly=true;
      field.setAttribute('aria-invalid','false');field.classList.remove('invalid-field');
      field.closest('.input-box')?.classList.remove('invalid');
      const error=document.getElementById(field.id+'Error');if(error)error.textContent='';
      const button=document.querySelector(`button[aria-controls="${field.id}"]`);
      if(button){
        button.setAttribute('aria-pressed','false');button.setAttribute('aria-label','Show password');
        const use=button.querySelector('use');
        if(use)use.setAttribute('href','#icon-eye');
        else {const svg=button.querySelector('svg');if(svg)svg.innerHTML='<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/>';}
      }
      field.dispatchEvent(new CustomEvent('portal:password-cleared',{bubbles:true}));
    }
    protectedPasswords.forEach(field=>{
      clearPassword(field);
      const unlock=()=>{
        if(field.readOnly){field.value='';field.defaultValue='';field.readOnly=false;}
      };
      field.addEventListener('focus',unlock);
      field.addEventListener('pointerdown',unlock);
      field.addEventListener('keydown',unlock);
      field.addEventListener('input',()=>{if(field.readOnly&&field.value)clearPassword(field);});
    });
    const forms=new Set(protectedPasswords.map(field=>field.form).filter(Boolean));
    forms.forEach(form=>form.addEventListener('reset',()=>queueMicrotask(()=>protectedPasswords.filter(field=>field.form===form).forEach(clearPassword))));
    window.addEventListener('pagehide',()=>protectedPasswords.forEach(clearPassword));
    window.addEventListener('pageshow',event=>{
      restorePage();
      protectedPasswords.filter(field=>event.persisted||field.readOnly).forEach(clearPassword);
      if(event.persisted&&canAnimate())document.querySelector('.portal-viewport')?.animate([{opacity:0,transform:'translateY(6px)'},{opacity:1,transform:'translateY(0)'}],{duration:280,easing:'ease-out'});
    });
    document.addEventListener('click',event=>{
      const link=event.target instanceof Element?event.target.closest('a[href]'):null;
      if(!link||event.defaultPrevented||event.button!==0||event.metaKey||event.ctrlKey||event.shiftKey||event.altKey||link.download||link.target&&link.target!=='_self')return;
      const url=new URL(link.href,location.href);
      if(!['http:','https:','file:'].includes(url.protocol)||url.origin!==location.origin||url.pathname===location.pathname&&url.search===location.search)return;
      if(!canAnimate()||document.querySelector('form[aria-busy="true"]'))return;
      event.preventDefault();void navigate(url.href);
    });
    document.querySelectorAll('[data-brand-seal]').forEach(image => {
      const loaded = () => { image.hidden = !image.naturalWidth; };
      image.addEventListener('load', loaded);
      image.addEventListener('error', () => { image.hidden = true; });
      if (image.complete) loaded();
    });
    const reduced = matchMedia('(prefers-reduced-motion: reduce)');
    const connection = navigator.connection;
    const syncMotion = () => {
      document.body.dataset.sceneMotion = document.hidden || reduced.matches || connection?.saveData ? 'paused' : 'running';
    };
    reduced.addEventListener?.('change',syncMotion);
    connection?.addEventListener?.('change',syncMotion);
    document.addEventListener('visibilitychange',syncMotion);
    window.addEventListener('pageshow',syncMotion);
    syncMotion();
  }
  const normalizePhone = value => {
    const digits = String(value || '').replace(/\D/g, '');
    if (/^639\d{9}$/.test(digits)) return '0' + digits.slice(2);
    if (/^9\d{9}$/.test(digits)) return '0' + digits;
    return digits;
  };
  async function timedFetch(input, options = {}) {
    const controller = new AbortController();
    const upstream = options.signal || (input instanceof Request ? input.signal : null);
    const abort = () => controller.abort(upstream?.reason);
    if (upstream?.aborted) abort();
    else upstream?.addEventListener('abort', abort, {once:true});
    const timer = setTimeout(() => controller.abort(new DOMException('Request timed out','TimeoutError')), 20000);
    try { return await fetch(input, {...options, signal:controller.signal}); }
    finally { clearTimeout(timer); upstream?.removeEventListener('abort', abort); }
  }
  const uuid = () => {
    if (crypto.randomUUID) return crypto.randomUUID();
    const bytes = crypto.getRandomValues(new Uint8Array(16));
    bytes[6] = (bytes[6] & 15) | 64; bytes[8] = (bytes[8] & 63) | 128;
    const hex = [...bytes].map(byte => byte.toString(16).padStart(2,'0')).join('');
    return `${hex.slice(0,8)}-${hex.slice(8,12)}-${hex.slice(12,16)}-${hex.slice(16,20)}-${hex.slice(20)}`;
  };
  window.PortalUI = Object.freeze({normalizePhone, timedFetch, uuid, navigate});
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, {once:true});
  else init();
})();

/* Visual feedback follows the existing async state; it never submits a form. */
(() => {
  'use strict';
  if(window.PGENRO_ButtonFeedback)return;
  window.PGENRO_ButtonFeedback=true;
  function init(){
    const submitFor={loginForm:'loginBtn',accessForm:'submitBtn',publicServiceRequestForm:'submitServiceRequestBtn',visitorForm:'submitBtn'};
    Object.entries(submitFor).forEach(([formId,buttonId])=>{
      const form=document.getElementById(formId),button=document.getElementById(buttonId);if(!form||!button)return;
      const status=document.createElement('p');status.className='sr-only ui-async-status';status.setAttribute('role','status');status.setAttribute('aria-live','polite');status.setAttribute('aria-atomic','true');form.after(status);
      const labels={loginForm:'Signing in. Please wait.',accessForm:'Sending your account request. Please wait.',publicServiceRequestForm:'Sending your service request. Please wait.',visitorForm:'Saving your visit. Please wait.'};
      const sync=()=>{const busy=form.getAttribute('aria-busy')==='true';button.setAttribute('aria-busy',String(busy));button.classList.toggle('ui-button-busy',busy);status.textContent=busy?labels[formId]:'';};
      sync();new MutationObserver(sync).observe(form,{attributes:true,attributeFilter:['aria-busy']});
    });
    if(document.body.dataset.recordAccess==='view-only'){
      document.querySelectorAll('#refreshDashboardBtn,#refreshRecordsBtn,#refreshBtn,#travelRefresh').forEach(button=>{
        let previous='';
        const sync=()=>{const busy=button.disabled||button.classList.contains('is-loading'),key=String(busy);if(key===previous)return;previous=key;button.setAttribute('aria-busy',key);button.classList.toggle('ui-button-busy',busy);};
        sync();new MutationObserver(sync).observe(button,{attributes:true,attributeFilter:['disabled','class']});
      });
    }
    const eligible='.primary-sign-btn,.submit-btn,.btn-solid,.primary-action,.secondary-action,.btn-outline,.refresh-btn,.secondary-btn';
    document.addEventListener('pointerdown',event=>{
      const button=event.target.closest('button');if(!button||!button.matches(eligible)||button.disabled||event.button!==0||matchMedia('(prefers-reduced-motion: reduce)').matches)return;
      const r=button.getBoundingClientRect(),wave=document.createElement('span');wave.className='ui-tap-wave';wave.setAttribute('aria-hidden','true');
      wave.style.setProperty('--tap-x',event.clientX-r.left+'px');wave.style.setProperty('--tap-y',event.clientY-r.top+'px');wave.style.setProperty('--tap-size',Math.max(r.width,r.height)*2+'px');
      button.append(wave);wave.addEventListener('animationend',()=>wave.remove(),{once:true});setTimeout(()=>wave.remove(),700);
    },true);
    document.body.dataset.buttonFeedbackReady='true';
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})();

/* Public account request. Auth metadata keys match the original database trigger. */
(() => {
  'use strict';
  const init = () => {
    const $ = id => document.getElementById(id);
    const form = $('accessForm');
    if (!form) return;
    const ui = window.PortalUI;
    const CONFIG = {url:'https://zssrxubajhqryrwijyzm.supabase.co',key:'sb_publishable_5RWFfJ5oN6ike6SSyafajw_yF9DYApP'};
    let db = null;
    try {
      if (window.supabase?.createClient) db = window.supabase.createClient(CONFIG.url,CONFIG.key,{
        auth:{persistSession:false,autoRefreshToken:false,detectSessionInUrl:false},
        global:{fetch:ui.timedFetch}
      });
    } catch { /* Show an actionable error only if a submission is attempted. */ }
    // This public page must not replace a signed-in staff session with a pending applicant.
    const fields = [...form.querySelectorAll('input,select,textarea')];
    const pages = [1,2,3].map(i => $('page'+i));
    const steps = [...document.querySelectorAll('[data-step]')];
    const draftKey = 'pgenro_applicant_draft_v2';
    const draftFields = ['fullName','email','contact','position','division','role','endorser','reason'];
    let page = 1, saving = false, draftTimer, draftCleared = false;
    const reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
    const icons = {
    leaf: '<path d="M20 3C11 3 4 7 4 14a6 6 0 0 0 6 6c7 0 10-8 10-17Zm-17 18L15 9"/>',
    user: '<circle cx="12" cy="7" r="4"/><path d="M4 21v-2a8 8 0 0 1 16 0v2"/>',
    'user-check': '<circle cx="9" cy="7" r="4"/><path d="M2 21v-2a7 7 0 0 1 12-4.9m2 .9 3 3 5-6"/>',
    mail: '<rect x="3" y="5" width="18" height="14" rx="3"/><path d="m3 7 9 6 9-6"/>',
    phone: '<path d="M22 16.9v3a2 2 0 0 1-2.2 2A19.8 19.8 0 0 1 3.1 5.2 2 2 0 0 1 5.1 3h3a2 2 0 0 1 2 1.7l.5 3-2 2a16 16 0 0 0 6.7 6.7l2-2 3 .5a2 2 0 0 1 1.7 2Z"/>',
    lock: '<rect x="5" y="10" width="14" height="11" rx="3"/><path d="M8 10V7a4 4 0 0 1 8 0v3m-4 5v2"/>',
    eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/>',
    'eye-off': '<path d="m3 3 18 18M10.6 5.1A12 12 0 0 1 12 5c6.5 0 10 7 10 7a17 17 0 0 1-3 3.9M6.5 6.5A19 19 0 0 0 2 12s3.5 7 10 7a12 12 0 0 0 5.5-1.5M9.9 9.9a3 3 0 0 0 4.2 4.2"/>',
    shield: '<path d="m12 3 8 3v6c0 5-8 9-8 9s-8-4-8-9V6Z"/>',
    'shield-check': '<path d="m12 3 8 3v6c0 5-8 9-8 9s-8-4-8-9V6Z"/><path d="m8 12 3 3 5-6"/>',
    briefcase: '<rect x="3" y="7" width="18" height="14" rx="3"/><path d="M8 7V4h8v3M3 12c6 4 12 4 18 0m-9 0v4"/>',
    building: '<rect x="5" y="3" width="14" height="18" rx="2"/><path d="M9 7h1m4 0h1M9 11h1m4 0h1M9 15h1m4 0h1M10 21v-3h4v3"/>',
    'chevron-down': '<path d="m6 9 6 6 6-6"/>',
    check: '<path d="m5 12 4 4L19 6"/>',
    'check-circle-2': '<circle cx="12" cy="12" r="9"/><path d="m8 12 3 3 5-6"/>',
    'file-check': '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8Z"/><path d="M14 2v6h6m-12 6 3 3 5-6"/>',
    info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v6m0-10h.01"/>',
    'alert-circle': '<circle cx="12" cy="12" r="9"/><path d="M12 7v6m0 4h.01"/>',
    'arrow-right': '<path d="M5 12h14m-6-6 6 6-6 6"/>',
    'arrow-left': '<path d="M19 12H5m6-6-6 6 6 6"/>',
    send: '<path d="m22 2-7 20-4-9-9-4 20-7ZM11 13 22 2"/>',
    'pen-tool': '<path d="m16 3 5 5-12 12H4v-5ZM13 6l5 5"/>',
    x: '<path d="m6 6 12 12M6 18 18 6"/>',
    cloud: '<path d="M18 18a4 4 0 0 0 0-8h-1a6 6 0 0 0-11-2 5 5 0 0 0-1 10Z"/>',
    'archive-restore': '<rect x="3" y="3" width="18" height="4" rx="1"/><path d="M5 7v14h14V7M9 12l3-3 3 3m-3-3v8"/>',
    'rotate-ccw': '<path d="M3 11a9 9 0 1 1 2.7 7M3 4v7h7"/>',
    'trash-2': '<path d="M3 6h18M9 6V3h6v3M5 6l1 15h12l1-15M10 10v7m4-7v7"/>',
    'loader-2': '<path d="M21 12a9 9 0 1 1-9-9"/>'
};
    function renderIcons() {
      document.querySelectorAll('i[data-lucide]').forEach(node => {
        const svg = document.createElementNS('http://www.w3.org/2000/svg','svg');
        svg.setAttribute('viewBox','0 0 24 24'); svg.setAttribute('aria-hidden','true');
        svg.setAttribute('class',`request-icon ${node.className || ''}`);
        svg.innerHTML = icons[node.dataset.lucide] || icons.info;
        node.replaceWith(svg);
      });
    }
    const toast = message => {
      const el=document.createElement('div'); el.className='toast'; el.textContent=message;
      $('toastContainer').append(el); setTimeout(()=>el.remove(),5000);
    };
    const status = text => { $('saveStatus').textContent=text; };
    function error(input, message='') {
      input.setAttribute('aria-invalid',String(Boolean(message)));
      input.classList.toggle('invalid-field',Boolean(message));
      if ($(input.id+'Error')) $(input.id+'Error').textContent=message;
    }
    function validate(input) {
      let message='';
      const value=input.value.trim();
      if (input.id==='contact') input.value=ui.normalizePhone(input.value);
      if (input.type==='checkbox') {
        if (input.required&&!input.checked) message=input.id==='agree'?'Please accept the privacy and account-use notice.':'Please confirm your division endorsement.';
      } else if (input.required&&!value) message='Please complete this field.';
      else if (input.id==='email' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) message='Enter a valid email address.';
      else if (input.id==='contact' && !/^09\d{9}$/.test(input.value)) message='Use an 11-digit mobile number starting with 09.';
      else if (input.id==='password' && input.value.length<6) message='Use at least 6 characters.';
      else if (input.id==='confirmPassword' && input.value!==$('password').value) message='Passwords do not match.';
      else if (input.maxLength>0&&input.value.length>input.maxLength) message=`Use no more than ${input.maxLength} characters.`;
      else if (input.tagName==='SELECT'&&!input.checkValidity()) message='Please select an option.';
      error(input,message); return !message;
    }
    function validatePage(number) {
      let valid=true;
      pages[number-1].querySelectorAll('[required]').forEach(input=>{if(!validate(input))valid=false;});
      return valid;
    }
    function focusInvalid() {
      let target=pages[page-1].querySelector('[aria-invalid="true"]');
      if(target?.id==='role')target=document.querySelector('.role-choice');
      target?.focus();
    }
    function showError(message) { $('requestError').textContent=message; $('requestError').hidden=false; $('requestError').focus(); }
    function summary() {
      for(const [out,input] of [['sumName','fullName'],['sumId','email'],['sumDivision','division'],['sumPosition','position']]) $(out).textContent=$(input).value.trim()||'—';
      $('summaryRoleBadge').textContent='Requested: '+($('role').value||'—');
    }
    function syncRole() {
      document.querySelectorAll('.role-choice').forEach(button=>button.setAttribute('aria-pressed',String(button.dataset.role===$('role').value)));
    }
    function showPage(number, focus=true) {
      form.dataset.stepDirection=number<page?'back':'forward';
      page=number;
      pages.forEach((section,i)=>{section.hidden=i+1!==page;});
      steps.forEach((step,i)=>{
        step.classList.toggle('active',i+1===page); step.classList.toggle('completed',i+1<page);
        if(i+1===page)step.setAttribute('aria-current','step');else step.removeAttribute('aria-current');
        step.disabled=i+1>page || saving;
      });
      $('stepperProgress').style.width=((page-1)/2*100)+'%';
      document.querySelector('.progress-track').setAttribute('aria-valuenow',String(page));
      $('progressLabel').textContent=`Step ${page} of 3`;
      $('progressHint').textContent=['Your details','Your assignment','Review & submit'][page-1];
      $('backBtn').style.visibility=page===1?'hidden':'visible';
      $('nextBtn').hidden=page===3; $('nextBtn').style.removeProperty('display');
      $('submitBtn').hidden=page!==3; $('submitBtn').style.removeProperty('display');
      if(page===3)summary();
      if(focus)pages[page-1].querySelector('h3')?.focus();
    }
    function meter() {
      const value=$('password').value;
      let score=value.length>=6?1:0;
      if(score){if(/[A-Z]/.test(value)&&/[a-z]/.test(value))score++;if(/\d/.test(value))score++;if(/[^A-Za-z0-9]/.test(value)&&value.length>=8)score++;}
      for(let i=1;i<=4;i++)$('pwSeg'+i).style.background=i<=score?(score<2?'var(--danger)':score<3?'var(--warning)':'var(--brand)'):'var(--line)';
      $('passwordStrengthText').textContent=['Use at least 6 characters','Weak · Add numbers and capitals','Fair · Add length and symbols','Strong password','Very strong password'][score];
    }
    const counter = () => { $('charCount').textContent=`${$('reason').value.length} / 250`; };
    form.addEventListener('portal:password-cleared',meter);
    function saveDraft() {
      if(saving||draftCleared)return;
      const data=Object.fromEntries(draftFields.map(id=>[id,$(id).value]));
      try {
        if(draftFields.some(id=>String(data[id]).trim()))localStorage.setItem(draftKey,JSON.stringify(data));
        else localStorage.removeItem(draftKey);
        status('Draft saved on this device • Passwords excluded');
      } catch { status('Draft storage unavailable. Keep this page open.'); }
    }
    function scheduleDraft(){if(saving)return;draftCleared=false;clearTimeout(draftTimer);draftTimer=setTimeout(saveDraft,400);}
    function clearDraft(){clearTimeout(draftTimer);draftCleared=true;try{localStorage.removeItem(draftKey);$('draftBanner').hidden=true;status('Saved draft cleared. Your current entries are still here.');toast('Saved draft cleared.');}catch{status('This browser could not clear the saved draft.');}}
    $('discardDraftBtn').addEventListener('click',clearDraft); $('clearSavedDraftBtn').addEventListener('click',clearDraft);
    $('restoreDraftBtn').addEventListener('click',()=>{
      try {
        const draft=JSON.parse(localStorage.getItem(draftKey)||'null');if(!draft||typeof draft!=='object')return;
        draftFields.forEach(id=>{if(typeof draft[id]==='string')$(id).value=draft[id];});
        $('password').value='';$('confirmPassword').value='';$('agree').checked=false;$('endorsementCheck').checked=false;
        fields.forEach(input=>error(input));syncRole();meter();counter();showPage(1);
        $('draftBanner').hidden=true;status('Draft restored. Re-enter your passwords and confirmations.');toast('Your draft is restored.');
      } catch { toast('Could not restore this draft.'); }
    });
    try {const data=JSON.parse(localStorage.getItem(draftKey)||'null');$('draftBanner').hidden=!data||!draftFields.some(id=>typeof data[id]==='string'&&data[id].trim());}catch{}
    form.addEventListener('input',event=>{
      const input=event.target;if(!fields.includes(input))return;
      if(input.getAttribute('aria-invalid')==='true'&&input.id!=='contact')validate(input);
      if(input.id==='password'){meter();if($('confirmPassword').value)validate($('confirmPassword'));}
      if(input.id==='confirmPassword'&&input.value)validate(input);
      if(input.id==='reason')counter();
      $('requestError').hidden=true;scheduleDraft();
    });
    form.addEventListener('change',event=>{if(fields.includes(event.target)){validate(event.target);scheduleDraft();}});
    fields.forEach(input=>input.addEventListener('blur',()=>{if(input.value||input.required)validate(input);}));
    for(const [buttonId,inputId]of [['togglePasswordBtn','password'],['toggleConfirmPasswordBtn','confirmPassword']]){
      $(buttonId).addEventListener('click',()=>{
        const visible=$(inputId).type==='password';$(inputId).type=visible?'text':'password';
        $(buttonId).setAttribute('aria-pressed',String(visible));$(buttonId).setAttribute('aria-label',visible?'Hide password':'Show password');
        $(buttonId).innerHTML=`<i data-lucide="${visible?'eye-off':'eye'}"></i>`;renderIcons();
      });
    }
    document.querySelectorAll('.role-choice').forEach(button=>button.addEventListener('click',()=>{
      $('role').value=button.dataset.role;syncRole();validate($('role'));scheduleDraft();
    }));
    function next(){if(saving)return;if(!validatePage(page)){focusInvalid();toast('Please complete the highlighted fields.');return;}showPage(Math.min(3,page+1));saveDraft();}
    $('nextBtn').addEventListener('click',next);$('backBtn').addEventListener('click',()=>{if(!saving)showPage(Math.max(1,page-1));});
    steps.forEach(step=>step.addEventListener('click',()=>{if(!saving&&Number(step.dataset.step)<page)showPage(Number(step.dataset.step));}));
    const modal=$('privacyModal');
    $('openPrivacyBtn').addEventListener('click',()=>modal.showModal());$('closePrivacyBtn').addEventListener('click',()=>modal.close());
    $('acceptPrivacyBtn').addEventListener('click',()=>{$('agree').checked=true;validate($('agree'));modal.close();$('openPrivacyBtn').focus();});
    function busy(value){saving=value;form.setAttribute('aria-busy',String(value));form.inert=value;
      steps.forEach(step=>{step.disabled=value||Number(step.dataset.step)>page;});
      $('submitBtn').disabled=value;$('submitBtn').textContent=value?'Submitting…':'Submit request';
      $('clearSavedDraftBtn').disabled=value;
    }
    form.addEventListener('submit',async event=>{
      event.preventDefault();if(saving)return;if(page<3){next();return;}
      for(let i=1;i<=3;i++){if(!validatePage(i)){showPage(i,false);focusInvalid();return;}}
      if(!navigator.onLine){showError('You’re offline. Reconnect and try again. Your entries are still here.');return;}
      if(!db){showError('The account service is unavailable. Reload this page and try again.');return;}
      $('requestError').hidden=true;clearTimeout(draftTimer);saveDraft();
      const now=new Date();
      const year=new Intl.DateTimeFormat('en',{timeZone:'Asia/Manila',year:'numeric'}).format(now);
      const ref=`REQ-${year}-${ui.uuid().slice(0,8).toUpperCase()}`;
      const email=$('email').value.trim().toLowerCase();
      const metadata={request_id:ref,full_name:$('fullName').value.trim(),username:email.split('@')[0],contact:ui.normalizePhone($('contact').value),position:$('position').value,division:$('division').value,requested_role:$('role').value,requested_system:$('role').value,endorser:$('endorser').value.trim(),reason:$('reason').value.trim(),submitted_at:now.toISOString(),submitted_display:new Intl.DateTimeFormat('en-US',{timeZone:'Asia/Manila',month:'short',day:'numeric',year:'numeric',hour:'2-digit',minute:'2-digit'}).format(now)};
      busy(true);status('Sending your request for administrator review…');
      try {
        const {data,error:failure}=await db.auth.signUp({email,password:$('password').value,options:{data:metadata}});
        if(failure)throw failure;
        if(!data?.user)throw new Error('The account service did not confirm your request.');
        if(Array.isArray(data.user.identities)&&!data.user.identities.length)throw new Error('An account request already exists for this email. Sign in or contact the administrator.');
        // Clear only this isolated public client; do not end another staff session.
        if(data.session)try{await db.auth.signOut({scope:'local'});}catch{}
        try{localStorage.removeItem(draftKey);}catch{}
        form.reset();fields.forEach(input=>error(input));form.hidden=true;
        document.querySelector('.progress-area').hidden=true;document.querySelector('.save-status-row').hidden=true;$('draftBanner').hidden=true;
        $('successRef').textContent=ref;$('requestSuccess').hidden=false;$('successTitle').focus();
      } catch(failure){
        const code=String(failure.code||'');
        const message=/already|exists|registered/i.test(failure.message||'')?'An account request already exists for this email. Sign in or contact the administrator.':failure.status===429?'Too many requests. Please wait before trying again.':/Abort|Timeout/.test(failure.name||'')?'The connection timed out. Check your inbox or ask the administrator whether your request was received before submitting again.':/fetch|network/i.test(failure.message||'')?'Could not connect. Check your connection; your entries are still here.':code==='weak_password'?'The password does not meet the account service requirements. Go back and use a stronger password.':failure.message||'The request could not be submitted. Please try again.';
        showError(message);status('Your entries are still here. Review the message above.');
      } finally {busy(false);}
    });
    window.addEventListener('pagehide',()=>{clearTimeout(draftTimer);if(!form.hidden&&!saving)saveDraft();});
    meter();counter();syncRole();showPage(1,false);renderIcons();
  };
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})();

/* Presentation enhancements only. Existing validation and submissions own the forms. */
(() => {
  'use strict';
  function init(){
    if(document.body.dataset.portalDesign!=='v4')return;
    const visitor=document.getElementById('visitorForm');
    if(visitor){
      const update=()=>document.querySelectorAll('[data-visit-preview]').forEach(output=>{
        const input=document.getElementById(output.dataset.visitPreview);if(!input)return;
        const value=input.value.trim();let text=value||(input.tagName==='SELECT'?'Not selected yet':'Not provided yet');
        if(value&&input.tagName==='SELECT')text=input.selectedOptions[0]?.textContent.trim()||value;
        if(input.id==='purposeCategory'&&value==='Other Service not listed')text=document.getElementById('otherPurposeSpecific')?.value.trim()||text;
        output.textContent=text;
      });
      visitor.addEventListener('input',update);visitor.addEventListener('change',update);visitor.addEventListener('blur',()=>queueMicrotask(update),true);visitor.addEventListener('reset',()=>queueMicrotask(update));update();
    }
    // Restore a single decorative arrow after the existing controller resets a label.
    for(const id of ['submitBtn','submitServiceRequestBtn']){
      const button=document.getElementById(id);if(!button||button.closest('#visitorForm'))continue;
      const form=button.form;if(!form)continue;
      const sync=()=>{
        if(form.getAttribute('aria-busy')==='true'||button.querySelector('svg,i'))return;
        const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');svg.setAttribute('viewBox','0 0 24 24');svg.setAttribute('aria-hidden','true');svg.setAttribute('class','v4-action-arrow');svg.innerHTML='<path d="M5 12h14m-6-6 6 6-6 6"/>';button.append(svg);
      };
      new MutationObserver(sync).observe(form,{attributes:true,attributeFilter:['aria-busy']});sync();
    }
    document.querySelectorAll('input:not([type="password"]):not([type="checkbox"]),textarea').forEach(field=>{
      const sync=()=>field.classList.toggle('v4-has-entry',Boolean(field.value.trim()));
      field.addEventListener('input',sync);field.form?.addEventListener('reset',()=>queueMicrotask(sync));sync();
    });
    document.body.dataset.portalSurfaceReady='true';
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})();
