/* Fixed emerald surroundings and light forms. No stored or system appearance settings. */
(() => {
  'use strict';
  let leaving=false;
  let exitAnimation=null;
  const canAnimate = () => !matchMedia('(prefers-reduced-motion: reduce)').matches && !navigator.connection?.saveData;
  function restorePage() {
    leaving=false;
    exitAnimation?.cancel();
    exitAnimation=null;
    document.body.dataset.routeMotion='ready';
  }
  async function navigate(destination) {
    if(leaving)return;
    leaving=true;
    const viewport=document.querySelector('.portal-viewport');
    if(canAnimate()&&viewport?.animate){
      document.body.dataset.routeMotion='leaving';
      exitAnimation=viewport.animate([{opacity:1,transform:'translateY(0)'},{opacity:0,transform:'translateY(-8px)'}],{duration:170,easing:'ease-in',fill:'forwards'});
      try{await exitAnimation.finished;}catch{}
    }
    window.location.assign(destination);
    // Restore the old document if a navigation is cancelled or fails to leave it.
    setTimeout(()=>{if(!document.hidden)restorePage();},1800);
  }
  function init() {
    const protectedPasswords=[...document.querySelectorAll('input[data-empty-on-open]')];
    function clearPassword(field) {
      field.value='';field.defaultValue='';field.type='password';field.readOnly=true;
      field.setAttribute('aria-invalid','false');field.classList.remove('invalid-field');
      field.closest('.input-box')?.classList.remove('invalid');
      const error=document.getElementById(field.id+'Error');if(error)error.textContent='';
      const button=document.querySelector(`button[aria-controls="${field.id}"]`);
      if(button){
        button.setAttribute('aria-pressed','false');button.setAttribute('aria-label','Show password');
        const use=button.querySelector('use');
        if(use)use.setAttribute('href','#icon-eye');
        else {const svg=button.querySelector('svg');if(svg)svg.innerHTML='<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/>';}
      }
      field.dispatchEvent(new CustomEvent('portal:password-cleared',{bubbles:true}));
    }
    protectedPasswords.forEach(field=>{
      clearPassword(field);
      const unlock=()=>{
        if(field.readOnly){field.value='';field.defaultValue='';field.readOnly=false;}
      };
      field.addEventListener('focus',unlock);
      field.addEventListener('pointerdown',unlock);
      field.addEventListener('keydown',unlock);
      field.addEventListener('input',()=>{if(field.readOnly&&field.value)clearPassword(field);});
    });
    const forms=new Set(protectedPasswords.map(field=>field.form).filter(Boolean));
    forms.forEach(form=>form.addEventListener('reset',()=>queueMicrotask(()=>protectedPasswords.filter(field=>field.form===form).forEach(clearPassword))));
    window.addEventListener('pagehide',()=>protectedPasswords.forEach(clearPassword));
    window.addEventListener('pageshow',event=>{
      restorePage();
      protectedPasswords.filter(field=>event.persisted||field.readOnly).forEach(clearPassword);
      if(event.persisted&&canAnimate())document.querySelector('.portal-viewport')?.animate([{opacity:0,transform:'translateY(6px)'},{opacity:1,transform:'translateY(0)'}],{duration:280,easing:'ease-out'});
    });
    document.addEventListener('click',event=>{
      const link=event.target instanceof Element?event.target.closest('a[href]'):null;
      if(!link||event.defaultPrevented||event.button!==0||event.metaKey||event.ctrlKey||event.shiftKey||event.altKey||link.download||link.target&&link.target!=='_self')return;
      const url=new URL(link.href,location.href);
      if(!['http:','https:','file:'].includes(url.protocol)||url.origin!==location.origin||url.pathname===location.pathname&&url.search===location.search)return;
      if(!canAnimate()||document.querySelector('form[aria-busy="true"]'))return;
      event.preventDefault();void navigate(url.href);
    });
    document.querySelectorAll('[data-brand-seal]').forEach(image => {
      const loaded = () => { image.hidden = !image.naturalWidth; };
      image.addEventListener('load', loaded);
      image.addEventListener('error', () => { image.hidden = true; });
      if (image.complete) loaded();
    });
    const reduced = matchMedia('(prefers-reduced-motion: reduce)');
    const connection = navigator.connection;
    const syncMotion = () => {
      document.body.dataset.sceneMotion = document.hidden || reduced.matches || connection?.saveData ? 'paused' : 'running';
    };
    reduced.addEventListener?.('change',syncMotion);
    connection?.addEventListener?.('change',syncMotion);
    document.addEventListener('visibilitychange',syncMotion);
    window.addEventListener('pageshow',syncMotion);
    syncMotion();
  }
  const normalizePhone = value => {
    const digits = String(value || '').replace(/\D/g, '');
    if (/^639\d{9}$/.test(digits)) return '0' + digits.slice(2);
    if (/^9\d{9}$/.test(digits)) return '0' + digits;
    return digits;
  };
  async function timedFetch(input, options = {}) {
    const controller = new AbortController();
    const upstream = options.signal || (input instanceof Request ? input.signal : null);
    const abort = () => controller.abort(upstream?.reason);
    if (upstream?.aborted) abort();
    else upstream?.addEventListener('abort', abort, {once:true});
    const timer = setTimeout(() => controller.abort(new DOMException('Request timed out','TimeoutError')), 20000);
    try { return await fetch(input, {...options, signal:controller.signal}); }
    finally { clearTimeout(timer); upstream?.removeEventListener('abort', abort); }
  }
  const uuid = () => {
    if (crypto.randomUUID) return crypto.randomUUID();
    const bytes = crypto.getRandomValues(new Uint8Array(16));
    bytes[6] = (bytes[6] & 15) | 64; bytes[8] = (bytes[8] & 63) | 128;
    const hex = [...bytes].map(byte => byte.toString(16).padStart(2,'0')).join('');
    return `${hex.slice(0,8)}-${hex.slice(8,12)}-${hex.slice(12,16)}-${hex.slice(16,20)}-${hex.slice(20)}`;
  };
  window.PortalUI = Object.freeze({normalizePhone, timedFetch, uuid, navigate});
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, {once:true});
  else init();
})();

/* Visual feedback follows the existing async state; it never submits a form. */
(() => {
  'use strict';
  if(window.PGENRO_ButtonFeedback)return;
  window.PGENRO_ButtonFeedback=true;
  function init(){
    const submitFor={loginForm:'loginBtn',accessForm:'submitBtn',publicServiceRequestForm:'submitServiceRequestBtn',visitorForm:'submitBtn'};
    Object.entries(submitFor).forEach(([formId,buttonId])=>{
      const form=document.getElementById(formId),button=document.getElementById(buttonId);if(!form||!button)return;
      const status=document.createElement('p');status.className='sr-only ui-async-status';status.setAttribute('role','status');status.setAttribute('aria-live','polite');status.setAttribute('aria-atomic','true');form.after(status);
      const labels={loginForm:'Signing in. Please wait.',accessForm:'Sending your account request. Please wait.',publicServiceRequestForm:'Sending your service request. Please wait.',visitorForm:'Saving your visit. Please wait.'};
      const sync=()=>{const busy=form.getAttribute('aria-busy')==='true';button.setAttribute('aria-busy',String(busy));button.classList.toggle('ui-button-busy',busy);status.textContent=busy?labels[formId]:'';};
      sync();new MutationObserver(sync).observe(form,{attributes:true,attributeFilter:['aria-busy']});
    });
    if(document.body.dataset.recordAccess==='view-only'){
      document.querySelectorAll('#refreshDashboardBtn,#refreshRecordsBtn,#refreshBtn,#travelRefresh').forEach(button=>{
        let previous='';
        const sync=()=>{const busy=button.disabled||button.classList.contains('is-loading'),key=String(busy);if(key===previous)return;previous=key;button.setAttribute('aria-busy',key);button.classList.toggle('ui-button-busy',busy);};
        sync();new MutationObserver(sync).observe(button,{attributes:true,attributeFilter:['disabled','class']});
      });
    }
    const eligible='.primary-sign-btn,.submit-btn,.btn-solid,.primary-action,.secondary-action,.btn-outline,.refresh-btn,.secondary-btn';
    document.addEventListener('pointerdown',event=>{
      const button=event.target.closest('button');if(!button||!button.matches(eligible)||button.disabled||event.button!==0||matchMedia('(prefers-reduced-motion: reduce)').matches)return;
      const r=button.getBoundingClientRect(),wave=document.createElement('span');wave.className='ui-tap-wave';wave.setAttribute('aria-hidden','true');
      wave.style.setProperty('--tap-x',event.clientX-r.left+'px');wave.style.setProperty('--tap-y',event.clientY-r.top+'px');wave.style.setProperty('--tap-size',Math.max(r.width,r.height)*2+'px');
      button.append(wave);wave.addEventListener('animationend',()=>wave.remove(),{once:true});setTimeout(()=>wave.remove(),700);
    },true);
    document.body.dataset.buttonFeedbackReady='true';
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})();

/* Public service request wizard. Existing RPC name, field names and receipt contract retained. */
(() => {
  'use strict';
  function init() {
    const $=id=>document.getElementById(id);
    const form=$('publicServiceRequestForm');if(!form)return;
    const ui=window.PortalUI;
    const CONFIG={url:'https://zssrxubajhqryrwijyzm.supabase.co',key:'sb_publishable_5RWFfJ5oN6ike6SSyafajw_yF9DYApP'};
    const field=name=>form.elements.namedItem(name);
    const pages=[1,2,3,4].map(i=>$('servicePage'+i));
    const steps=[...form.querySelectorAll('[data-service-step]')];
    const inputs=[...form.querySelectorAll('input,textarea,select')];
    const categories=['technicalAssistance','iecService','plantingMaterials','environmentalConcerns','certifications','otherServices'];
    const labels=['About you','Services','Details','Review & submit'];
    const feedback=$('serviceRequestFeedback');
    let page=1,saving=false,requestId=null,serializedPayload=null,showCategoryError=false;
    const categoryError=document.createElement('p');categoryError.className='category-error';categoryError.id='categoryError';categoryError.hidden=true;categoryError.setAttribute('role','status');
    $('categoryHelp').after(categoryError);
    const selectedCount=document.createElement('p');selectedCount.className='category-selection';selectedCount.setAttribute('role','status');selectedCount.textContent='No services selected yet';
    $('requestCategories').querySelector('.service-form-grid').before(selectedCount);
    categories.forEach(name=>{
      const input=field(name);input.setAttribute('aria-describedby',[input.getAttribute('aria-describedby'),'categoryHelp','categoryError'].filter(Boolean).join(' '));
    });
    inputs.forEach(input=>{
      const error=document.createElement('span');error.className='error-msg';error.id=input.id+'Error';
      error.setAttribute('aria-live','polite');input.after(error);
      input.setAttribute('aria-describedby',[input.getAttribute('aria-describedby'),error.id].filter(Boolean).join(' '));
      if(input.tagName==='TEXTAREA'){
        const count=document.createElement('p');count.className='field-counter';count.id=input.id+'Count';input.parentElement.append(count);
        const sync=()=>{count.textContent=`${input.value.length} / ${input.maxLength}`;};input.addEventListener('input',sync);sync();
      }
    });
    for(const [name,autocomplete] of [['clientName','name'],['organization','organization'],['contactNo','tel'],['emailAddress','email']])field(name).autocomplete=autocomplete;
    field('emailAddress').setAttribute('autocapitalize','none');field('emailAddress').spellcheck=false;
    function today(){
      const parts=new Intl.DateTimeFormat('en-US',{timeZone:'Asia/Manila',year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(new Date());
      const values=Object.fromEntries(parts.map(part=>[part.type,part.value]));return `${values.year}-${values.month}-${values.day}`;
    }
    function syncDate(){field('dateNeeded').min=today();}
    function error(input,message=''){
      input.setAttribute('aria-invalid',String(Boolean(message)));
      $(input.id+'Error').textContent=message;
    }
    function validate(input){
      const value=input.value.trim();let message='';
      if(input.required&&!value)message='Please complete this field.';
      else if(value&&input.type==='email'&&!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value))message='Enter a valid email address.';
      else if(value&&input.name==='contactNo'){
        const digits=value.replace(/\D/g,'');
        if(!/^[+\d\s().-]+$/.test(value)||digits.length<7||digits.length>15)message='Enter a valid mobile or landline number.';
        else if(/^(09|\+?639)/.test(value)&&!/^09\d{9}$/.test(ui.normalizePhone(value)))message='Use a complete Philippine mobile number, for example 09123456789.';
      } else if(value&&input.type==='date'&&value<today())message='Choose today or a future date.';
      else if(input.maxLength>0&&value.length>input.maxLength)message=`Use no more than ${input.maxLength} characters.`;
      error(input,message);return !message;
    }
    function syncCategories(){
      const count=categories.filter(name=>field(name).value.trim()).length;
      selectedCount.textContent=count?`${count} service ${count===1?'category':'categories'} selected`:'No services selected yet';
      categoryError.hidden=!showCategoryError||count>0;
      categoryError.textContent=count?'':'Select at least one service, or describe another service below.';
      return count>0;
    }
    function validatePage(number){
      syncDate();let valid=true;
      pages[number-1].querySelectorAll('input,select,textarea').forEach(input=>{if(!validate(input))valid=false;});
      if(number===2){showCategoryError=true;if(!syncCategories())valid=false;}
      return valid;
    }
    function focusInvalid(){
      const target=pages[page-1].querySelector('[aria-invalid="true"]')||(page===2?field('technicalAssistance'):null);
      target?.focus();
    }
    function showError(message){feedback.textContent=message;feedback.hidden=false;feedback.focus();}
    function showPage(number,focus=true){
      form.dataset.stepDirection=number<page?'back':'forward';
      page=number;pages.forEach((section,i)=>{section.hidden=i+1!==page;});
      steps.forEach((step,i)=>{
        step.classList.toggle('active',i+1===page);step.classList.toggle('completed',i+1<page);
        step.disabled=saving||i+1>page;
        if(i+1===page)step.setAttribute('aria-current','step');else step.removeAttribute('aria-current');
      });
      $('serviceProgressFill').style.width=((page-1)/3*100)+'%';$('serviceProgress').setAttribute('aria-valuenow',String(page));
      $('serviceStepLabel').textContent=`Step ${page} of 4`;$('serviceStepHint').textContent=labels[page-1];
      $('serviceBackBtn').hidden=page===1;$('serviceNextBtn').hidden=page===4;$('submitServiceRequestBtn').hidden=page!==4;
      if(page===4)renderReview();
      if(focus){
        const heading=pages[page-1].querySelector('legend,h3');heading?.setAttribute('tabindex','-1');heading?.focus();
      }
    }
    function renderReview(){
      const root=$('serviceReview');root.replaceChildren();
      for(let number=1;number<=3;number++){
        const block=document.createElement('section');block.className='review-block';
        const header=document.createElement('header');const title=document.createElement('h4');title.textContent=labels[number-1];
        const edit=document.createElement('button');edit.type='button';edit.className='text-button';edit.textContent='Edit';edit.setAttribute('aria-label','Edit '+labels[number-1].toLowerCase());edit.addEventListener('click',()=>showPage(number));
        header.append(title,edit);const list=document.createElement('dl');
        pages[number-1].querySelectorAll('input,select,textarea').forEach(input=>{
          const value=input.value.trim();if(!value)return;
          const item=document.createElement('div');const term=document.createElement('dt');const definition=document.createElement('dd');
          term.textContent=form.querySelector(`label[for="${input.id}"]`)?.textContent.replace(/\s*\*\s*$/,'')||input.name;
          definition.textContent=value;item.append(term,definition);list.append(item);
        });
        block.append(header,list);root.append(block);
      }
    }
    function next(){if(saving)return;if(!validatePage(page)){focusInvalid();return;}feedback.hidden=true;showPage(Math.min(4,page+1));}
    $('serviceNextBtn').addEventListener('click',next);$('serviceBackBtn').addEventListener('click',()=>{if(!saving)showPage(Math.max(1,page-1));});
    steps.forEach(step=>step.addEventListener('click',()=>{if(!saving&&Number(step.dataset.serviceStep)<page)showPage(Number(step.dataset.serviceStep));}));
    form.addEventListener('input',event=>{
      if(!inputs.includes(event.target))return;
      if(event.target.getAttribute('aria-invalid')==='true')validate(event.target);
      feedback.hidden=true;syncCategories();
    });
    form.addEventListener('change',event=>{if(inputs.includes(event.target)){validate(event.target);syncCategories();}});
    inputs.forEach(input=>input.addEventListener('blur',()=>{if(input.value||input.required)validate(input);}));
    const clearDialog=$('clearFormDialog');
    $('clearServiceFormBtn').addEventListener('click',()=>{if(!saving)clearDialog.showModal();});
    clearDialog.querySelector('[data-close-dialog]').addEventListener('click',()=>clearDialog.close());
    $('confirmClearServiceBtn').addEventListener('click',()=>{clearDialog.close();form.reset();showPage(1);});
    form.addEventListener('reset',event=>{
      if(saving){event.preventDefault();return;}
      requestId=null;serializedPayload=null;showCategoryError=false;feedback.hidden=true;
      queueMicrotask(()=>{inputs.forEach(input=>{error(input);if($(input.id+'Count'))$(input.id+'Count').textContent=`0 / ${input.maxLength}`;});syncCategories();syncDate();});
    });
    form.addEventListener('submit',async event=>{
      event.preventDefault();if(saving)return;if(page<4){next();return;}
      for(let number=1;number<=3;number++)if(!validatePage(number)){showPage(number,false);focusInvalid();return;}
      if(!navigator.onLine){showError('You’re offline. Reconnect to submit. Your entries are still here.');return;}
      feedback.hidden=true;
      const payload=Object.fromEntries(new FormData(form));Object.keys(payload).forEach(key=>{payload[key]=String(payload[key]).trim();});
      const serialized=JSON.stringify(payload);
      if(!requestId||serializedPayload!==serialized){requestId=ui.uuid();serializedPayload=serialized;}
      const controls=[...form.querySelectorAll('input,select,textarea,button')];const previous=controls.map(input=>input.disabled);
      saving=true;form.setAttribute('aria-busy','true');form.inert=true;controls.forEach(input=>{input.disabled=true;});
      const submit=$('submitServiceRequestBtn');submit.textContent='Submitting…';let failureMessage='';
      try {
        const response=await ui.timedFetch(`${CONFIG.url}/rest/v1/rpc/submit_public_service_request`,{
          method:'POST',headers:{apikey:CONFIG.key,'Content-Type':'application/json'},body:JSON.stringify({p_data:payload,p_submission_id:requestId})
        });
        const result=await response.json().catch(()=>null);
        if(!response.ok){
          if(['PGRST202','42883'].includes(result?.code))throw new Error('Service submission is not available yet. Please ask the administrator to enable the public service request form. Your entries are still here.');
          if(result?.code==='22023')throw new Error(result.message||'Please review your entries.');
          throw new Error('Your request could not be saved. Please try again. Your entries are still here.');
        }
        if(!result?.id||!result.serviceNo||result.serviceStatus!=='Pending Review')throw new Error('The server did not confirm your request. Please submit again to confirm.');
        $('receiptServiceNo').textContent=result.serviceNo;$('receiptRequestDate').textContent=result.dateRequest||'—';$('receiptReference').textContent=result.id;
        form.hidden=true;$('serviceRequestReceipt').hidden=false;$('serviceRequestReceipt').focus();
      } catch(failure){
        failureMessage=/Abort|Timeout/.test(failure.name||'')?'The connection timed out. Submit again to confirm; an unchanged retry uses the same submission reference.':failure instanceof TypeError?'Could not connect. Check your connection and try again. Your entries are still here.':failure.message;
      } finally {
        saving=false;form.inert=false;form.setAttribute('aria-busy','false');controls.forEach((input,i)=>{input.disabled=previous[i];});
        submit.textContent='Submit request';if(failureMessage)showError(failureMessage);
      }
    });
    $('anotherServiceRequestBtn').addEventListener('click',()=>{
      form.reset();$('serviceRequestReceipt').hidden=true;form.hidden=false;showPage(1,false);field('clientName').focus();
    });
    $('printReceiptBtn').addEventListener('click',()=>window.print());
    window.addEventListener('pageshow',syncDate);syncDate();syncCategories();showPage(1,false);
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})();

/* Presentation enhancements only. Existing validation and submissions own the forms. */
(() => {
  'use strict';
  function init(){
    if(document.body.dataset.portalDesign!=='v4')return;
    const visitor=document.getElementById('visitorForm');
    if(visitor){
      const update=()=>document.querySelectorAll('[data-visit-preview]').forEach(output=>{
        const input=document.getElementById(output.dataset.visitPreview);if(!input)return;
        const value=input.value.trim();let text=value||(input.tagName==='SELECT'?'Not selected yet':'Not provided yet');
        if(value&&input.tagName==='SELECT')text=input.selectedOptions[0]?.textContent.trim()||value;
        if(input.id==='purposeCategory'&&value==='Other Service not listed')text=document.getElementById('otherPurposeSpecific')?.value.trim()||text;
        output.textContent=text;
      });
      visitor.addEventListener('input',update);visitor.addEventListener('change',update);visitor.addEventListener('blur',()=>queueMicrotask(update),true);visitor.addEventListener('reset',()=>queueMicrotask(update));update();
    }
    // Restore a single decorative arrow after the existing controller resets a label.
    for(const id of ['submitBtn','submitServiceRequestBtn']){
      const button=document.getElementById(id);if(!button||button.closest('#visitorForm'))continue;
      const form=button.form;if(!form)continue;
      const sync=()=>{
        if(form.getAttribute('aria-busy')==='true'||button.querySelector('svg,i'))return;
        const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');svg.setAttribute('viewBox','0 0 24 24');svg.setAttribute('aria-hidden','true');svg.setAttribute('class','v4-action-arrow');svg.innerHTML='<path d="M5 12h14m-6-6 6 6-6 6"/>';button.append(svg);
      };
      new MutationObserver(sync).observe(form,{attributes:true,attributeFilter:['aria-busy']});sync();
    }
    document.querySelectorAll('input:not([type="password"]):not([type="checkbox"]),textarea').forEach(field=>{
      const sync=()=>field.classList.toggle('v4-has-entry',Boolean(field.value.trim()));
      field.addEventListener('input',sync);field.form?.addEventListener('reset',()=>queueMicrotask(sync));sync();
    });
    document.body.dataset.portalSurfaceReady='true';
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})();
