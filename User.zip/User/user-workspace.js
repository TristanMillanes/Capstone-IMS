/* Presentation and accidental-write protection for authenticated viewer pages. */
(() => {
 'use strict';
 const recordTables=new Set(['communications','office_memos','travel_orders','employees','inventory','inventory_movements','ics_records','service_requests','visitors']);
 const submissions=new Set(['submit_ics','submit_public_ics','submit_public_service_request']);
 const originalFetch=window.fetch.bind(window);
 window.PGENRO_ViewerDetails=(title,fields,section='OFFICE RECORD')=>{
  let dialog=document.getElementById('viewerRecordDetails');
  if(!dialog){dialog=document.createElement('dialog');dialog.id='viewerRecordDetails';dialog.className='viewer-record-dialog';dialog.setAttribute('aria-labelledby','viewerRecordTitle');dialog.innerHTML='<header><div><small></small><h2 id="viewerRecordTitle"></h2></div><button type="button" aria-label="Close record details">×</button></header><dl></dl><footer>View-only record</footer>';document.body.append(dialog);dialog.querySelector('button').addEventListener('click',()=>dialog.close());}
  dialog.querySelector('h2').textContent=title;dialog.querySelector('small').textContent=section;
  const list=dialog.querySelector('dl');list.replaceChildren();
  fields.forEach(([label,content])=>{const pair=document.createElement('div'),term=document.createElement('dt'),value=document.createElement('dd');term.textContent=label;value.textContent=content==null||content===''?'—':String(content);pair.append(term,value);list.append(pair);});
  if(!dialog.open)dialog.showModal();
 };
 window.fetch=(input,options={})=>{
  const request=input instanceof Request?input:null;
  const url=new URL(request?request.url:String(input),location.href);
  const method=String(options.method||request?.method||'GET').toUpperCase();
  const parts=url.pathname.split('/').filter(Boolean),rest=parts.indexOf('v1');
  const isRest=rest>0&&parts[rest-1]==='rest';
  const blocked=isRest&&(recordTables.has(parts[rest+1])&&!['GET','HEAD','OPTIONS'].includes(method)||parts[rest+1]==='rpc'&&submissions.has(parts[rest+2]));
  const upload=parts[0]==='storage'&&parts[1]==='v1'&&!['GET','HEAD','OPTIONS'].includes(method)&&parts[2]==='object'&&!['sign','authenticated','public'].includes(parts[3]);
  if(blocked||upload)return Promise.resolve(new Response(JSON.stringify({code:'PGENRO_VIEW_ONLY',message:'Your workspace can view records. Only administrators can change them.'}),{status:403,headers:{'Content-Type':'application/json'}}));
  return originalFetch(input,options);
 };
 function init(){
  const body=document.body;if(body.dataset.recordAccess!=='view-only')return;
  const title=document.querySelector('h1')?.textContent.trim()||'Office workspace';
  document.querySelector('.depth-topbar-breadcrumb > span')?.setAttribute('title',title);
  const date=document.getElementById('viewerToday');if(date)date.textContent=new Intl.DateTimeFormat('en-PH',{timeZone:'Asia/Manila',weekday:'short',month:'short',day:'numeric',year:'numeric'}).format(new Date());
  const input=document.getElementById('viewerModuleSearch'),results=document.getElementById('viewerModuleResults');
  const modules=[...document.querySelectorAll('.modules-list a')].map(link=>({name:link.textContent.trim(),href:link.getAttribute('href')}));
  function close(){if(results){results.hidden=true;input.setAttribute('aria-expanded','false');}}
  function search(){
   const term=input.value.trim().toLowerCase();results.replaceChildren();
   if(!term){close();return;}
   const found=modules.filter(item=>item.name.toLowerCase().includes(term));
   for(const item of found){const link=document.createElement('a');link.href=item.href;link.textContent=item.name;results.append(link);}
   if(!found.length){const text=document.createElement('p');text.textContent='No matching modules';results.append(text);}
   results.hidden=false;input.setAttribute('aria-expanded','true');
  }
  input?.addEventListener('input',search);input?.addEventListener('keydown',event=>{if(event.key==='Escape'){close();input.blur();}if(event.key==='ArrowDown'){event.preventDefault();results.querySelector('a')?.focus();}if(event.key==='Enter'){const first=results.querySelector('a');if(first){event.preventDefault();first.click();}}});
  document.addEventListener('keydown',event=>{if((event.ctrlKey||event.metaKey)&&event.key.toLowerCase()==='k'){event.preventDefault();input?.focus();}if(event.key==='Escape')close();});
  document.addEventListener('click',event=>{if(!event.target.closest('.viewer-module-search'))close();});
  // The capture guard also covers stale markup or programmatically mounted editors.
  document.addEventListener('submit',event=>{
   const form=event.target;
   if(form.matches('#inventoryForm,#icsSubmissionForm,#icsSubmissionFormInline,[data-record-editor]')){event.preventDefault();event.stopImmediatePropagation();}
  },true);
  document.addEventListener('click',event=>{
   const node=event.target.closest('a[href],button');if(!node)return;
   const write=['add','edit','delete','remove','approve','reject','save','create','update','submit'];
   const action=String(node.dataset.action||'').toLowerCase();
   if(write.includes(action)||node.matches('#fillIcsFormBtn,#openEncodingBtn')||node.tagName==='A'&&/\/(?:ics-form|service-request-form)\.html$/.test(new URL(node.href,location.href).pathname)){event.preventDefault();event.stopImmediatePropagation();}
  },true);
  // No transformed chart ancestors: tooltips keep their pointer coordinates.
  document.querySelectorAll('.depth-tilt,.depth-entered').forEach(el=>el.classList.remove('depth-tilt','depth-entered'));
  document.querySelectorAll('.detail-drawer').forEach(drawer=>{const sync=()=>{drawer.inert=drawer.getAttribute('aria-hidden')==='true';};sync();new MutationObserver(sync).observe(drawer,{attributes:true,attributeFilter:['aria-hidden']});});
  if(location.pathname.endsWith('/inventory.html')){
   const table=document.getElementById('recordsTable');
   function install(){table?.querySelectorAll('tr').forEach(row=>{
    const cell=row.querySelector('.action-column');if(!cell||cell.querySelector('.viewer-detail-button'))return;
    const button=document.createElement('button');button.type='button';button.className='viewer-detail-button';button.textContent='View details';cell.replaceChildren(button);
   });}
   table?.addEventListener('click',event=>{const button=event.target.closest('.viewer-detail-button');if(!button)return;
    const row=button.closest('tr');const values=[...row.cells].slice(0,-1);const labels=['Item ID','Item details','Category','Total received','Issued / used','Stock balance'];
    window.PGENRO_ViewerDetails('Item details',values.map((cell,i)=>[labels[i]||'Record detail',cell.textContent.trim()]),'SUPPLIES INVENTORY');
   });
   if(table)new MutationObserver(install).observe(table,{childList:true,subtree:true});install();
  }
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})();

/* Page-owned layout helpers; do not change record permissions or data writes. */
(() => {
  'use strict';
  function init() {
    if (document.body.dataset.unifiedLayoutReady) return;
    document.body.dataset.unifiedLayoutReady = 'true';
    // A wide registry scrolls within its own region, including dynamically mounted tables.
    function containTables() {
      document.querySelectorAll('main table,.modal-body table,.modal-content table').forEach(table => {
        if (table.closest('.table-responsive,.table-wrapper,.table-container,.table-scroll,.responsive-table,.ui-table-scroll,.ws-table-scroll,.audit-table-scroll,.monitor-table-scroll')) return;
        const region = document.createElement('div'); region.className = 'ui-table-scroll';
        table.before(region); region.append(table);
      });
    }
    containTables();
    let tableFrame;
    const insertedTables = new MutationObserver(records => {
      if (!records.some(record => [...record.addedNodes].some(node => node.nodeType === 1 && (node.tagName === 'TABLE' || node.querySelector?.('table'))))) return;
      cancelAnimationFrame(tableFrame); tableFrame = requestAnimationFrame(containTables);
    });
    insertedTables.observe(document.body, {childList:true,subtree:true});
    document.querySelector('.admin-sidebar-close')?.addEventListener('click',()=>document.getElementById('sidebarBackdrop')?.click());
    // The existing user page controls continue to open and close its module menu.
    const sidebar = document.querySelector('.pgenro-user .sidebar');
    if (sidebar) {
      const media = matchMedia('(max-width: 900px)'), menu = document.getElementById('hamburgerMenu');
      let previouslyOpen = false, preferredCollapsed = false;
      try { preferredCollapsed = localStorage.getItem('pgenro_user_sidebar') === 'collapsed'; } catch {}
      sidebar.querySelectorAll('.modules-list a').forEach(link=>link.title=link.textContent.trim());
      function desktopNavigation() {
        const collapsed = !media.matches && preferredCollapsed;
        sidebar.classList.toggle('collapsed',collapsed);document.body.classList.toggle('user-sidebar-collapsed',collapsed);
        if(!media.matches&&menu){menu.setAttribute('aria-expanded',String(!collapsed));menu.setAttribute('aria-label',collapsed?'Expand module menu':'Collapse module menu');menu.title=menu.getAttribute('aria-label');}
      }
      menu?.addEventListener('click',event=>{
        if(media.matches)return;
        event.preventDefault();event.stopImmediatePropagation();
        preferredCollapsed = !sidebar.classList.contains('collapsed');
        try{localStorage.setItem('pgenro_user_sidebar',preferredCollapsed?'collapsed':'expanded');}catch{}
        desktopNavigation();
      },true);
      function sync() {
        const open = media.matches && sidebar.classList.contains('open');
        sidebar.inert = media.matches && !open;
        sidebar.setAttribute('aria-hidden', String(media.matches && !open));
        if (open && !previouslyOpen) sidebar.querySelector('.user-sidebar-close,a[href]')?.focus({preventScroll:true});
        if (!open && previouslyOpen) menu?.focus({preventScroll:true});
        previouslyOpen = open;
      }
      const state = new MutationObserver(sync); state.observe(sidebar,{attributes:true,attributeFilter:['class']});
      media.addEventListener('change',()=>{desktopNavigation();sync();});desktopNavigation();sync();
      let navigationFrame;
      window.addEventListener('resize',()=>{cancelAnimationFrame(navigationFrame);navigationFrame=requestAnimationFrame(desktopNavigation);});
      window.addEventListener('pagehide',()=>cancelAnimationFrame(navigationFrame));
      document.querySelector('.user-sidebar-close')?.addEventListener('click',()=>{ if(sidebar.classList.contains('open')) menu?.click(); });
      document.addEventListener('keydown',event=>{
        if(!media.matches||!sidebar.classList.contains('open')) return;
        if(event.key==='Escape') {menu?.click();return;}
        if(event.key!=='Tab')return;
        const items=[...sidebar.querySelectorAll('a[href],button:not(:disabled),[tabindex="0"]')].filter(el=>el.getClientRects().length && !el.closest('[inert]'));
        if(!items.length)return;
        const first=items[0],last=items.at(-1);
        if(!sidebar.contains(document.activeElement)){event.preventDefault();(event.shiftKey?last:first).focus();}
        else if(event.shiftKey&&document.activeElement===first){event.preventDefault();last.focus();}
        else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first.focus();}
      });
    }
    window.addEventListener('pagehide',event=>{if(event.persisted)return;insertedTables.disconnect();cancelAnimationFrame(tableFrame);});
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})();
