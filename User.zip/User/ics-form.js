'use strict'; window.location.replace('ics.html');
