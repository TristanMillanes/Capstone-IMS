/* Local navigation icons and brand-image fallback. */
(() => {
  'use strict';
  // Keep the essential navigation legible when the existing icon CDN is offline.
  if (!window.lucide?.createIcons) {
    const paths = {
      'layout-dashboard':'<rect x="3" y="3" width="7" height="8" rx="1.5"/><rect x="14" y="3" width="7" height="5" rx="1.5"/><rect x="3" y="15" width="7" height="6" rx="1.5"/><rect x="14" y="12" width="7" height="9" rx="1.5"/>',
      mail:'<rect x="3" y="5" width="18" height="14" rx="3"/><path d="m3 7 9 6 9-6"/>',
      navigation:'<path d="m21 3-7 18-3-8-8-3Z"/>',
      'file-text':'<path d="M14 3H6v18h12V7Z"/><path d="M14 3v5h4M9 12h6m-6 4h6"/>',
      'users-round':'<circle cx="9" cy="7" r="3"/><path d="M3 21v-3a6 6 0 0 1 12 0v3m2-17a3 3 0 0 1 0 6m1 4a5 5 0 0 1 3 5v2"/>',
      package:'<path d="m12 3 9 5v9l-9 5-9-5V8Zm0 10 9-5M3 8l9 5v9M7 5.8l9 5"/>',
      'clipboard-signature':'<rect x="4" y="4" width="16" height="17" rx="2"/><path d="M9 2h6v4H9Zm-2 9h10m-10 5h5m1 1 4-4"/>',
      wrench:'<path d="M14 6a5 5 0 0 0-6 6l-5 5a2 2 0 0 0 4 4l5-5a5 5 0 0 0 6-6l-3 3-4-4Z"/>',
      layers:'<path d="m12 3 10 5-10 5L2 8Zm-10 9 10 5 10-5M2 16l10 5 10-5"/>',
      user:'<circle cx="12" cy="7" r="4"/><path d="M4 21v-2a8 8 0 0 1 16 0v2"/>',
      'chevron-up':'<path d="m6 15 6-6 6 6"/>',
      'chevron-down':'<path d="m6 9 6 6 6-6"/>',
      'log-out':'<path d="M9 3H4v18h5m5-15 6 6-6 6M8 12h12"/>',
      search:'<circle cx="10" cy="10" r="6"/><path d="m15 15 6 6"/>',
      'refresh-cw':'<path d="M20 8a8 8 0 1 0 0 8m1-14v6h-6"/>',
      'calendar-days':'<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M7 2v6m10-6v6M3 11h18M7 15h2m4 0h2"/>',
      'clock-3':'<circle cx="12" cy="12" r="9"/><path d="M12 7v5h5"/>',
      'circle-check-big':'<path d="M21 11a9 9 0 1 1-6-8M8 11l4 4L22 5"/>',
      'circle-check':'<circle cx="12" cy="12" r="9"/><path d="m8 12 3 3 6-6"/>',
      'badge-check':'<path d="m12 2 3 2 4 1 1 4 2 3-2 3-1 4-4 1-3 2-3-2-4-1-1-4-2-3 2-3 1-4 4-1Z"/><path d="m8 12 3 3 5-6"/>',
      leaf:'<path d="M20 3C10 3 4 8 4 14a6 6 0 0 0 6 6c7 0 10-8 10-17ZM3 21 14 10"/>',
      plus:'<path d="M12 4v16M4 12h16"/>',
      x:'<path d="m6 6 12 12M6 18 18 6"/>',
      activity:'<path d="M2 12h5l3-8 4 16 3-8h5"/>',
      'arrow-up-right':'<path d="M6 18 18 6M6 6h12v12"/>',
      'arrow-right':'<path d="M4 12h16m-6-6 6 6-6 6"/>',
      'file-search':'<path d="M14 3H5v18h8M14 3v5h5V7Z"/><circle cx="16" cy="15" r="4"/><path d="m19 18 3 3"/>'
    };
    Object.assign(paths,{"eye": "<path d=\"M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z\"/><circle cx=\"12\" cy=\"12\" r=\"3\"/>", "printer": "<path d=\"M6 8V3h12v5M6 17H3V9h18v8h-3M6 14h12v7H6Z\"/><path d=\"M17 11h1\"/>", "settings": "<path d=\"m9 3-1 3-3 1-2 4 2 2v4l4 2 3-1 3 1 4-2v-4l2-2-2-4-3-1-1-3Z\"/><circle cx=\"12\" cy=\"11\" r=\"3\"/>", "chevron-left": "<path d=\"m15 6-6 6 6 6\"/>", "chevron-right": "<path d=\"m9 6 6 6-6 6\"/>", "download": "<path d=\"M12 3v12m-5-5 5 5 5-5M4 16v5h16v-5\"/>", "arrow-left": "<path d=\"M20 12H4m6-6-6 6 6 6\"/>", "info": "<circle cx=\"12\" cy=\"12\" r=\"9\"/><path d=\"M12 11v6m0-10v.1\"/>", "phone": "<path d=\"m5 3-2 3c1 8 7 14 15 15l3-2-4-5-3 2-6-6 2-3Z\"/>", "map-pin": "<path d=\"M20 10c0 6-8 12-8 12S4 16 4 10a8 8 0 0 1 16 0Z\"/><circle cx=\"12\" cy=\"10\" r=\"3\"/>", "paperclip": "<path d=\"m9 16 8-8a3 3 0 0 0-4-4L4 13a5 5 0 0 0 7 7L21 10M7 14l8-8\"/>", "copy": "<rect x=\"8\" y=\"8\" width=\"13\" height=\"13\" rx=\"2\"/><path d=\"M16 8V3H3v13h5\"/>", "briefcase": "<rect x=\"3\" y=\"7\" width=\"18\" height=\"14\" rx=\"2\"/><path d=\"M8 7V3h8v4M3 13h18m-11-2v4h4v-4\"/>", "clipboard-list": "<rect x=\"4\" y=\"4\" width=\"16\" height=\"17\" rx=\"2\"/><path d=\"M9 2h6v4H9Zm-1 9h8m-8 5h8\"/>", "inbox": "<path d=\"M3 13 6 4h12l3 9v7H3Zm0 0h6l2 3h2l2-3h6\"/>", "coins": "<ellipse cx=\"9\" cy=\"6\" rx=\"6\" ry=\"3\"/><path d=\"M3 6v4c0 4 12 4 12 0V6M3 10v4c0 3 8 4 11 1m3-6c7 0 7 6 0 6m-1-2v7c4 2 7-1 5-5\"/>", "route": "<circle cx=\"5\" cy=\"5\" r=\"2\"/><circle cx=\"19\" cy=\"19\" r=\"2\"/><path d=\"M7 5h9a4 4 0 0 1 0 8H8a3 3 0 0 0 0 6h9\"/>"});
    for(const [name,source] of Object.entries({"cog": "settings", "file": "file-text", "file-badge": "file-text", "file-stack": "layers", "file-x-2": "file-text", "contact-round": "users-round", "contact": "user", "user-round": "user", "briefcase-business": "briefcase", "clock": "clock-3", "calendar": "calendar-days", "mails": "mail", "user-check": "badge-check", "user-x": "user", "shield-check": "badge-check", "tag": "file-text", "history": "clock-3", "search-check": "search", "scan-text": "file-search", "stamp": "badge-check", "package-check": "package", "package-search": "package", "locate-fixed": "map-pin", "graduation-cap": "briefcase"}))paths[name]=paths[source];
    window.lucide = {createIcons() {
      document.querySelectorAll('i[data-lucide]').forEach(icon=>{
        const name=icon.getAttribute('data-lucide');if(!paths[name])return;
        const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');
        for(const [key,value] of Object.entries({viewBox:'0 0 24 24',width:'24',height:'24',fill:'none',stroke:'currentColor','stroke-width':'1.7','stroke-linecap':'round','stroke-linejoin':'round','aria-hidden':'true',focusable:'false',class:`lucide lucide-${name} ${icon.className||''}`}))svg.setAttribute(key,value);
        svg.innerHTML=paths[name];icon.replaceWith(svg);
      });
    }};
  }
  function init() {
    if (!document.body.classList.contains('user-refresh')) return;
    window.lucide?.createIcons?.();
    // The supplied folder relies on seals in its parent project. Keep a generic
    // letter mark if a seal is unavailable, while retaining the original image URL.
    document.querySelectorAll('.public-seal img,.sidebar-logo img').forEach(img=>{
      const fallback=()=>{
        if(img.parentElement.querySelector('.brand-image-fallback'))return;
        img.hidden=true;
        const mark=document.createElement('span');mark.className='brand-image-fallback';mark.setAttribute('role','img');mark.setAttribute('aria-label','PGENRO IMS');
        mark.textContent='P';
        img.parentElement.append(mark);
      };
      img.addEventListener('error',fallback,{once:true});if(img.complete&&!img.naturalWidth)fallback();
    });
  }

  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})();
