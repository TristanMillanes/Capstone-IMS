  /*
  * PGENRO IMS — Supabase data service for admin modules.
  *
  * All storage operations are routed through the single Supabase client created by
  * ../shared/supabase.js.
  * It intentionally does NOT create a second Supabase client.
  */
  (() => {
    "use strict";

    if (
      window.PGENRO_SUPABASE_STORE &&
      window.PGENRO_SUPABASE_STORE.__pgenroSupabaseStore
    ) {
      return;
    }

    const sb = window.pgenroSupabase || window.PGENRO_DB?.client || null;

    if (!sb) {
      console.warn(
        "PGENRO IMS: Supabase data service could not start because the shared Supabase client is unavailable."
      );
      return;
    }

    const TABLE_ALIASES = {
      users: "profiles"
    };

    const wrappedCache = new Map();
    const channelRegistry = new Set();

    const tableName = (name) => TABLE_ALIASES[name] || name;

    const uuid = () =>
      globalThis.crypto?.randomUUID?.() ||
      `local-${Date.now()}-${Math.random().toString(36).slice(2)}`;

    function normalizeValue(value) {
      if (value instanceof Date) {
        return value.toISOString();
      }

      if (Array.isArray(value)) {
        return value.map(normalizeValue);
      }

      if (value && typeof value === "object") {
        const output = {};

        for (const [key, item] of Object.entries(value)) {
          output[key] = normalizeValue(item);
        }

        return output;
      }

      return value;
    }

    function unwrapRow(row) {
      if (!row || typeof row !== "object") {
        return row;
      }

      if (
        row.data &&
        typeof row.data === "object" &&
        !Array.isArray(row.data)
      ) {
        return {
          ...row.data,
          id: row.id ?? row.data.id,
          created_at: row.created_at ?? row.data.created_at,
          updated_at: row.updated_at ?? row.data.updated_at
        };
      }

      return { ...row };
    }

    async function isWrappedTable(rawName) {
      const name = tableName(rawName);

      if (wrappedCache.has(name)) {
        return wrappedCache.get(name);
      }

      try {
        const { error } = await sb.from(name).select("data").limit(1);
        const wrapped = !error;

        wrappedCache.set(name, wrapped);
        return wrapped;
      } catch {
        wrappedCache.set(name, false);
        return false;
      }
    }

    async function readRows(rawName, order = null) {
      const name = tableName(rawName);
      let query = sb.from(name).select("*");

      if (order?.field && order.field.includes("_")) {
        query = query.order(order.field, {
          ascending: order.direction !== "desc"
        });
      }

      const { data, error } = await query;

      if (error) {
        throw error;
      }

      let rows = (data || []).map(unwrapRow);

      if (order?.field) {
        const direction = order.direction === "desc" ? -1 : 1;

        rows = rows.sort((first, second) => {
          const firstValue = first?.[order.field];
          const secondValue = second?.[order.field];

          const firstDate = new Date(firstValue).getTime();
          const secondDate = new Date(secondValue).getTime();

          if (
            !Number.isNaN(firstDate) &&
            !Number.isNaN(secondDate)
          ) {
            return (firstDate - secondDate) * direction;
          }

          return (
            String(firstValue ?? "").localeCompare(
              String(secondValue ?? "")
            ) * direction
          );
        });
      }

      return rows;
    }

    async function insertRow(rawName, payload, forcedId = null) {
      const name = tableName(rawName);
      const clean = normalizeValue(payload || {});
      const wrapped = await isWrappedTable(name);

      if (wrapped) {
        const row = forcedId
          ? { id: forcedId, data: clean }
          : { data: clean };

        let response = await sb
          .from(name)
          .insert(row)
          .select("*")
          .single();

        if (response.error && forcedId) {
          response = await sb
            .from(name)
            .insert({ data: clean })
            .select("*")
            .single();
        }

        if (response.error) {
          throw response.error;
        }

        return unwrapRow(response.data);
      }

      const direct = forcedId
        ? { id: forcedId, ...clean }
        : clean;

      const { data, error } = await sb
        .from(name)
        .insert(direct)
        .select("*")
        .single();

      if (error) {
        throw error;
      }

      return unwrapRow(data);
    }

    async function getRow(rawName, id) {
      const name = tableName(rawName);

      const { data, error } = await sb
        .from(name)
        .select("*")
        .eq("id", id)
        .maybeSingle();

      if (error) {
        throw error;
      }

      return data ? unwrapRow(data) : null;
    }

    async function updateRow(rawName, id, patch, merge = true) {
      const name = tableName(rawName);
      const clean = normalizeValue(patch || {});
      const wrapped = await isWrappedTable(name);

      if (wrapped) {
        let next = clean;

        if (merge) {
          const current = await getRow(name, id);

          next = {
            ...(current || {}),
            ...clean
          };

          delete next.id;
          delete next.created_at;
          delete next.updated_at;
        }

        const { data, error } = await sb
          .from(name)
          .update({ data: next })
          .eq("id", id)
          .select("*")
          .maybeSingle();

        if (error) {
          throw error;
        }

        return data ? unwrapRow(data) : { id, ...next };
      }

      const { data, error } = await sb
        .from(name)
        .update(clean)
        .eq("id", id)
        .select("*")
        .maybeSingle();

      if (error) {
        throw error;
      }

      return data ? unwrapRow(data) : { id, ...clean };
    }

    async function setRow(rawName, id, payload, merge = false) {
      const name = tableName(rawName);
      const clean = normalizeValue(payload || {});
      const wrapped = await isWrappedTable(name);

      if (wrapped) {
        let next = clean;

        if (merge) {
          const current = await getRow(name, id);

          next = {
            ...(current || {}),
            ...clean
          };

          delete next.id;
          delete next.created_at;
          delete next.updated_at;
        }

        let response = await sb
          .from(name)
          .upsert(
            {
              id,
              data: next
            },
            {
              onConflict: "id"
            }
          )
          .select("*")
          .maybeSingle();

        if (response.error) {
          const existing = await getRow(name, id).catch(() => null);

          if (existing) {
            return updateRow(name, id, clean, merge);
          }

          return insertRow(name, clean);
        }

        return response.data
          ? unwrapRow(response.data)
          : { id, ...next };
      }

      if (merge) {
        const existing = await getRow(name, id).catch(() => null);

        if (existing) {
          return updateRow(name, id, clean, true);
        }
      }

      const { data, error } = await sb
        .from(name)
        .upsert(
          {
            id,
            ...clean
          },
          {
            onConflict: "id"
          }
        )
        .select("*")
        .maybeSingle();

      if (error) {
        throw error;
      }

      return data ? unwrapRow(data) : { id, ...clean };
    }

    async function deleteRow(rawName, id) {
      const name = tableName(rawName);

      const { error } = await sb
        .from(name)
        .delete()
        .eq("id", id);

      if (error) {
        throw error;
      }
    }

    function makeTableStoreSnapshot(rows) {
      const docs = (rows || []).map((row) => ({
        id: String(row.id ?? ""),
        data: () => {
          const data = { ...row };
          delete data.id;
          return data;
        }
      }));

      return {
        docs,
        empty: docs.length === 0,
        size: docs.length,
        forEach(callback) {
          docs.forEach(callback);
        }
      };
    }

    function subscribeTable(
      rawName,
      callback,
      errorCallback,
      order = null
    ) {
      const name = tableName(rawName);
      let active = true;

      const refresh = async () => {
        if (!active) {
          return;
        }

        try {
          const rows = await readRows(name, order);

          if (active) {
            callback(rows);
          }
        } catch (error) {
          if (active) {
            errorCallback?.(error);
          }
        }
      };

      refresh();

      const channel = sb
        .channel(`supabase-store-${name}-${uuid()}`)
        .on(
          "postgres_changes",
          {
            event: "*",
            schema: "public",
            table: name
          },
          refresh
        )
        .subscribe();

      channelRegistry.add(channel);

      return () => {
        active = false;
        channelRegistry.delete(channel);

        try {
          sb.removeChannel(channel);
        } catch {}
      };
    }

    class TableStoreQuery {
      constructor(name, order = null) {
        this.name = name;
        this.order = order;
      }

      orderBy(field, direction = "asc") {
        return new TableStoreQuery(this.name, {
          field,
          direction
        });
      }

      onSnapshot(next, error) {
        return subscribeTable(
          this.name,
          (rows) => next(makeTableStoreSnapshot(rows)),
          error,
          this.order
        );
      }

      async get() {
        const rows = await readRows(this.name, this.order);
        return makeTableStoreSnapshot(rows);
      }
    }

    class TableStoreDocumentRef {
      constructor(name, id) {
        this.name = name;
        this.id = String(id);
      }

      async set(payload, options = {}) {
        return setRow(
          this.name,
          this.id,
          payload,
          Boolean(options.merge)
        );
      }

      async update(payload) {
        return updateRow(
          this.name,
          this.id,
          payload,
          true
        );
      }

      async delete() {
        return deleteRow(this.name, this.id);
      }

      async get() {
        const row = await getRow(this.name, this.id);

        return {
          id: this.id,
          exists: Boolean(row),
          data: () => {
            if (!row) {
              return undefined;
            }

            const data = { ...row };
            delete data.id;

            return data;
          }
        };
      }
    }

    class TableStoreCollectionRef extends TableStoreQuery {
      constructor(name) {
        super(name, null);
        this.name = name;
      }

      doc(id = uuid()) {
        return new TableStoreDocumentRef(this.name, id);
      }

      async add(payload) {
        const row = await insertRow(this.name, payload);

        return new TableStoreDocumentRef(
          this.name,
          row.id || uuid()
        );
      }
    }

    function makeValueSnapshot(value) {
      return {
        val: () => value,
        exists: () =>
          value !== null &&
          value !== undefined &&
          !(
            typeof value === "object" &&
            Object.keys(value).length === 0
          )
      };
    }

    class RealtimeRef {
      constructor(path = "") {
        this.path = String(path || "").replace(
          /^\/+|\/+$/g,
          ""
        );

        this._unsubs = [];
        this.key =
          this.path.split("/").filter(Boolean).pop() || null;
      }

      _parts() {
        return this.path.split("/").filter(Boolean);
      }

      child(childPath) {
        const child = String(childPath || "").replace(
          /^\/+|\/+$/g,
          ""
        );

        return new RealtimeRef(
          [this.path, child].filter(Boolean).join("/")
        );
      }

      push(value) {
        const child = this.child(uuid());

        if (value !== undefined) {
          child.set(value).catch(console.error);
        }

        return child;
      }

      async _read() {
        if (this.path === ".info/connected") {
          return Boolean(navigator.onLine);
        }

        const [rawTable, id] = this._parts();

        if (!rawTable) {
          return null;
        }

        const name = tableName(rawTable);

        if (id) {
          return getRow(name, id);
        }

        const rows = await readRows(name);

        return Object.fromEntries(
          rows.map((row, index) => {
            const key = String(
              row.id ??
              row.user_id ??
              index
            );

            const value = { ...row };
            delete value.id;

            return [key, value];
          })
        );
      }

      async once(eventName) {
        if (eventName !== "value") {
          throw new Error(
            `Unsupported Supabase store event: ${eventName}`
          );
        }

        return makeValueSnapshot(await this._read());
      }

      on(eventName, callback, errorCallback) {
        if (eventName !== "value") {
          return callback;
        }

        if (this.path === ".info/connected") {
          const emit = () => {
            callback(
              makeValueSnapshot(Boolean(navigator.onLine))
            );
          };

          emit();

          addEventListener("online", emit);
          addEventListener("offline", emit);

          const unsubscribe = () => {
            removeEventListener("online", emit);
            removeEventListener("offline", emit);
          };

          this._unsubs.push(unsubscribe);

          return callback;
        }

        const [rawTable] = this._parts();

        if (!rawTable) {
          return callback;
        }

        const name = tableName(rawTable);
        let active = true;

        const refresh = async () => {
          if (!active) {
            return;
          }

          try {
            callback(
              makeValueSnapshot(await this._read())
            );
          } catch (error) {
            errorCallback?.(error);
          }
        };

        refresh();

        const channel = sb
          .channel(`supabase-realtime-${name}-${uuid()}`)
          .on(
            "postgres_changes",
            {
              event: "*",
              schema: "public",
              table: name
            },
            refresh
          )
          .subscribe();

        channelRegistry.add(channel);

        const unsubscribe = () => {
          active = false;
          channelRegistry.delete(channel);

          try {
            sb.removeChannel(channel);
          } catch {}
        };

        this._unsubs.push(unsubscribe);

        return callback;
      }

      off() {
        this._unsubs.splice(0).forEach((unsubscribe) => {
          try {
            unsubscribe();
          } catch {}
        });
      }

      async set(value) {
        const [rawTable, id] = this._parts();

        if (!rawTable || !id) {
          throw new Error(
            "Supabase store set() requires a table/id path."
          );
        }

        return setRow(rawTable, id, value, false);
      }

      async update(value) {
        const [rawTable, id] = this._parts();

        if (!rawTable || !id) {
          throw new Error(
            "Supabase store update() requires a table/id path."
          );
        }

        return updateRow(rawTable, id, value, true);
      }

      async remove() {
        const [rawTable, id] = this._parts();

        if (!rawTable || !id) {
          throw new Error(
            "Supabase remove() requires a table/id path."
          );
        }

        return deleteRow(rawTable, id);
      }
    }

    const authApi = {
      currentUser: null,

      onAuthStateChanged(callback) {
        let active = true;

        sb.auth
          .getSession()
          .then(({ data }) => {
            const user = data?.session?.user || null;
            authApi.currentUser = user;

            if (active) {
              callback(user);
            }
          })
          .catch(() => {
            if (active) {
              callback(null);
            }
          });

        const { data } = sb.auth.onAuthStateChange(
          (_event, session) => {
            authApi.currentUser =
              session?.user || null;

            if (active) {
              callback(authApi.currentUser);
            }
          }
        );

        return () => {
          active = false;

          try {
            data?.subscription?.unsubscribe?.();
          } catch {}
        };
      },

      signOut() {
        return sb.auth.signOut();
      }
    };

    const tableStore = () => ({
      collection(name) {
        return new TableStoreCollectionRef(name);
      }
    });

    tableStore.FieldValue = {
      serverTimestamp: () => new Date().toISOString()
    };

    const realtimeStore = () => ({
      ref(path = "") {
        return new RealtimeRef(path);
      }
    });

    realtimeStore.ServerValue = {};

    Object.defineProperty(
      realtimeStore.ServerValue,
      "TIMESTAMP",
      {
        enumerable: true,
        get: () => Date.now()
      }
    );

    const supabaseStoreAdapter = {
      __pgenroSupabaseStore: true,
      clients: [
        {
          name: "[PGENRO-SUPABASE]"
        }
      ],

      connect() {
        return supabaseStoreAdapter.clients[0];
      },

      auth: () => authApi,
      realtimeStore,
      tableStore
    };

    window.PGENRO_SUPABASE_STORE =
      supabaseStoreAdapter;

    window.PGENRO_SUPABASE_STORE_INFO = {
      client: sb,

      shutdown() {
        for (const channel of [...channelRegistry]) {
          try {
            sb.removeChannel(channel);
          } catch {}
        }

        channelRegistry.clear();
      }
    };
  })();

  /* ========================================================================== */
  /* ADMIN DASHBOARD PAGE                                                       */
  /* ========================================================================== */

  const supabaseStore =
    window.PGENRO_SUPABASE_STORE;

  document.addEventListener("DOMContentLoaded", () => {
    if (window.lucide) {
      window.lucide.createIcons();
    }

    const $ = (id) =>
      document.getElementById(id);

    const safeJson = (raw, fallback = []) => {
      try {
        return JSON.parse(raw) ?? fallback;
      } catch {
        return fallback;
      }
    };

    const arrFromObject = (value) => {
      if (Array.isArray(value)) {
        return value;
      }

      if (
        value &&
        typeof value === "object"
      ) {
        return Object.entries(value).map(
          ([id, item]) => ({
            id,
            ...(item || {})
          })
        );
      }

      return [];
    };

    const escapeHTML = (value) =>
      String(value ?? "").replace(
        /[&<>'"]/g,
        (character) =>
          ({
            "&": "&amp;",
            "<": "&lt;",
            ">": "&gt;",
            "'": "&#39;",
            '"': "&quot;"
          })[character]
      );

    const setText = (id, value) => {
      const element = $(id);

      if (!element) {
        return;
      }

      element.textContent =
        Number.isFinite(Number(value))
          ? Number(value).toLocaleString()
          : String(value ?? "");
    };

    const supabaseStoreConfig = {};

    let db = null;
    let currentAuthLogs = [];
    let remoteAuthLogs = [];
    let localAuditLogs = [];
    let memos = [];

    const auditLocalKey =
      "pgenro_audit_log_fallback";

    let stats = {
      communications: 0,
      travel: 0,
      memos: 0,
      employees: 0,
      inventory: 0,
      visitors: 0,
      services: 0,
      ics: 0,
      users: 0,
      requests: 0,
      lowStock: 0,

      serviceStatus: {
        completed: 0,
        progress: 0,
        pending: 0,
        archived: 0
      },

      monthlyMemos: Array(12).fill(0),
      monthlyComms: Array(12).fill(0),
      monthlyIcs: Array(12).fill(0)
    };

    function updateProfile(profile = {}) {
      const name =
        profile.fullName ||
        profile.name ||
        profile.displayName ||
        "PGENRO Admin";

      const email =
        profile.email ||
        "Administrator Session";

      const role =
        profile.role ||
        "System Administrator";

      if ($("currentUserName")) {
        $("currentUserName").textContent = name;
      }

      if ($("currentUserRole")) {
        $("currentUserRole").textContent = role;
      }

      if ($("dropdownUserName")) {
        $("dropdownUserName").textContent = name;
      }

      if ($("dropdownUserEmail")) {
        $("dropdownUserEmail").textContent = email;
      }

      if ($("dropdownUserRole")) {
        $("dropdownUserRole").textContent = role;
      }
    }

    let localProfile = safeJson(
      localStorage.getItem(
        "pgenro_current_user"
      ),
      null
    );

    if (
      localProfile &&
      typeof localProfile === "object"
    ) {
      updateProfile(localProfile);
    }

    /* ======================================================================== */
    /* AUDIT LOG                                                               */
    /* ======================================================================== */

    function auditDate(log) {
      const raw =
        log?.timestamp ||
        log?.createdAt ||
        log?.created_at ||
        log?.date ||
        0;

      const date = raw?.toDate
        ? raw.toDate()
        : new Date(raw);

      return Number.isNaN(date.getTime())
        ? new Date(0)
        : date;
    }

    function auditKey(log) {
      return String(
        log?.eventId ||
        log?.event_id ||
        log?.id ||
        [
          auditDate(log).toISOString(),
          log?.userEmail ||
            log?.email ||
            log?.emailMasked ||
            "",
          log?.activity ||
            log?.action ||
            "",
          log?.details ||
            log?.description ||
            ""
        ].join("|")
      );
    }

    function loadLocalAuditLogs() {
      localAuditLogs = safeJson(
        localStorage.getItem(auditLocalKey),
        []
      );

      if (!Array.isArray(localAuditLogs)) {
        localAuditLogs = [];
      }
    }

    function saveLocalAuditLogs() {
      try {
        localStorage.setItem(
          auditLocalKey,
          JSON.stringify(
            localAuditLogs.slice(0, 250)
          )
        );
      } catch (error) {
        console.warn(
          "PGENRO IMS: local audit fallback is unavailable.",
          error
        );
      }
    }

    function refreshAuditLogs() {
      const unique = new Map();

      [...remoteAuthLogs, ...localAuditLogs]
        .sort(
          (first, second) =>
            auditDate(second) - auditDate(first)
        )
        .forEach((log) => {
          const key = auditKey(log);

          if (!unique.has(key)) {
            unique.set(key, log);
          }
        });

      currentAuthLogs = [
        ...unique.values()
      ].slice(0, 500);

      applyAuditFilters();
    }

    async function auditIdentity() {
      const profile =
        safeJson(
          localStorage.getItem(
            "pgenro_current_user"
          ),
          localProfile || {}
        ) || {};

      let user = null;

      try {
        const client =
          window.pgenroSupabase ||
          window.PGENRO_DB?.client;

        const result =
          await client?.auth?.getSession?.();

        user =
          result?.data?.session?.user ||
          null;
      } catch {}

      const metadata =
        user?.user_metadata || {};

      return {
        userId:
          user?.id ||
          profile.id ||
          profile.userId ||
          null,

        userEmail:
          user?.email ||
          profile.email ||
          "Protected account",

        userName:
          metadata.full_name ||
          metadata.name ||
          profile.fullName ||
          profile.name ||
          profile.displayName ||
          "PGENRO User",

        role:
          profile.role ||
          metadata.role ||
          "Administrator"
      };
    }

    async function logAudit(
      action,
      details,
      options = {}
    ) {
      const identity =
        await auditIdentity();

      const eventId =
        globalThis.crypto?.randomUUID?.() ||
        `audit-${Date.now()}-${Math.random()
          .toString(36)
          .slice(2)}`;

      const timestamp =
        new Date().toISOString();

      const normalizedAction = String(
        action || "SYSTEM_ACTIVITY"
      )
        .trim()
        .toUpperCase()
        .replace(/\s+/g, "_");

      const record = {
        eventId,
        timestamp,
        createdAt: timestamp,
        ...identity,
        activity: normalizedAction,
        action: normalizedAction,

        actionType:
          normalizedAction === "LOGIN"
            ? "login"
            : normalizedAction === "LOGOUT"
              ? "logout"
              : "activity",

        module:
          options.module ||
          document.title ||
          "PGENRO IMS",

        details: String(
          details ||
          "System activity recorded."
        ),

        page:
          location.pathname
            .split("/")
            .pop() ||
          "admin.html",

        ipAddress:
          options.ipAddress ||
          "Client session",

        sessionStatus:
          options.status ||
          "Success",

        status:
          options.status ||
          "Success"
      };

      localAuditLogs.unshift(record);
      localAuditLogs =
        localAuditLogs.slice(0, 250);

      saveLocalAuditLogs();
      refreshAuditLogs();

      try {
        const auditDb =
          db ||
          window.PGENRO_SUPABASE_STORE
            ?.realtimeStore?.();

        if (auditDb) {
          await auditDb
            .ref(`audit_logs/${eventId}`)
            .set(record);
        }
      } catch (error) {
        console.warn(
          "PGENRO IMS: audit event retained locally because cloud logging failed.",
          error
        );
      }

      return record;
    }

    window.PGENRO_AUDIT = {
      log: logAudit,
      refresh: refreshAuditLogs
    };

    /* ======================================================================== */
    /* CHARTS                                                                  */
    /* ======================================================================== */

    let monthlyChart;
    let categoryChart;
    let statusChart;

    function initCharts() {
      if (!window.Chart) {
        return;
      }

      const monthlyContext =
        $("monthlyChart")?.getContext("2d");

      if (monthlyContext) {
        monthlyChart = new Chart(
          monthlyContext,
          {
            type: "line",

            data: {
              labels: [
                "Jan",
                "Feb",
                "Mar",
                "Apr",
                "May",
                "Jun",
                "Jul",
                "Aug",
                "Sep",
                "Oct",
                "Nov",
                "Dec"
              ],

              datasets: [
                {
                  label: "Memos",
                  data: stats.monthlyMemos,
                  borderColor: "#059669",
                  backgroundColor:
                    "rgba(5,150,105,.08)",
                  tension: 0.35
                },
                {
                  label: "Communications",
                  data: stats.monthlyComms,
                  borderColor: "#2563eb",
                  backgroundColor:
                    "rgba(37,99,235,.08)",
                  tension: 0.35
                },
                {
                  label: "ICS",
                  data: stats.monthlyIcs,
                  borderColor: "#7c3aed",
                  backgroundColor:
                    "rgba(124,58,237,.08)",
                  tension: 0.35
                }
              ]
            },

            options: {
              responsive: true,
              maintainAspectRatio: false,

              plugins: {
                legend: {
                  position: "bottom"
                }
              },

              scales: {
                y: {
                  beginAtZero: true
                }
              }
            }
          }
        );
      }

      const categoryContext =
        $("categoryChart")?.getContext("2d");

      if (categoryContext) {
        categoryChart = new Chart(
          categoryContext,
          {
            type: "doughnut",

            data: {
              labels: [
                "Documents",
                "Travel",
                "Employees",
                "Visitors",
                "Inventory",
                "Services"
              ],

              datasets: [
                {
                  data: [0, 0, 0, 0, 0, 0],
                  backgroundColor: [
                    "#059669",
                    "#2563eb",
                    "#7c3aed",
                    "#f59e0b",
                    "#0ea5e9",
                    "#e11d48"
                  ],
                  borderWidth: 0
                }
              ]
            },

            options: {
              responsive: true,
              maintainAspectRatio: false,
              cutout: "68%",

              plugins: {
                legend: {
                  position: "bottom"
                }
              }
            }
          }
        );
      }

      const statusContext =
        $("statusChart")?.getContext("2d");

      if (statusContext) {
        statusChart = new Chart(
          statusContext,
          {
            type: "bar",

            data: {
              labels: [
                "Completed",
                "In Progress",
                "Pending",
                "Archived"
              ],

              datasets: [
                {
                  label: "Requests",
                  data: [0, 0, 0, 0],
                  backgroundColor: [
                    "#059669",
                    "#2563eb",
                    "#f59e0b",
                    "#94a3b8"
                  ],
                  borderRadius: 6
                }
              ]
            },

            options: {
              responsive: true,
              maintainAspectRatio: false,

              plugins: {
                legend: {
                  display: false
                }
              },

              scales: {
                y: {
                  beginAtZero: true
                }
              }
            }
          }
        );
      }
    }

    function monthBuckets(list) {
      const output =
        Array(12).fill(0);

      list.forEach((item) => {
        const raw =
          item.createdAt ||
          item.created_at ||
          item.timestamp ||
          item.date ||
          item.dateIssued ||
          item.issueDate;

        const date = raw?.toDate
          ? raw.toDate()
          : new Date(raw);

        if (!Number.isNaN(date.getTime())) {
          output[date.getMonth()]++;
        }
      });

      return output;
    }

    function updateCharts() {
      if (monthlyChart) {
        monthlyChart.data.datasets[0].data =
          stats.monthlyMemos;

        monthlyChart.data.datasets[1].data =
          stats.monthlyComms;

        monthlyChart.data.datasets[2].data =
          stats.monthlyIcs;

        monthlyChart.update();
      }

      if (categoryChart) {
        categoryChart.data.datasets[0].data = [
          stats.memos + stats.communications,
          stats.travel,
          stats.employees,
          stats.visitors,
          stats.inventory,
          stats.services
        ];

        categoryChart.update();
      }

      if (statusChart) {
        const service = stats.serviceStatus;

        statusChart.data.datasets[0].data = [
          service.completed,
          service.progress,
          service.pending,
          service.archived
        ];

        statusChart.update();
      }
    }

    /* ======================================================================== */
    /* LOCAL MODULE STATISTICS                                                  */
    /* ======================================================================== */

    function firstLocalArray(keys) {
      for (const key of keys) {
        const value = safeJson(
          localStorage.getItem(key),
          null
        );

        if (
          value &&
          (
            Array.isArray(value) ||
            typeof value === "object"
          )
        ) {
          return arrFromObject(value);
        }
      }

      return [];
    }

    function refreshLocalStats() {
      const communications =
        firstLocalArray([
          "communicationRecords"
        ]);

      const travel =
        firstLocalArray([
          "pgenro_admin_travel_orders",
          "travelOrders"
        ]);

      const employees =
        firstLocalArray([
          "pgenro_admin_employees",
          "employees"
        ]);

      const inventory =
        firstLocalArray([
          "pgenro_admin_inventory",
          "inventoryRecords"
        ]);

      const localMemos =
        firstLocalArray([
          "pgenro_office_memos",
          "officeMemos"
        ]);

      const ics =
        firstLocalArray([
          "pgenro_ics_records",
          "icsRecords"
        ]);

      stats.communications =
        communications.length;

      stats.travel =
        travel.length;

      stats.employees = Math.max(
        stats.employees,
        employees.length
      );

      stats.inventory =
        inventory.length;

      stats.ics =
        ics.length;

      if (localMemos.length) {
        memos = localMemos;
        stats.memos = localMemos.length;
        stats.monthlyMemos =
          monthBuckets(localMemos);

        renderMemoStream(memos);
      }

      stats.monthlyComms =
        monthBuckets(communications);

      stats.monthlyIcs =
        monthBuckets(ics);

      stats.lowStock =
        inventory.filter((item) => {
          const quantity = Number(
            item.quantity ??
            item.qty ??
            item.stock ??
            0
          );

          const threshold = Number(
            item.threshold ??
            item.reorderLevel ??
            item.minimumStock ??
            10
          );

          return quantity <= threshold;
        }).length;

      updateUI();
    }

    function updateUI() {
      setText(
        "kpiPersonnel",
        stats.employees
      );

      setText(
        "kpiPendingAcc",
        stats.requests
      );

      setText(
        "kpiActiveICS",
        stats.ics
      );

      setText(
        "kpiLowStock",
        stats.lowStock
      );

      const values = {
        modCommCount:
          stats.communications,

        modTravelCount:
          stats.travel,

        modMemoCount:
          stats.memos,

        modEmployeeCount:
          stats.employees,

        modInventoryCount:
          stats.inventory,

        modVisitorCount:
          stats.visitors,

        modServiceCount:
          stats.services,

        modIcsCount:
          stats.ics,

        modUserCount:
          stats.users,

        modRequestCount:
          stats.requests
      };

      Object.entries(values).forEach(
        ([id, value]) => {
          setText(id, value);
        }
      );

      if ($("sidebarPendingAccBadge")) {
        $("sidebarPendingAccBadge").textContent =
          `${stats.requests} New`;
      }

      const open =
        stats.serviceStatus.pending +
        stats.serviceStatus.progress;

      if ($("sidebarOpenServicesBadge")) {
        $("sidebarOpenServicesBadge").textContent =
          `${open} Open`;
      }

      updateCharts();
    }

    /* ======================================================================== */
    /* SUPABASE LIVE DATA                                                       */
    /* ======================================================================== */

    function setDbStatus(ok, text) {
      const dot = $("dbStatusDot");
      const label = $("dbStatusText");

      if (dot) {
        dot.className =
          `status-dot ${
            ok ? "online" : "offline"
          }`;
      }

      if (label) {
        label.textContent = text;
      }
    }

    function subscribe(path, handler) {
      if (!db) {
        return;
      }

      db.ref(path).on(
        "value",

        (snapshot) => {
          handler(
            arrFromObject(
              snapshot.val() || {}
            )
          );
        },

        (error) => {
          console.warn(
            `Supabase table ${path} unavailable`,
            error
          );

          setDbStatus(
            false,
            "Cloud sync unavailable / local mode"
          );
        }
      );
    }

    function initSupabase() {
      try {
        if (!window.PGENRO_SUPABASE_STORE) {
          throw new Error(
            "Supabase SDK unavailable"
          );
        }

        if (!supabaseStore.clients.length) {
          supabaseStore.connect(
            supabaseStoreConfig
          );
        }

        db =
          supabaseStore.realtimeStore();

        db.ref(".info/connected").on(
          "value",
          (snapshot) => {
            setDbStatus(
              Boolean(snapshot.val()),
              snapshot.val()
                ? "Supabase Live"
                : "Offline / reconnecting"
            );
          }
        );

        if (supabaseStore.auth) {
          supabaseStore
            .auth()
            .onAuthStateChanged((user) => {
              if (!user) {
                return;
              }

              updateProfile({
                displayName:
                  user.user_metadata?.full_name ||
                  user.user_metadata?.name,

                email: user.email,

                role:
                  localProfile?.role ||
                  "Administrator"
              });

              const loginMarker =
                `pgenro_audit_login_${user.id}`;

              if (
                !sessionStorage.getItem(
                  loginMarker
                )
              ) {
                sessionStorage.setItem(
                  loginMarker,
                  "1"
                );

                logAudit(
                  "LOGIN",
                  "Signed in and opened the administrator workspace.",
                  {
                    module: "Authentication"
                  }
                );
              }
            });
        }

        subscribe("users", (rows) => {
          stats.users = rows.length;

          if (rows.length) {
            stats.employees = Math.max(
              stats.employees,
              rows.length
            );
          }

          updateUI();
        });

        subscribe(
          "access_requests",
          (rows) => {
            stats.requests =
              rows.filter((request) =>
                String(
                  request.status ||
                  "Pending"
                ).toLowerCase() === "pending"
              ).length;

            renderNotifications(rows);
            updateUI();
          }
        );

        subscribe("visitors", (rows) => {
          stats.visitors = rows.length;
          updateUI();
        });

        subscribe(
          "service_requests",
          (rows) => {
            stats.services = rows.length;

            const count = {
              completed: 0,
              progress: 0,
              pending: 0,
              archived: 0
            };

            rows.forEach((request) => {
              const status = String(
                request.status ||
                request.serviceStatus ||
                "Pending Review"
              ).toLowerCase();

              if (
                status.includes("complete") ||
                status.includes("closed")
              ) {
                count.completed++;
              } else if (
                status.includes("progress") ||
                status.includes("processing")
              ) {
                count.progress++;
              } else if (
                status.includes("archive")
              ) {
                count.archived++;
              } else {
                count.pending++;
              }
            });

            stats.serviceStatus = count;
            updateUI();
          }
        );

        subscribe("audit_logs", (rows) => {
          remoteAuthLogs = rows
            .sort(
              (first, second) =>
                auditDate(second) -
                auditDate(first)
            )
            .slice(0, 500);

          refreshAuditLogs();
        });

        subscribe(
          "office_memos",
          (rows) => {
            if (!rows.length) {
              return;
            }

            memos = rows;
            stats.memos = rows.length;
            stats.monthlyMemos =
              monthBuckets(rows);

            renderMemoStream(rows);
            updateUI();
          }
        );

        subscribe(
          "communications",
          (rows) => {
            if (!rows.length) {
              return;
            }

            stats.communications =
              rows.length;

            stats.monthlyComms =
              monthBuckets(rows);

            updateUI();
          }
        );

        subscribe(
          "ics_records",
          (rows) => {
            if (!rows.length) {
              return;
            }

            stats.ics = rows.length;
            stats.monthlyIcs =
              monthBuckets(rows);

            updateUI();
          }
        );

        const liveTable = (
          table,
          handler
        ) => {
          const client =
            window.pgenroSupabase;

          if (!client) {
            return;
          }

          const load = async () => {
            const { data, error } =
              await client
                .from(table)
                .select("*");

            if (error) {
              console.warn(
                `Supabase ${table} unavailable`,
                error
              );

              return;
            }

            handler(data || []);
          };

          load();

          client
            .channel(
              `dashboard-${table}-${Math.random()
                .toString(36)
                .slice(2)}`
            )
            .on(
              "postgres_changes",
              {
                event: "*",
                schema: "public",
                table
              },
              load
            )
            .subscribe();
        };

        liveTable(
          "employees",
          (rows) => {
            stats.employees = rows.length;
            updateUI();
          }
        );

        liveTable(
          "travel_orders",
          (rows) => {
            stats.travel = rows.length;
            updateUI();
          }
        );

        liveTable(
          "inventory",
          (rows) => {
            stats.inventory = rows.length;

            stats.lowStock =
              rows.filter((item) =>
                Number(item.quantity || 0) <=
                Number(item.threshold || 0)
              ).length;

            updateUI();
          }
        );
      } catch (error) {
        console.warn(
          "Supabase dashboard fallback",
          error
        );

        setDbStatus(
          false,
          "Local module storage mode"
        );
      }
    }

    /* ======================================================================== */
    /* NOTIFICATIONS                                                            */
    /* ======================================================================== */

    function renderNotifications(requests) {
      const pending = requests.filter(
        (request) =>
          String(
            request.status || "Pending"
          ).toLowerCase() === "pending"
      );

      if ($("notifBadgeCount")) {
        $("notifBadgeCount").textContent =
          `${pending.length} Unread`;
      }

      if ($("notifPing")) {
        $("notifPing").style.display =
          pending.length
            ? "block"
            : "none";
      }

      const list =
        $("notificationList");

      if (!list) {
        return;
      }

      if (!pending.length) {
        list.innerHTML =
          '<div class="empty-notif-state">No new notifications</div>';

        return;
      }

      list.innerHTML = pending
        .slice(0, 5)
        .map(
          (request) => `
            <a href="requestacc.html" class="notification-item">
              <strong>
                ${escapeHTML(
                  request.fullName ||
                  request.name ||
                  "New applicant"
                )}
              </strong>

              <span>
                ${escapeHTML(
                  request.email ||
                  request.role ||
                  "Access request"
                )}
              </span>
            </a>
          `
        )
        .join("");
    }

    /* ======================================================================== */
    /* MEMO STREAM                                                              */
    /* ======================================================================== */

    function renderMemoStream(rows) {
      const box = $("memoStreamList");

      if (!box) {
        return;
      }

      setText(
        "memosTotalCountLabel",
        `${rows.length} Memos Recorded`
      );

      if (!rows.length) {
        box.innerHTML =
          '<div class="empty-table-cell">No memos recorded in database.</div>';

        return;
      }

      const sorted = [...rows].sort(
        (first, second) =>
          new Date(
            second.createdAt ||
            second.date ||
            0
          ) -
          new Date(
            first.createdAt ||
            first.date ||
            0
          )
      );

      box.innerHTML = sorted
        .slice(0, 5)
        .map(
          (memo) => `
            <div class="memo-stream-item">
              <div class="memo-stream-info">
                <span class="memo-stream-title">
                  ${escapeHTML(
                    memo.memoNo
                      ? `[${memo.memoNo}] `
                      : ""
                  )}
                  ${escapeHTML(
                    memo.title ||
                    memo.subject ||
                    "Office Memorandum"
                  )}
                </span>

                <span class="memo-stream-meta">
                  ${escapeHTML(
                    memo.issuedBy ||
                    memo.author ||
                    "PGENRO Admin"
                  )}
                </span>
              </div>

              <a
                href="officememo-admin.html"
                class="icon-btn-sm"
                title="Open memo administration"
              >
                <i data-lucide="external-link"></i>
              </a>
            </div>
          `
        )
        .join("");

      window.lucide?.createIcons?.();
    }

    /* ======================================================================== */
    /* SCROLLABLE AUDIT TABLE                                                   */
    /* ======================================================================== */

    function renderAuthLogs(logs) {
      const tbody =
        $("auditTableBody");

      const information =
        $("tablePaginationInfo");

      if (!tbody) {
        return;
      }

      if (!logs.length) {
        tbody.innerHTML = `
          <tr class="empty-row">
            <td
              colspan="8"
              class="empty-table-cell"
            >
              No matching user activity recorded yet.
            </td>
          </tr>
        `;

        if (information) {
          information.textContent =
            "Showing 0 of 0 log entries";
        }

        return;
      }

      tbody.innerHTML = logs
        .map((log) => {
          const date = auditDate(log);

          const action = String(
            log.activity ||
            log.action ||
            "SYSTEM_ACTIVITY"
          );

          const email =
            log.userEmail ||
            log.email ||
            log.emailMasked ||
            "Protected account";

          const name =
            log.userName ||
            email;

          const status = String(
            log.sessionStatus ||
            log.status ||
            "Success"
          );

          const successful =
            !/fail|error|denied|blocked/i.test(
              status
            );

          const details =
            log.details ||
            log.description ||
            log.message ||
            "System activity recorded.";

          const source =
            log.module ||
            log.page ||
            "PGENRO IMS";

          const type =
            log.actionType ||
            (
              /login/i.test(action)
                ? "login"
                : /logout/i.test(action)
                  ? "logout"
                  : "activity"
            );

          return `
            <tr data-audit-type="${escapeHTML(type)}">
              <td>
                <input
                  type="checkbox"
                  class="row-checkbox"
                  aria-label="Select audit record"
                >
              </td>

              <td class="text-muted">
                ${escapeHTML(
                  date.toLocaleString()
                )}
              </td>

              <td>
                <div class="user-cell">
                  <div class="avatar-sm">
                    ${escapeHTML(
                      String(name)
                        .slice(0, 2)
                        .toUpperCase()
                    )}
                  </div>

                  <div>
                    <strong>
                      ${escapeHTML(name)}
                    </strong>

                    <small>
                      ${escapeHTML(email)}
                    </small>
                  </div>
                </div>
              </td>

              <td>
                <span
                  class="badge-status ${
                    successful
                      ? "success"
                      : "urgent"
                  }"
                >
                  <span class="dot"></span>

                  ${escapeHTML(
                    action.replaceAll("_", " ")
                  )}
                </span>
              </td>

              <td class="audit-action-detail">
                ${escapeHTML(details)}

                <span class="audit-source">
                  ${escapeHTML(source)}
                </span>
              </td>

              <td>
                <span class="table-tag">
                  ${escapeHTML(
                    log.role ||
                    log.division ||
                    "PGENRO"
                  )}
                </span>
              </td>

              <td class="font-mono">
                ${escapeHTML(
                  log.ipAddress ||
                  "Client session"
                )}
              </td>

              <td>
                <span
                  class="badge-status ${
                    successful
                      ? "success"
                      : "urgent"
                  }"
                >
                  ${escapeHTML(status)}
                </span>
              </td>
            </tr>
          `;
        })
        .join("");

      if (information) {
        information.textContent =
          `Showing ${logs.length} of ${currentAuthLogs.length} log entries`;
      }

      window.lucide?.createIcons?.();
    }

    function applyAuditFilters() {
      const search = (
        $("tableSearchInput")?.value || ""
      )
        .toLowerCase()
        .trim();

      const type =
        $("auditTypeFilter")?.value ||
        "all";

      const filtered =
        currentAuthLogs.filter((log) => {
          const action = String(
            log.activity ||
            log.action ||
            ""
          );

          const logType =
            log.actionType ||
            (
              /login/i.test(action)
                ? "login"
                : /logout/i.test(action)
                  ? "logout"
                  : "activity"
            );

          const haystack = [
            auditDate(log).toLocaleString(),
            log.userName,
            log.userEmail,
            log.email,
            action,
            log.details,
            log.description,
            log.module,
            log.page,
            log.role,
            log.division,
            log.status,
            log.sessionStatus
          ]
            .join(" ")
            .toLowerCase();

          const matchesType =
            type === "all" ||
            type === logType;

          const matchesSearch =
            !search ||
            haystack.includes(search);

          return (
            matchesType &&
            matchesSearch
          );
        });

      renderAuthLogs(filtered);
    }

    $("tableSearchInput")
      ?.addEventListener(
        "input",
        applyAuditFilters
      );

    $("auditTypeFilter")
      ?.addEventListener(
        "change",
        applyAuditFilters
      );

    $("selectAllRows")
      ?.addEventListener(
        "change",
        (event) => {
          document
            .querySelectorAll(
              ".row-checkbox"
            )
            .forEach((checkbox) => {
              checkbox.checked =
                event.target.checked;
            });
        }
      );

    $("exportCsvBtn")
      ?.addEventListener(
        "click",
        () => {
          if (!currentAuthLogs.length) {
            alert(
              "No user activity logs available to export."
            );

            return;
          }

          const quote = (value) =>
            `"${String(value ?? "").replace(
              /"/g,
              '""'
            )}"`;

          const rows = [
            [
              "Timestamp",
              "Account",
              "Name",
              "Action",
              "Activity Details",
              "Module",
              "Role / Division",
              "IP Address",
              "Status"
            ]
              .map(quote)
              .join(","),

            ...currentAuthLogs.map(
              (log) =>
                [
                  auditDate(log).toISOString(),

                  log.userEmail ||
                    log.email ||
                    log.emailMasked ||
                    "",

                  log.userName || "",

                  log.activity ||
                    log.action ||
                    "",

                  log.details ||
                    log.description ||
                    "",

                  log.module ||
                    log.page ||
                    "",

                  log.role ||
                    log.division ||
                    "",

                  log.ipAddress ||
                    "Client session",

                  log.status ||
                    log.sessionStatus ||
                    ""
                ]
                  .map(quote)
                  .join(",")
            )
          ];

          downloadBlob(
            rows.join("\n"),
            `PGENRO_Complete_Audit_${
              new Date()
                .toISOString()
                .slice(0, 10)
            }.csv`,
            "text/csv;charset=utf-8"
          );

          logAudit(
            "EXPORT_AUDIT",
            "Exported the complete user activity audit trail as CSV.",
            {
              module:
                "Security Audit Trail"
            }
          );
        }
      );

    $("globalSearchInput")
      ?.addEventListener(
        "input",
        (event) => {
          const search =
            event.target.value
              .toLowerCase()
              .trim();

          document
            .querySelectorAll(
              ".module-control-card"
            )
            .forEach((card) => {
              card.style.display =
                !search ||
                card.textContent
                  .toLowerCase()
                  .includes(search)
                  ? ""
                  : "none";
            });
        }
      );

    function downloadBlob(
      content,
      name,
      type
    ) {
      const blob = new Blob(
        [content],
        { type }
      );

      const url =
        URL.createObjectURL(blob);

      const anchor =
        document.createElement("a");

      anchor.href = url;
      anchor.download = name;

      document.body.appendChild(anchor);
      anchor.click();
      anchor.remove();

      URL.revokeObjectURL(url);
    }

    /* ======================================================================== */
    /* BACKUP AND PREFERENCES                                                   */
    /* ======================================================================== */

    $("downloadLocalBackupBtn")
      ?.addEventListener(
        "click",
        () => {
          const data = {
            meta: {
              system: "PGENRO IMS",
              exportedAt:
                new Date().toISOString(),
              version: 2
            },

            localStorage: {}
          };

          for (
            let index = 0;
            index < localStorage.length;
            index++
          ) {
            const key =
              localStorage.key(index);

            if (
              key &&
              (
                key.startsWith("pgenro_") ||
                [
                  "communicationRecords",
                  "travelOrders",
                  "employees",
                  "inventoryRecords",
                  "officeMemos",
                  "icsRecords"
                ].includes(key)
              )
            ) {
              data.localStorage[key] =
                localStorage.getItem(key);
            }
          }

          downloadBlob(
            JSON.stringify(
              data,
              null,
              2
            ),
            `PGENRO_IMS_Local_Backup_${
              new Date()
                .toISOString()
                .slice(0, 10)
            }.json`,
            "application/json"
          );

          logAudit(
            "DOWNLOAD_BACKUP",
            "Downloaded a browser-side IMS backup file.",
            {
              module:
                "System Backup & Recovery"
            }
          );
        }
      );

    $("restoreBackupInput")
      ?.addEventListener(
        "change",
        async (event) => {
          const file =
            event.target.files?.[0];

          if (!file) {
            return;
          }

          try {
            const parsed = JSON.parse(
              await file.text()
            );

            if (
              !parsed.localStorage ||
              typeof parsed.localStorage !==
                "object"
            ) {
              throw new Error(
                "Invalid backup structure"
              );
            }

            const confirmed = confirm(
              "Restore this local IMS backup? Matching browser records will be replaced."
            );

            if (!confirmed) {
              event.target.value = "";
              return;
            }

            Object.entries(
              parsed.localStorage
            ).forEach(([key, value]) => {
              if (typeof value === "string") {
                localStorage.setItem(
                  key,
                  value
                );
              }
            });

            await logAudit(
              "RESTORE_BACKUP",
              `Restored the local backup file: ${file.name}.`,
              {
                module:
                  "System Backup & Recovery"
              }
            );

            alert(
              "Local backup restored successfully. The dashboard will refresh."
            );

            location.reload();
          } catch (error) {
            logAudit(
              "RESTORE_BACKUP_FAILED",
              `Could not restore backup: ${error.message}`,
              {
                module:
                  "System Backup & Recovery",
                status: "Failed"
              }
            );

            alert(
              `Unable to restore backup: ${error.message}`
            );
          } finally {
            event.target.value = "";
          }
        }
      );

    const preferenceKey =
      "pgenro_admin_preferences";

    function applyPreferences() {
      const preferences = safeJson(
        localStorage.getItem(
          preferenceKey
        ),
        {}
      );

      if ($("compactModeToggle")) {
        $("compactModeToggle").checked =
          Boolean(preferences.compact);
      }

      if ($("showDbStatusToggle")) {
        $("showDbStatusToggle").checked =
          preferences.showDb !== false;
      }

      document.body.classList.toggle(
        "compact-mode",
        Boolean(preferences.compact)
      );

      document.body.classList.toggle(
        "hide-db-status",
        preferences.showDb === false
      );
    }

    function savePreferences() {
      const preferences = {
        compact: Boolean(
          $("compactModeToggle")?.checked
        ),

        showDb:
          $("showDbStatusToggle")
            ?.checked !== false
      };

      localStorage.setItem(
        preferenceKey,
        JSON.stringify(preferences)
      );

      applyPreferences();

      logAudit(
        "SETTINGS_CHANGE",
        `Changed dashboard preferences: compact table ${
          preferences.compact
            ? "enabled"
            : "disabled"
        }; database status ${
          preferences.showDb
            ? "visible"
            : "hidden"
        }.`,
        {
          module:
            "Workspace Preferences"
        }
      );
    }

    $("compactModeToggle")
      ?.addEventListener(
        "change",
        savePreferences
      );

    $("showDbStatusToggle")
      ?.addEventListener(
        "change",
        savePreferences
      );

    $("resetAdminPrefsBtn")
      ?.addEventListener(
        "click",
        () => {
          localStorage.removeItem(
            preferenceKey
          );

          applyPreferences();

          logAudit(
            "SETTINGS_RESET",
            "Reset administrator dashboard preferences.",
            {
              module:
                "Workspace Preferences"
            }
          );
        }
      );

    applyPreferences();

    /* Track opened system modules. */
    document.addEventListener(
      "click",
      (event) => {
        const target =
          event.target instanceof Element
            ? event.target
            : null;

        if (!target) {
          return;
        }

        const link = target.closest(
          ".module-control-card, .sidebar .nav-item"
        );

        if (
          !link ||
          link
            .getAttribute("href")
            ?.startsWith("#")
        ) {
          return;
        }

        const label = (
          link.querySelector(
            "strong, span"
          )?.textContent ||
          link.textContent ||
          "System module"
        )
          .replace(/\s+/g, " ")
          .trim();

        logAudit(
          "OPEN_MODULE",
          `Opened ${label}.`,
          {
            module: label
          }
        );
      }
    );

    window.addEventListener(
      "storage",
      refreshLocalStats
    );

    document.addEventListener(
      "visibilitychange",
      () => {
        if (!document.hidden) {
          refreshLocalStats();
        }
      }
    );

    loadLocalAuditLogs();
    refreshAuditLogs();
    initCharts();
    refreshLocalStats();
    initSupabase();
    updateUI();
  });

  /* ========================================================================== */
  /* ADMIN SHELL CONTROLLER                                                     */
  /* ========================================================================== */

  (() => {
    "use strict";

    const $ = (
      selector,
      root = document
    ) => root.querySelector(selector);

    const $$ = (
      selector,
      root = document
    ) =>
      Array.from(
        root.querySelectorAll(selector)
      );

    const currentFile = (
      location.pathname
        .split("/")
        .pop() ||
      "admin.html"
    ).toLowerCase();

    function normalizePath(href) {
      if (
        !href ||
        href.startsWith("#") ||
        href.startsWith("javascript:")
      ) {
        return "";
      }

      try {
        const url =
          new URL(href, location.href);

        return (
          url.pathname
            .split("/")
            .pop() ||
          ""
        ).toLowerCase();
      } catch {
        return "";
      }
    }

    function fixNavigation() {
      const map = {
        "Security Audit Trail":
          "admin.html#audit",

        "System Backups":
          "admin.html#backup",

        "Global Settings":
          "admin.html#settings"
      };

      const links =
        $$(".sidebar a");

      links.forEach((link) => {
        const label = (
          link.textContent || ""
        )
          .replace(/\s+/g, " ")
          .trim();

        if (
          (
            !link.getAttribute("href") ||
            link.getAttribute("href") === "#"
          ) &&
          map[label]
        ) {
          link.setAttribute(
            "href",
            map[label]
          );
        }
      });

      let match = null;
      const currentHash =
        location.hash || "";

      for (const link of links) {
        const href =
          link.getAttribute("href") || "";

        if (
          !href ||
          href.startsWith("javascript:")
        ) {
          continue;
        }

        let url;

        try {
          url = new URL(
            href,
            location.href
          );
        } catch {
          continue;
        }

        const file = (
          url.pathname
            .split("/")
            .pop() ||
          ""
        ).toLowerCase();

        if (file !== currentFile) {
          continue;
        }

        if (
          currentFile === "admin.html"
        ) {
          if (
            url.hash &&
            url.hash === currentHash
          ) {
            match = link;
            break;
          }

          if (
            !url.hash &&
            (
              !currentHash ||
              currentHash === "#dashboard"
            )
          ) {
            match = link;
          }
        } else if (!url.hash) {
          match = link;
          break;
        }
      }

      if (match) {
        links.forEach((link) => {
          link.classList.toggle(
            "active",
            link === match
          );

          if (link === match) {
            link.setAttribute(
              "aria-current",
              "page"
            );
          } else {
            link.removeAttribute(
              "aria-current"
            );
          }
        });
      }
    }

    function cleanupDuplicateNavigation() {
      const seen = new Set();

      $$(".sidebar a").forEach(
        (link) => {
          const label = (
            link.textContent || ""
          )
            .replace(/\s+/g, " ")
            .trim()
            .toLowerCase();

          const href =
            link.getAttribute("href") || "";

          if (!label || !href) {
            return;
          }

          const key =
            `${href.toLowerCase()}|${label}`;

          if (!seen.has(key)) {
            seen.add(key);
            return;
          }

          const row =
            link.closest("li");

          (row || link).remove();
        }
      );
    }

    function setupUnifiedProfileMenu() {
      const menu =
        $("#profileMenu");

      const button =
        $("#profileBtn");

      const dropdown =
        $("#profileDropdown");

      const notificationsButton =
        $("#notificationsBtn");

      const notificationsDropdown =
        $("#notificationDropdown");

      if (
        menu &&
        button &&
        dropdown
      ) {
        button.setAttribute(
          "aria-haspopup",
          "menu"
        );

        button.setAttribute(
          "aria-controls",
          "profileDropdown"
        );

        button.setAttribute(
          "aria-expanded",
          "false"
        );

        dropdown.setAttribute(
          "role",
          "menu"
        );

        dropdown.setAttribute(
          "aria-hidden",
          "true"
        );

        menu.classList.remove(
          "open",
          "show",
          "active"
        );

        dropdown.classList.remove(
          "open",
          "show",
          "active"
        );

        dropdown.style.removeProperty(
          "display"
        );
      }

      if (
        notificationsButton &&
        notificationsDropdown
      ) {
        notificationsButton.setAttribute(
          "aria-haspopup",
          "true"
        );

        notificationsButton.setAttribute(
          "aria-controls",
          "notificationDropdown"
        );

        notificationsButton.setAttribute(
          "aria-expanded",
          "false"
        );

        notificationsDropdown.setAttribute(
          "aria-hidden",
          "true"
        );

        notificationsDropdown.classList.remove(
          "open",
          "show",
          "active"
        );

        notificationsDropdown.style.removeProperty(
          "display"
        );
      }
    }

    function addAccessibility() {
      if (!$(".admin-ui-skip-link")) {
        const skip =
          document.createElement("a");

        skip.className =
          "admin-ui-skip-link";

        skip.href =
          "#adminMainContent";

        skip.textContent =
          "Skip to main content";

        document.body.prepend(skip);
      }

      const main =
        $(".main-content");

      if (main && !main.id) {
        main.id =
          "adminMainContent";
      }

      main?.setAttribute(
        "role",
        "main"
      );

      const sidebar =
        $(".sidebar");

      sidebar?.setAttribute(
        "aria-label",
        "Administrator navigation"
      );

      $$("button").forEach(
        (button) => {
          if (
            !button.getAttribute("type")
          ) {
            button.setAttribute(
              "type",
              "button"
            );
          }

          const text = (
            button.textContent || ""
          ).trim();

          if (
            !text &&
            !button.getAttribute(
              "aria-label"
            )
          ) {
            const title =
              button.getAttribute("title");

            const icon =
              button
                .querySelector(
                  "[data-lucide]"
                )
                ?.getAttribute(
                  "data-lucide"
                );

            button.setAttribute(
              "aria-label",
              title ||
              (
                icon
                  ? icon.replace(
                      /-/g,
                      " "
                    )
                  : "Action"
              )
            );
          }
        }
      );

      $$("table").forEach(
        (table) => {
          if (
            !table.getAttribute("role")
          ) {
            table.setAttribute(
              "role",
              "table"
            );
          }

          $$("th", table).forEach(
            (heading) => {
              if (
                !heading.getAttribute(
                  "scope"
                )
              ) {
                heading.setAttribute(
                  "scope",
                  "col"
                );
              }
            }
          );
        }
      );

      $$(
        "input[required], select[required], textarea[required]"
      ).forEach((element) => {
        element.setAttribute(
          "aria-required",
          "true"
        );
      });
    }

    function addMobileTitle() {
      const left =
        $(".topbar-left");

      if (
        !left ||
        $(
          ".admin-ui-mobile-title",
          left
        )
      ) {
        return;
      }

      const heading = $(
        ".page-header h1, .ics-admin-header h1"
      );

      if (!heading) {
        return;
      }

      const title =
        document.createElement("div");

      title.className =
        "admin-ui-mobile-title";

      title.innerHTML = `
        <strong>
          ${escapeHtml(
            heading.textContent.trim()
          )}
        </strong>
        <span>PGENRO IMS Admin</span>
      `;

      const menu = $(
        "#mobileMenuBtn",
        left
      );

      if (menu?.nextSibling) {
        left.insertBefore(
          title,
          menu.nextSibling
        );
      } else {
        left.prepend(title);
      }
    }

    function setupKeyboardSearch() {
      const search = $(
        "#globalSearchInput, #globalSearch, #quickSearchInput, #tableSearchInput, #visitorSearch"
      );

      if (!search) {
        return;
      }

      document.addEventListener(
        "keydown",
        (event) => {
          const target =
            event.target;

          const typing =
            target &&
            /INPUT|TEXTAREA|SELECT/.test(
              target.tagName
            );

          if (
            (
              event.ctrlKey ||
              event.metaKey
            ) &&
            event.key.toLowerCase() ===
              "k"
          ) {
            event.preventDefault();
            search.focus();
            search.select?.();
          } else if (
            event.key === "/" &&
            !typing
          ) {
            event.preventDefault();
            search.focus();
          }
        }
      );
    }

    function setupMobileBackdrop() {
      if (
        $(".overlay#overlay") ||
        $("#sidebarOverlay") ||
        $("#sidebarBackdrop")
      ) {
        return;
      }

      const sidebar =
        $("#sidebar");

      const menu =
        $("#mobileMenuBtn");

      if (!sidebar || !menu) {
        return;
      }

      const backdrop =
        document.createElement("div");

      backdrop.className =
        "admin-sidebar-backdrop";

      backdrop.setAttribute(
        "aria-hidden",
        "true"
      );

      document.body.appendChild(
        backdrop
      );

      const synchronize = () => {
        const open =
          sidebar.classList.contains(
            "mobile-open"
          ) ||
          sidebar.classList.contains(
            "open"
          );

        backdrop.classList.toggle(
          "active",
          open && innerWidth <= 900
        );

        backdrop.setAttribute(
          "aria-hidden",
          open ? "false" : "true"
        );
      };

      menu.addEventListener(
        "click",
        () => {
          setTimeout(
            synchronize,
            0
          );
        }
      );

      backdrop.addEventListener(
        "click",
        () => {
          sidebar.classList.remove(
            "mobile-open",
            "open"
          );

          backdrop.classList.remove(
            "active"
          );

          menu.setAttribute(
            "aria-expanded",
            "false"
          );
        }
      );

      new MutationObserver(
        synchronize
      ).observe(sidebar, {
        attributes: true,
        attributeFilter: ["class"]
      });
    }

    function setupSidebarState() {
      const sidebar =
        $("#sidebar");

      const main =
        $(".main-wrapper");

      const collapse =
        $("#sidebarCollapseBtn");

      if (!sidebar) {
        return;
      }

      try {
        const collapsed =
          localStorage.getItem(
            "pgenro_admin_sidebar"
          ) === "collapsed";

        if (
          collapsed &&
          innerWidth > 900
        ) {
          sidebar.classList.add(
            "collapsed"
          );

          document.body.classList.add(
            "sidebar-collapsed"
          );

          main?.classList.add(
            "sidebar-collapsed"
          );
        }
      } catch {}

      collapse?.setAttribute(
        "aria-expanded",
        String(
          !sidebar.classList.contains(
            "collapsed"
          )
        )
      );
    }

    function setupUnifiedShellControls() {
      const sidebar =
        $("#sidebar");

      const main =
        $(".main-wrapper");

      const profileMenu =
        $("#profileMenu");

      const profileButton =
        $("#profileBtn");

      const profileDropdown =
        $("#profileDropdown");

      const notificationDropdown =
        $("#notificationDropdown");

      const mobileMenuButton =
        $("#mobileMenuBtn");

      const collapseButton =
        $("#sidebarCollapseBtn");

      profileMenu?.classList.remove(
        "open",
        "show",
        "active"
      );

      profileDropdown?.classList.remove(
        "open",
        "show",
        "active"
      );

      notificationDropdown?.classList.remove(
        "open",
        "show",
        "active"
      );

      profileDropdown?.style.removeProperty(
        "display"
      );

      notificationDropdown?.style.removeProperty(
        "display"
      );

      profileDropdown?.setAttribute(
        "aria-hidden",
        "true"
      );

      notificationDropdown?.setAttribute(
        "aria-hidden",
        "true"
      );

      profileButton?.setAttribute(
        "aria-expanded",
        "false"
      );

      $("#notificationsBtn")
        ?.setAttribute(
          "aria-expanded",
          "false"
        );

      const allBackdrops = () =>
        [
          $("#sidebarBackdrop"),
          $("#sidebarOverlay"),
          $(".admin-sidebar-backdrop")
        ].filter(Boolean);

      const setBackdrop = (open) => {
        allBackdrops().forEach(
          (backdrop) => {
            backdrop.classList.toggle(
              "active",
              Boolean(open)
            );
          }
        );

        const overlay =
          $("#overlay");

        if (
          overlay &&
          !$("#detailDrawer")
            ?.classList.contains("open")
        ) {
          overlay.classList.toggle(
            "active",
            Boolean(open)
          );
        }
      };

      const closeMobile = () => {
        sidebar?.classList.remove(
          "mobile-open",
          "open"
        );

        mobileMenuButton?.setAttribute(
          "aria-expanded",
          "false"
        );

        setBackdrop(false);
      };

      const closeProfile = () => {
        profileMenu?.classList.remove(
          "open",
          "show",
          "active"
        );

        profileDropdown?.classList.remove(
          "open",
          "show",
          "active"
        );

        profileDropdown?.style.removeProperty(
          "display"
        );

        profileDropdown?.setAttribute(
          "aria-hidden",
          "true"
        );

        profileButton?.setAttribute(
          "aria-expanded",
          "false"
        );
      };

      const closeNotifications = () => {
        notificationDropdown?.classList.remove(
          "open",
          "show",
          "active"
        );

        notificationDropdown?.style.removeProperty(
          "display"
        );

        notificationDropdown?.setAttribute(
          "aria-hidden",
          "true"
        );

        $("#notificationsBtn")
          ?.setAttribute(
            "aria-expanded",
            "false"
          );
      };

      document.addEventListener(
        "click",
        (event) => {
          const target =
            event.target instanceof Element
              ? event.target
              : null;

          if (!target) {
            return;
          }

          if (
            target.closest(
              "#mobileMenuBtn"
            )
          ) {
            event.preventDefault();
            event.stopImmediatePropagation();

            if (!sidebar) {
              return;
            }

            const opening =
              !sidebar.classList.contains(
                "mobile-open"
              );

            sidebar.classList.toggle(
              "mobile-open",
              opening
            );

            mobileMenuButton?.setAttribute(
              "aria-expanded",
              String(opening)
            );

            setBackdrop(
              opening &&
              innerWidth <= 900
            );

            return;
          }

          if (
            target.closest(
              "#sidebarCollapseBtn"
            )
          ) {
            event.preventDefault();
            event.stopImmediatePropagation();

            if (!sidebar) {
              return;
            }

            if (innerWidth <= 900) {
              closeMobile();
              return;
            }

            const collapsed =
              !sidebar.classList.contains(
                "collapsed"
              );

            sidebar.classList.toggle(
              "collapsed",
              collapsed
            );

            document.body.classList.toggle(
              "sidebar-collapsed",
              collapsed
            );

            main?.classList.toggle(
              "sidebar-collapsed",
              collapsed
            );

            collapseButton?.setAttribute(
              "aria-expanded",
              String(!collapsed)
            );

            try {
              localStorage.setItem(
                "pgenro_admin_sidebar",
                collapsed
                  ? "collapsed"
                  : "expanded"
              );
            } catch {}

            return;
          }

          if (
            target.closest("#logoutBtn")
          ) {
            event.preventDefault();
            event.stopImmediatePropagation();

            const logoutButton =
              target.closest(
                "#logoutBtn"
              );

            logoutButton?.setAttribute(
              "disabled",
              ""
            );

            logoutButton?.setAttribute(
              "aria-busy",
              "true"
            );

            (async () => {
              try {
                await window.PGENRO_AUDIT
                  ?.log?.(
                    "LOGOUT",
                    "Signed out of the administrator workspace.",
                    {
                      module:
                        "Authentication"
                    }
                  );

                const client =
                  window.pgenroSupabase ||
                  window.PGENRO_DB?.client;

                await client?.auth
                  ?.signOut?.();
              } catch (error) {
                console.warn(
                  "PGENRO IMS: sign-out request could not be completed.",
                  error
                );
              } finally {
                try {
                  Object.keys(
                    sessionStorage
                  )
                    .filter((key) =>
                      /^(pgenro|sb-)/i.test(
                        key
                      )
                    )
                    .forEach((key) => {
                      sessionStorage.removeItem(
                        key
                      );
                    });
                } catch {}

                window.location.href =
                  "../User/login.html";
              }
            })();

            return;
          }

          if (
            target.closest("#profileBtn")
          ) {
            event.preventDefault();
            event.stopImmediatePropagation();

            if (!profileMenu) {
              return;
            }

            const opening =
              !profileMenu.classList.contains(
                "open"
              );

            closeProfile();
            closeNotifications();

            if (opening) {
              profileMenu.classList.add(
                "open"
              );

              profileDropdown?.setAttribute(
                "aria-hidden",
                "false"
              );

              profileButton?.setAttribute(
                "aria-expanded",
                "true"
              );
            }

            return;
          }

          if (
            target.closest(
              "#notificationsBtn"
            )
          ) {
            event.preventDefault();
            event.stopImmediatePropagation();

            if (!notificationDropdown) {
              window.AdminUI?.toast?.(
                "No new notifications.",
                "info"
              );

              return;
            }

            const opening =
              !notificationDropdown.classList.contains(
                "open"
              );

            closeProfile();
            closeNotifications();

            if (opening) {
              notificationDropdown.classList.add(
                "open"
              );

              notificationDropdown.setAttribute(
                "aria-hidden",
                "false"
              );

              $("#notificationsBtn")
                ?.setAttribute(
                  "aria-expanded",
                  "true"
                );
            }

            return;
          }

          if (
            profileMenu &&
            !profileMenu.contains(target)
          ) {
            closeProfile();
          }

          const notificationWrapper =
            notificationDropdown?.closest(
              ".notification-wrapper"
            );

          if (
            notificationDropdown &&
            notificationWrapper &&
            !notificationWrapper.contains(
              target
            )
          ) {
            closeNotifications();
          }

          if (
            innerWidth <= 900 &&
            sidebar?.classList.contains(
              "mobile-open"
            )
          ) {
            const insideSidebar =
              sidebar.contains(target);

            const isMenuButton =
              Boolean(
                target.closest(
                  "#mobileMenuBtn"
                )
              );

            if (
              !insideSidebar &&
              !isMenuButton &&
              !target.closest("#overlay")
            ) {
              closeMobile();
            }
          }
        },
        true
      );

      window.addEventListener(
        "resize",
        () => {
          if (innerWidth > 900) {
            sidebar?.classList.remove(
              "mobile-open",
              "open"
            );

            setBackdrop(false);
          } else {
            document.body.classList.remove(
              "sidebar-collapsed"
            );

            main?.classList.remove(
              "sidebar-collapsed"
            );
          }
        }
      );
    }

    function setupEscapeKey() {
      document.addEventListener(
        "keydown",
        (event) => {
          if (event.key !== "Escape") {
            return;
          }

          $("#sidebar")
            ?.classList.remove(
              "mobile-open",
              "open"
            );

          $$(
            ".admin-sidebar-backdrop, #sidebarOverlay, #sidebarBackdrop"
          ).forEach((element) => {
            element.classList.remove(
              "active"
            );
          });

          if (
            !$("#detailDrawer")
              ?.classList.contains("open")
          ) {
            $("#overlay")
              ?.classList.remove(
                "active"
              );
          }

          $("#mobileMenuBtn")
            ?.setAttribute(
              "aria-expanded",
              "false"
            );

          $("#profileBtn")
            ?.setAttribute(
              "aria-expanded",
              "false"
            );

          $("#profileDropdown")
            ?.classList.remove(
              "open",
              "show",
              "active"
            );

          $("#profileDropdown")
            ?.setAttribute(
              "aria-hidden",
              "true"
            );

          $("#profileMenu")
            ?.classList.remove(
              "open",
              "show",
              "active"
            );

          $("#notificationDropdown")
            ?.classList.remove(
              "open",
              "show",
              "active"
            );

          $("#notificationDropdown")
            ?.setAttribute(
              "aria-hidden",
              "true"
            );

          $("#notificationsBtn")
            ?.setAttribute(
              "aria-expanded",
              "false"
            );

          const drawer =
            $("#detailDrawer");

          if (drawer) {
            drawer.classList.remove(
              "open",
              "active"
            );

            drawer.setAttribute(
              "aria-hidden",
              "true"
            );
          }
        }
      );
    }

    function setupResponsiveTables() {
      $$("table").forEach(
        (table) => {
          if (
            table.closest(
              ".table-responsive, .table-wrapper, .table-container, .ics-table-wrapper"
            )
          ) {
            return;
          }

          const parent =
            table.parentElement;

          if (!parent) {
            return;
          }

          const wrapper =
            document.createElement("div");

          wrapper.className =
            "table-responsive admin-ui-auto-table-wrap";

          parent.insertBefore(
            wrapper,
            table
          );

          wrapper.appendChild(table);
        }
      );
    }

    function setupExternalLinkSafety() {
      $$('a[target="_blank"]').forEach(
        (anchor) => {
          const rel = new Set(
            (
              anchor.getAttribute("rel") ||
              ""
            )
              .split(/\s+/)
              .filter(Boolean)
          );

          rel.add("noopener");
          rel.add("noreferrer");

          anchor.setAttribute(
            "rel",
            [...rel].join(" ")
          );
        }
      );
    }

    function addFooterWhenMissing() {
      const main =
        $(".main-content");

      if (
        !main ||
        $("footer", main) ||
        $(".admin-footer", main)
      ) {
        return;
      }

      const footer =
        document.createElement(
          "footer"
        );

      footer.className =
        "admin-footer";

      footer.innerHTML = `
        <div>
          <p>
            &copy; 2026 Provincial Government Environment
            and Natural Resources Office.
            Administrator workspace.
          </p>
        </div>

        <div class="footer-links">
          <a href="admin.html#audit">
            Audit Trail
          </a>

          <a href="admin.html#backup">
            Backups
          </a>

          <a href="admin.html#settings">
            Settings
          </a>
        </div>
      `;

      main.appendChild(footer);
    }

    function setupOnlineState() {
      const apply = () => {
        document.documentElement.dataset.network =
          navigator.onLine
            ? "online"
            : "offline";
      };

      apply();

      addEventListener(
        "online",
        apply
      );

      addEventListener(
        "offline",
        apply
      );
    }

    function escapeHtml(value) {
      const element =
        document.createElement("div");

      element.textContent =
        value == null
          ? ""
          : String(value);

      return element.innerHTML;
    }

    window.AdminUI =
      window.AdminUI || {};

    window.AdminUI.toast = (
      message,
      type = "success",
      timeout = 2800
    ) => {
      let stack =
        $(".admin-ui-toast-stack");

      if (!stack) {
        stack =
          document.createElement("div");

        stack.className =
          "admin-ui-toast-stack";

        stack.setAttribute(
          "aria-live",
          "polite"
        );

        document.body.appendChild(
          stack
        );
      }

      const toast =
        document.createElement("div");

      toast.className =
        "admin-ui-toast";

      toast.dataset.type = type;

      const icon =
        type === "error"
          ? "alert-circle"
          : type === "warning"
            ? "alert-triangle"
            : "circle-check";

      toast.innerHTML = `
        <i data-lucide="${icon}"></i>
        <span>
          ${escapeHtml(message)}
        </span>
      `;

      stack.appendChild(toast);

      window.lucide?.createIcons?.();

      setTimeout(() => {
        toast.style.opacity = "0";
        toast.style.transform =
          "translateY(8px)";

        setTimeout(() => {
          toast.remove();
        }, 200);
      }, timeout);
    };

    function init() {
      document.documentElement.classList.add(
        "admin-ui-ready"
      );

      cleanupDuplicateNavigation();
      fixNavigation();
      setupUnifiedProfileMenu();

      window.addEventListener(
        "hashchange",
        fixNavigation
      );

      addAccessibility();
      addMobileTitle();
      setupKeyboardSearch();
      setupMobileBackdrop();
      setupSidebarState();
      setupUnifiedShellControls();
      setupEscapeKey();
      setupResponsiveTables();
      setupExternalLinkSafety();
      addFooterWhenMissing();
      setupOnlineState();

      window.lucide?.createIcons?.();
    }

    if (
      document.readyState === "loading"
    ) {
      document.addEventListener(
        "DOMContentLoaded",
        init,
        {
          once: true
        }
      );
    } else {
      init();
    }
  })();