/* ==========================================================================
   PGENRO IMS — ADMIN COMMUNICATIONS LOG
   Smart OCR parser: extracts source office from letterhead, recipient from TO,
   subject from SUBJECT, control number, document type, and date.
   ========================================================================== */

(() => {
  "use strict";

  document.addEventListener("DOMContentLoaded", init);

  async function init() {
    /* ---------------- 1. HELPERS & ICON RESOLVER ---------------- */
    const $ = (selector, root = document) => root.querySelector(selector);
    const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));

    function escapeHtml(value) {
      return String(value ?? "").replace(/[&<>"']/g, character => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#039;"
      })[character]);
    }

    function resolveIconName(name) {
      const availableIcons = window.lucide?.icons;
      if (!availableIcons) return name;

      const aliasMap = {
        "file-search": ["file-scan", "scan-text", "search", "file-text"],
        "file-type-2": ["file-text", "file-type", "file"],
        "sheet": ["file-spreadsheet", "table", "file-text"],
        "cloud-upload": ["upload-cloud", "upload", "cloud"],
        "check-circle": ["circle-check", "check-circle-2", "check"],
        "circle-check": ["circle-check", "check-circle-2", "check"],
        "edit-3": ["pencil", "edit", "file-pen"],
        "alert-circle": ["circle-alert", "alert-circle"],
        "alert-triangle": ["triangle-alert", "alert-triangle"]
      };

      if (availableIcons[name] || availableIcons[kebabToPascal(name)]) return name;
      const candidates = aliasMap[name] || [];
      for (const candidate of candidates) {
        if (availableIcons[candidate] || availableIcons[kebabToPascal(candidate)]) {
          return candidate;
        }
      }
      return name;
    }

    function kebabToPascal(str) {
      return str
        .split("-")
        .map(part => part.charAt(0).toUpperCase() + part.slice(1))
        .join("");
    }

    function refreshIcons() {
      try {
        document.querySelectorAll("[data-lucide]").forEach(el => {
          const raw = el.getAttribute("data-lucide");
          const resolved = resolveIconName(raw);
          if (resolved !== raw) el.setAttribute("data-lucide", resolved);
        });
        window.lucide?.createIcons?.();
      } catch (error) {
        console.warn("Lucide notice:", error);
      }
    }

    refreshIcons();

    /* ---------------- 2. INDEXEDDB FILE STORAGE ---------------- */
    const DB_NAME = "PGENRO_Document_Store";
    const DB_VERSION = 1;
    const STORE_NAME = "uploaded_files";

    function openFileDatabase() {
      return new Promise((resolve, reject) => {
        const request = indexedDB.open(DB_NAME, DB_VERSION);
        request.onupgradeneeded = (e) => {
          const db = e.target.result;
          if (!db.objectStoreNames.contains(STORE_NAME)) {
            db.createObjectStore(STORE_NAME, { keyPath: "id" });
          }
        };
        request.onsuccess = () => resolve(request.result);
        request.onerror = () => reject(request.error);
      });
    }

    async function storeFileLocally(id, file) {
      if (!id || !file) return;
      try {
        const db = await openFileDatabase();
        return new Promise((resolve, reject) => {
          const tx = db.transaction(STORE_NAME, "readwrite");
          const store = tx.objectStore(STORE_NAME);
          store.put({
            id: String(id),
            name: file.name,
            type: file.type,
            size: file.size,
            blob: file,
            updatedAt: Date.now()
          });
          tx.oncomplete = () => resolve(true);
          tx.onerror = () => reject(tx.error);
        });
      } catch (err) {
        console.warn("IndexedDB store notice:", err);
      }
    }

    async function getStoredFile(id) {
      if (!id) return null;
      try {
        const db = await openFileDatabase();
        return new Promise((resolve) => {
          const tx = db.transaction(STORE_NAME, "readonly");
          const store = tx.objectStore(STORE_NAME);
          const req = store.get(String(id));
          req.onsuccess = () => resolve(req.result || null);
          req.onerror = () => resolve(null);
        });
      } catch {
        return null;
      }
    }

    async function deleteStoredFile(id) {
      if (!id) return;
      try {
        const db = await openFileDatabase();
        const tx = db.transaction(STORE_NAME, "readwrite");
        tx.objectStore(STORE_NAME).delete(String(id));
      } catch (e) {
        console.warn("Delete error:", e);
      }
    }

    /* ---------------- 3. DOM ELEMENTS ---------------- */
    const dbStatusDot = $("#dbStatusDot");
    const dbStatusText = $("#dbStatusText");

    const communicationTableBody = $("#communicationTableBody");
    const tablePaginationInfo = $("#tablePaginationInfo");
    const tableSearchInput = $("#tableSearchInput");
    const globalSearchInput = $("#globalSearchInput");
    const statusFilter = $("#statusFilter");
    const filterTabs = $$(".filter-tab");
    const selectAllRows = $("#selectAllRows");
    const bulkSelectionBar = $("#bulkSelectionBar");
    const selectedCountText = $("#selectedCountText");
    const bulkArchiveBtn = $("#bulkArchiveBtn");
    const bulkDeleteBtn = $("#bulkDeleteBtn");
    const clearSelectionBtn = $("#clearSelectionBtn");
    const exportCommunicationsBtn = $("#exportCommunicationsBtn");
    const syncCommunicationsBtn = $("#syncCommunicationsBtn");
    const notificationList = $("#notificationList");
    const notifBadgeCount = $("#notifBadgeCount");
    const notifPing = $("#notifPing");

    const kpiTotalRecords = $("#kpiTotalRecords");
    const kpiIncomingCount = $("#kpiIncomingCount");
    const kpiOutgoingCount = $("#kpiOutgoingCount");
    const kpiPendingCount = $("#kpiPendingCount");

    // Modal Form Elements
    const encodingModal = $("#encodingModal");
    const openEncodingModalBtn = $("#openEncodingModalBtn");
    const closeEncodingModalBtn = $("#closeEncodingModalBtn");
    const cancelEncodingBtn = $("#cancelEncodingBtn");
    const communicationForm = $("#communicationForm");
    const modalTitle = $("#modalTitle");

    const editIndexInput = $("#editIndex");
    const typeSelect = $("#typeSelect");
    const controlNoInput = $("#controlNoInput");
    const docTypeSelect = $("#docTypeSelect");
    const dateInput = $("#dateInput");
    const statusSelect = $("#statusSelect");
    const officeInput = $("#officeInput");
    const subjectInput = $("#subjectInput");
    const actionTakenInput = $("#actionTakenInput");
    const remarksInput = $("#remarksInput");
    const ocrTextInput = $("#ocrTextInput");
    const ocrStatsChip = $("#ocrStatsChip");

    // File Elements
    const documentFileInput = $("#documentFileInput");
    const browseDocumentBtn = $("#browseDocumentBtn");
    const removeDocumentBtn = $("#removeDocumentBtn");
    const runOcrBtn = $("#runOcrBtn");
    const ocrActionSubtext = $("#ocrActionSubtext");
    const filePickerState = $("#filePickerState");
    const filePickerIcon = $("#filePickerIcon");
    const fileNameDisplay = $("#fileNameDisplay");
    const fileMetaDisplay = $("#fileMetaDisplay");

    // Live Preview
    const filePreviewContainer = $("#filePreviewContainer");
    const filePreviewBody = $("#filePreviewBody");
    const previewBadge = $("#previewBadge");
    const previewOpenExternalBtn = $("#previewOpenExternalBtn");

    // Progress Bar & Submit
    const encodingUploadProgressBox = $("#encodingUploadProgressBox");
    const encodingUploadStatusText = $("#encodingUploadStatusText");
    const encodingProgressBar = $("#encodingProgressBar");
    const saveRecordBtn = $("#saveRecordBtn");

    // Viewer Modals
    const viewOcrModal = $("#viewOcrModal");
    const viewOcrContent = $("#viewOcrContent");
    const viewOcrFileName = $("#viewOcrFileName");
    const closeViewOcrModalBtn = $("#closeViewOcrModalBtn");

    const viewDocumentModal = $("#viewDocumentModal");
    const docViewerTitle = $("#docViewerTitle");
    const docViewerSubtitle = $("#docViewerSubtitle");
    const docViewerIframe = $("#docViewerIframe");
    const docViewerImage = $("#docViewerImage");
    const docViewerFallback = $("#docViewerFallback");
    const docViewerDownloadBtn = $("#docViewerDownloadBtn");
    const docViewerExternalBtn = $("#docViewerExternalBtn");
    const closeDocViewerBtn = $("#closeDocViewerBtn");

    // Profile Dropdown
    const profileMenu = $("#profileMenu");
    const profileBtn = $("#profileBtn");
    const profileDropdown = $("#profileDropdown");
    const notificationsBtn = $("#notificationsBtn");
    const notificationDropdown = $("#notificationDropdown");
    const logoutBtn = $("#logoutBtn");
    const sidebar = $("#sidebar");
    const sidebarCollapseBtn = $("#sidebarCollapseBtn");
    const mobileMenuBtn = $("#mobileMenuBtn");
    const mainWrapper = $(".main-wrapper");

    /* ---------------- 4. APPLICATION STATE ---------------- */
    let records = [];
    let currentTypeFilter = "All";
    let currentStatusFilter = "All";
    let selectedFile = null;
    let existingEditFileName = "";
    let existingEditDriveLink = "";
    let activePreviewBlobUrl = null;
    let cloudRecordsAvailable = false;
    const selectedRecordIds = new Set();

    const COMMUNICATIONS_TABLE = "communications";
    const supabaseClient = window.pgenroSupabase || null;
    const supabaseConfigured = Boolean(window.PGENRO_SUPABASE?.configured && supabaseClient);
    const OCR_SERVER_URL = "http://127.0.0.1:5000";
    const SUPPORTED_DOCUMENT_TYPES = new Set([
      "pdf", "png", "jpg", "jpeg", "webp", "bmp", "tif", "tiff",
      "docx", "txt", "csv", "xlsx", "pptx"
    ]);
    const MAX_FILE_SIZE = 50 * 1024 * 1024;

    /* ---------------- 5. PROFILE & DROPDOWN HANDLING ---------------- */
    function closeProfileDropdown() {
      if (!profileDropdown || !profileBtn) return;
      profileDropdown.classList.remove("open");
      profileMenu?.classList.remove("open");
      profileBtn.setAttribute("aria-expanded", "false");
      profileDropdown.style.display = "none";
    }

    function openProfileDropdown() {
      if (!profileDropdown || !profileBtn) return;
      if (notificationDropdown) {
        notificationDropdown.classList.remove("open");
        notificationDropdown.style.display = "none";
      }
      profileDropdown.classList.add("open");
      profileMenu?.classList.add("open");
      profileBtn.setAttribute("aria-expanded", "true");
      profileDropdown.style.display = "block";
    }

    profileBtn?.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      profileDropdown.classList.contains("open") ? closeProfileDropdown() : openProfileDropdown();
    });

    document.addEventListener("click", (e) => {
      if (!profileMenu?.contains(e.target)) closeProfileDropdown();
      if (notificationDropdown && !notificationDropdown.contains(e.target) && !notificationsBtn?.contains(e.target)) {
        notificationDropdown.classList.remove("open");
        notificationDropdown.style.display = "none";
      }
    });

    /* ---------------- 5B. RESPONSIVE ADMIN SHELL ---------------- */
    let sidebarBackdrop = $(".admin-sidebar-backdrop");
    if (!sidebarBackdrop) {
      sidebarBackdrop = document.createElement("div");
      sidebarBackdrop.className = "admin-sidebar-backdrop";
      sidebarBackdrop.setAttribute("aria-hidden", "true");
      document.body.appendChild(sidebarBackdrop);
    }

    const isMobileViewport = () => window.matchMedia("(max-width: 900px)").matches;

    function setMobileSidebar(open) {
      sidebar?.classList.toggle("mobile-open", Boolean(open));
      sidebarBackdrop?.classList.toggle("active", Boolean(open));
      sidebarBackdrop?.setAttribute("aria-hidden", String(!open));
      mobileMenuBtn?.setAttribute("aria-expanded", String(Boolean(open)));
      document.body.classList.toggle("admin-mobile-nav-open", Boolean(open));
    }

    function setDesktopSidebarCollapsed(collapsed) {
      if (!sidebar) return;
      sidebar.classList.toggle("collapsed", Boolean(collapsed));
      mainWrapper?.classList.toggle("sidebar-collapsed", Boolean(collapsed));
      document.body.classList.toggle("sidebar-collapsed", Boolean(collapsed));
      sidebarCollapseBtn?.setAttribute("aria-expanded", String(!collapsed));
      try { localStorage.setItem("pgenro_admin_sidebar", collapsed ? "collapsed" : "expanded"); } catch {}
    }

    mobileMenuBtn?.setAttribute("aria-expanded", "false");
    mobileMenuBtn?.addEventListener("click", (e) => {
      e.preventDefault();
      setMobileSidebar(!sidebar?.classList.contains("mobile-open"));
    });

    sidebarCollapseBtn?.addEventListener("click", (e) => {
      e.preventDefault();
      if (isMobileViewport()) {
        setMobileSidebar(false);
        return;
      }
      setDesktopSidebarCollapsed(!sidebar?.classList.contains("collapsed"));
    });

    sidebarBackdrop?.addEventListener("click", () => setMobileSidebar(false));
    sidebar?.querySelectorAll("a.nav-item").forEach(link => {
      link.addEventListener("click", () => {
        if (isMobileViewport()) setMobileSidebar(false);
      });
    });

    notificationsBtn?.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      closeProfileDropdown();
      const opening = !notificationDropdown?.classList.contains("open");
      notificationDropdown?.classList.toggle("open", opening);
      if (notificationDropdown) notificationDropdown.style.display = opening ? "block" : "none";
    });

    logoutBtn?.addEventListener("click", async (e) => {
      e.preventDefault();
      try { await supabaseClient?.auth?.signOut?.(); } catch (error) { console.warn("Sign-out notice:", error); }
      sessionStorage.clear();
      window.location.href = "../User/login.html";
    });

    window.addEventListener("resize", () => {
      if (!isMobileViewport()) {
        setMobileSidebar(false);
      } else {
        sidebar?.classList.remove("collapsed");
        mainWrapper?.classList.remove("sidebar-collapsed");
        document.body.classList.remove("sidebar-collapsed");
      }
    });

    document.addEventListener("keydown", (e) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        globalSearchInput?.focus();
        globalSearchInput?.select?.();
        return;
      }

      if (e.key === "Escape") {
        setMobileSidebar(false);
        closeProfileDropdown();
        notificationDropdown?.classList.remove("open");
        if (notificationDropdown) notificationDropdown.style.display = "none";

        if (viewDocumentModal?.classList.contains("open")) {
          viewDocumentModal.classList.remove("open");
          viewDocumentModal.setAttribute("aria-hidden", "true");
          if (docViewerIframe) docViewerIframe.src = "";
          if (docViewerImage) docViewerImage.src = "";
        } else if (viewOcrModal?.classList.contains("open")) {
          viewOcrModal.classList.remove("open");
          viewOcrModal.setAttribute("aria-hidden", "true");
        } else if (encodingModal?.classList.contains("open")) {
          closeEncodingModal();
        }

        if (!document.querySelector(".modal-overlay.open")) {
          document.body.classList.remove("admin-modal-open");
        }
      }
    });

    if (!isMobileViewport()) {
      try { setDesktopSidebarCollapsed(localStorage.getItem("pgenro_admin_sidebar") === "collapsed"); } catch {}
    }

    /* ---------------- 6. DATE FORMATTER ---------------- */
    function parseDateValue(str) {
      if (!str) return "";
      const text = String(str).trim();
      const monthNames = [
        "january", "february", "march", "april", "may", "june",
        "july", "august", "september", "october", "november", "december"
      ];

      // Format: "02 January 2025" o "2 January 2025"
      const dayFirstMatch = text.match(/\b(\d{1,2})(?:st|nd|rd|th)?\s+([A-Za-z]+)\s+(\d{4})\b/i);
      if (dayFirstMatch) {
        const day = Number(dayFirstMatch[1]);
        const monthStr = dayFirstMatch[2].toLowerCase();
        const year = Number(dayFirstMatch[3]);
        const mIdx = monthNames.findIndex(m => m.startsWith(monthStr.slice(0, 3)));
        if (mIdx !== -1) {
          return `${year}-${String(mIdx + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
        }
      }

      // Format: "January 02, 2025"
      const monthFirstMatch = text.match(/\b([A-Za-z]+)\s+(\d{1,2})(?:st|nd|rd|th)?,?\s+(\d{4})\b/i);
      if (monthFirstMatch) {
        const monthStr = monthFirstMatch[1].toLowerCase();
        const day = Number(monthFirstMatch[2]);
        const year = Number(monthFirstMatch[3]);
        const mIdx = monthNames.findIndex(m => m.startsWith(monthStr.slice(0, 3)));
        if (mIdx !== -1) {
          return `${year}-${String(mIdx + 1).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
        }
      }

      // Format: YYYY-MM-DD
      const isoMatch = text.match(/\b(\d{4})-(\d{1,2})-(\d{1,2})\b/);
      if (isoMatch) {
        return `${isoMatch[1]}-${String(isoMatch[2]).padStart(2, "0")}-${String(isoMatch[3]).padStart(2, "0")}`;
      }

      return "";
    }

    /* ---------------- 7. UNIVERSAL DOCUMENT OCR PARSER ---------------- */
    function normalizeOcrSpacing(value = "") {
      return String(value || "")
        .replace(/\u00A0/g, " ")
        .replace(/[ \t]+/g, " ")
        .trim();
    }

    function getNormalizedLines(rawText = "") {
      return String(rawText || "")
        .replace(/\r/g, "")
        .replace(/\u00A0/g, " ")
        .split("\n")
        .map(line => normalizeOcrSpacing(line))
        .filter(Boolean);
    }

    function isSectionLabel(line = "") {
      return /^(?:DATE|DATE\s+RECEIVED|DATE\s+RELEASED|DATED|FROM|TO|T0|THRU|REF(?:ERENCE)?|SUBJECT(?:\s+MATTER)?|SUBJ)\s*[:;.-]?\s*/i.test(line);
    }

    function cleanOfficeName(value = "") {
      return normalizeOcrSpacing(value)
        .replace(/\s{2,}/g, " ")
        .replace(/^[|:;,.\-]+|[|:;,.\-]+$/g, "")
        .trim();
    }

    function ensureDocumentTypeOptions() {
      if (!docTypeSelect) return;

      const requiredOptions = [
        "Office Order",
        "Special Order",
        "Travel Order",
        "Request Letter",
        "Endorsement Letter",
        "Transmittal Letter",
        "Response Letter",
        "Notice of Meeting",
        "Invitation",
        "Report",
        "Memorandum",
        "Other File"
      ];

      const existing = new Set(
        Array.from(docTypeSelect.options).map(option =>
          String(option.value || "").trim().toLowerCase()
        )
      );

      requiredOptions.forEach(label => {
        if (existing.has(label.toLowerCase())) return;
        const option = document.createElement("option");
        option.value = label;
        option.textContent = label;
        docTypeSelect.appendChild(option);
      });
    }

    function findExplicitField(text, labels) {
      const escapedLabels = labels
        .map(label => label.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"))
        .join("|");

      const regex = new RegExp(
        `(?:^|\\n)\\s*(?:${escapedLabels})\\s*[:;.-]\\s*([^\\n\\r]+)`,
        "i"
      );

      const match = String(text || "").match(regex);
      return match?.[1] ? normalizeOcrSpacing(match[1]) : "";
    }

    function extractSourceOffice(text = "", lines = []) {
      // 1. Prefer an explicit sender/originating-office field.
      const explicitFrom = findExplicitField(text, [
        "FROM",
        "ISSUED BY",
        "ISSUING OFFICE",
        "ORIGINATING OFFICE",
        "SENDER"
      ]);

      if (explicitFrom) return cleanOfficeName(explicitFrom);

      // 2. Read the document letterhead from the upper portion only.
      const headerLines = lines.slice(0, 30);
      const candidates = [];

      for (const line of headerLines) {
        // Stop when normal document fields begin.
        if (/^(?:TO|T0|SUBJECT|SUBJ|DATE|FROM|THRU|REF|DEAR)\b/i.test(line)) {
          break;
        }

        if (/\b(?:OFFICE|DEPARTMENT|DIVISION|SECTION|BUREAU|CENTER|CENTRE|COMMISSION|COUNCIL|UNIVERSITY|COLLEGE|SCHOOL|COMPANY|CORPORATION|INC\.?|LTD\.?|ASSOCIATION|FOUNDATION|AGENCY|GOVERNMENT|BARANGAY|MUNICIPAL|PROVINCIAL|CITY)\b/i.test(line)) {
          candidates.push(line);
        }
      }

      // Avoid treating a person's name or addressee as the source office.
      const office = cleanOfficeName(candidates.join(" "));
      if (office && !/^(?:HON\.?|MR\.?|MS\.?|MRS\.?|ATTY\.?|DR\.?)\b/i.test(office)) {
        return office;
      }

      return "";
    }

    function detectDocumentTypeUniversal(text = "", lines = []) {
      const upperLines = lines
        .slice(0, 35)
        .map(line => line.toUpperCase().trim());

      // IMPORTANT: document type is detected ONLY from an explicit title/heading.
      // Words such as "request" inside a subject/body must NOT make it a Request Letter.
      const headingRules = [
        { type: "Office Order", patterns: [/^PG\s+ENRO\s+OFFICE\s+ORDER\b/, /^OFFICE\s+ORDER(?:\s+NO\.?|\b)/] },
        { type: "Special Order", patterns: [/^SPECIAL\s+ORDER(?:\s+NO\.?|\b)/] },
        { type: "Travel Order", patterns: [/^TRAVEL\s+ORDER(?:\s+NO\.?|\b)/] },
        { type: "Memorandum", patterns: [/^MEMORANDUM(?:\s+NO\.?|\b)/, /^MEMO(?:\s+NO\.?|\b)/, /^MEMORANDUM$/] },
        { type: "Notice of Meeting", patterns: [/^NOTICE\s+OF\s+MEETING$/] },
        { type: "Endorsement Letter", patterns: [/^ENDORSEMENT\s+LETTER$/, /^LETTER\s+OF\s+ENDORSEMENT$/] },
        { type: "Transmittal Letter", patterns: [/^TRANSMITTAL\s+LETTER$/, /^LETTER\s+OF\s+TRANSMITTAL$/] },
        { type: "Response Letter", patterns: [/^RESPONSE\s+LETTER$/, /^LETTER\s+OF\s+RESPONSE$/] },
        { type: "Request Letter", patterns: [/^REQUEST\s+LETTER$/, /^LETTER\s+OF\s+REQUEST$/] },
        { type: "Invitation", patterns: [/^INVITATION(?:\s+LETTER)?$/] },
        { type: "Report", patterns: [/^REPORT(?:\s+ON|\s+OF|\s+NO\.?|$)/] },
        { type: "Certification", patterns: [/^CERTIFICATION$/, /^CERTIFICATE$/] }
      ];

      for (const line of upperLines) {
        if (!line || line.length > 120) continue;

        for (const rule of headingRules) {
          if (rule.patterns.some(pattern => pattern.test(line))) {
            return rule.type === "Certification" ? "Other File" : rule.type;
          }
        }
      }

      // Secondary explicit heading search for common formats such as:
      // "PG ENRO OFFICE ORDER NO. 25-002" or "OFFICE ORDER NO. 25-002"
      const upperHeader = upperLines.join(" ");
      if (/\bOFFICE\s+ORDER\s+NO\.?\s*[A-Z0-9-]+/i.test(upperHeader)) return "Office Order";
      if (/\bSPECIAL\s+ORDER\s+NO\.?\s*[A-Z0-9-]+/i.test(upperHeader)) return "Special Order";
      if (/\bTRAVEL\s+ORDER\s+NO\.?\s*[A-Z0-9-]+/i.test(upperHeader)) return "Travel Order";
      if (/\bMEMORANDUM\s+(?:NO\.?|NUMBER)\s*[A-Z0-9-]+/i.test(upperHeader)) return "Memorandum";

      // Never infer document type from a generic word appearing in the body/subject.
      return "Other File";
    }

    function extractRecipient(text = "", lines = []) {
      const labeled = findExplicitField(text, ["TO", "T0", "MEMORANDUM FOR", "FOR"]);
      if (labeled) return cleanOfficeName(labeled);

      // Generic letter format: first named addressee immediately before salutation.
      const topLines = lines.slice(0, 25);
      const salutationIndex = topLines.findIndex(line => /^(?:DEAR|GREETINGS|SIR|MADAM|MA'AM|TO WHOM IT MAY CONCERN)\b/i.test(line));

      if (salutationIndex > 0) {
        for (let i = salutationIndex - 1; i >= 0; i -= 1) {
          const line = topLines[i];
          if (!line || /^(?:SUBJECT|DATE|REF|REFERENCE)\b/i.test(line)) continue;
          if (/^\d{1,2}[A-Z]?\s+/.test(line)) continue;
          if (/^(?:REPUBLIC|PROVINCE|REGION|PROVINCIAL GOVERNMENT|CITY GOVERNMENT|MUNICIPAL GOVERNMENT)\b/i.test(line)) continue;
          if (line.length >= 3 && line.length <= 150) return cleanOfficeName(line);
        }
      }

      return "";
    }

    function extractSubjectOnly(text = "", lines = []) {
      const normalizedText = String(text || "").replace(/\r/g, "");
      const normalizedLines = getNormalizedLines(normalizedText);

      // Find SUBJECT / SUBJ / SUBJECT MATTER / RE: only in the upper document area.
      // This prevents body paragraphs containing the word "subject" from being used.
      const searchLimit = Math.min(normalizedLines.length, 45);
      let subjectIndex = -1;
      let subjectInline = "";

      for (let i = 0; i < searchLimit; i += 1) {
        const line = normalizedLines[i];

        const inlineMatch = line.match(
          /^(?:SUBJECT\s+MATTER|SUBJECT|SUBJ|RE)\s*[:;.-]\s*(.+)$/i
        );

        if (inlineMatch) {
          subjectIndex = i;
          subjectInline = normalizeOcrSpacing(inlineMatch[1]);
          break;
        }

        // Also support OCR where "SUBJECT:" is isolated on its own line.
        if (/^(?:SUBJECT\s+MATTER|SUBJECT|SUBJ|RE)\s*[:;.-]?$/i.test(line)) {
          subjectIndex = i;
          break;
        }
      }

      if (subjectIndex < 0) return "";

      const subjectParts = [];
      if (subjectInline) subjectParts.push(subjectInline);

      for (let i = subjectIndex + 1; i < searchLimit; i += 1) {
        const line = normalizedLines[i];
        const lower = line.toLowerCase();

        // Hard section boundaries.
        if (/^(?:DATE|DATE\s+RECEIVED|DATE\s+RELEASED|DATED|FROM|TO|T0|THRU|REF|REFERENCE)\s*[:;.-]/i.test(line)) break;
        if (/^(?:DEAR|GREETINGS|SIR\.?|MADAM\.?|MA'?AM\.?|TO WHOM IT MAY CONCERN)\b/i.test(line)) break;
        if (/^(?:IN\s+LIGHT\s+OF|THIS\s+MEMORANDUM|THIS\s+LETTER|THIS\s+OFFICE|THE\s+PURPOSE|PLEASE\s+BE\s+INFORMED|WE\s+ARE\s+PLEASED|WE\s+WOULD\s+LIKE)\b/i.test(line)) break;
        if (/^\d+\.\s+/.test(line)) break;
        if (/^[-_=]{3,}$/.test(line)) break;

        // Do not absorb obvious document-header content.
        if (/^(?:REPUBLIC\s+OF\s+THE\s+PHILIPPINES|PROVINCE\s+OF|PROVINCIAL\s+GOVERNMENT|CITY\s+GOVERNMENT|MUNICIPAL\s+GOVERNMENT)\b/i.test(line)) break;

        // A new labeled field means the subject is complete.
        if (isSectionLabel(line)) break;

        // A line that is obviously a signature/closing should stop the field.
        if (/^(?:SINCERELY|RESPECTFULLY|TRULY|VERY\s+TRULY|CORDIALLY|YOURS)\b/i.test(line)) break;

        subjectParts.push(line);
      }

      let subject = subjectParts
        .join(" ")
        .replace(/\s{2,}/g, " ")
        .replace(/\s+[|]+\s+/g, " ")
        .trim();

      // Subject is required to contain actual content; do not fall back to the whole file.
      if (!subject || subject.length < 2) return "";

      // Strip accidental trailing OCR separators.
      subject = subject.replace(/[|:;.-]+$/g, "").trim();

      return subject;
    }

    function parseOfficialDocument(rawText = "", serverMetadata = null) {
      const text = String(rawText || "")
        .replace(/\r/g, "")
        .replace(/\u00A0/g, " ");
      const lines = getNormalizedLines(text);

      const result = {
        type: "Outgoing",
        documentType: detectDocumentTypeUniversal(text, lines),
        controlNo: "",
        date: "",
        office: extractSourceOffice(text, lines),
        sourceOffice: extractSourceOffice(text, lines),
        recipient: extractRecipient(text, lines),
        subject: extractSubjectOnly(text, lines),
        status: "Released"
      };

      // Communication type: only switch to Incoming when the document explicitly
      // indicates receipt/incoming; otherwise keep the existing Outgoing behavior.
      if (/\b(?:DATE\s+RECEIVED|RECEIVED\s+FROM|INCOMING\s+COMMUNICATION)\b/i.test(text)) {
        result.type = "Incoming";
        result.status = "Received";
      }

      // Control number only when an explicit document number exists.
      const controlPatterns = [
        /\b(?:OFFICE\s+ORDER|SPECIAL\s+ORDER|TRAVEL\s+ORDER|MEMORANDUM|MEMO)\s+(?:NO\.?|NUMBER)\s*[:#-]?\s*([A-Z0-9._\/-]+)/i,
        /(?:^|\n)\s*(?:NO\.?|NUMBER)\s*[:#-]\s*([A-Z0-9._\/-]+)/i
      ];

      for (const regex of controlPatterns) {
        const match = text.match(regex);
        if (match?.[1]) {
          result.controlNo = normalizeOcrSpacing(match[1]).replace(/[.,;]+$/g, "");
          break;
        }
      }

      // Date: prefer an explicit DATE field, otherwise only search the top 20 lines.
      const explicitDate = findExplicitField(text, ["DATE", "DATE RECEIVED", "DATE RELEASED", "DATED"]);
      result.date = parseDateValue(explicitDate);

      if (!result.date) {
        result.date = parseDateValue(lines.slice(0, 20).join(" "));
      }

      // OCR correction for the common PGENRO scan, without hard-coding the subject itself.
      if (result.subject) {
        result.subject = result.subject
          .replace(/\bA[LI]{1,2}GMENTATION\b/gi, "AUGMENTATION")
          .replace(/\bAUGNENTATION\b/gi, "AUGMENTATION")
          .replace(/\bSCHEDULE\s+LEAVE\b/gi, "SCHEDULED LEAVE")
          .replace(/\bOFFICIAL\s+TRAVE[LI]\b/gi, "OFFICIAL TRAVEL")
          .replace(/\s{2,}/g, " ")
          .trim();
      }

      // Keep metadata only as a safe secondary source for explicit source office.
      // Never let server metadata replace the locally extracted subject/document type.
      const metadata = serverMetadata && typeof serverMetadata === "object" ? serverMetadata : {};
      if (!result.sourceOffice && metadata.sourceOffice) {
        result.sourceOffice = cleanOfficeName(metadata.sourceOffice);
        result.office = result.sourceOffice;
      }

      return result;
    }

    function autofillCommunicationFields(extractedText, serverMetadata = null) {
      ensureDocumentTypeOptions();

      const parsed = parseOfficialDocument(extractedText, serverMetadata);

      if (typeSelect && parsed.type) {
        typeSelect.value = parsed.type;
        typeSelect.dispatchEvent(new Event("change", { bubbles: true }));
      }

      if (controlNoInput) {
        controlNoInput.value = parsed.controlNo || "";
        controlNoInput.dispatchEvent(new Event("input", { bubbles: true }));
      }

      if (docTypeSelect) {
        const safeType = parsed.documentType || "Other File";
        ensureDocumentTypeOptions();
        docTypeSelect.value = safeType;
        docTypeSelect.dispatchEvent(new Event("change", { bubbles: true }));
      }

      if (dateInput) {
        dateInput.value = parsed.date || "";
        dateInput.dispatchEvent(new Event("input", { bubbles: true }));
      }

      if (statusSelect && parsed.status) {
        statusSelect.value = parsed.status;
        statusSelect.dispatchEvent(new Event("change", { bubbles: true }));
      }

      if (officeInput) {
        officeInput.value = parsed.sourceOffice || parsed.office || parsed.recipient || "";
        officeInput.dispatchEvent(new Event("input", { bubbles: true }));
      }

      // SUBJECT FIELD = SUBJECT ONLY. Never populate it with the full OCR text.
      if (subjectInput) {
        subjectInput.value = parsed.subject || "";
        subjectInput.dispatchEvent(new Event("input", { bubbles: true }));
      }

      return parsed;
    }

    ensureDocumentTypeOptions();

    /* ---------------- 8. OCR CLIENT ENGINE ---------------- */
    async function checkOcrServer() {
      try {
        const response = await fetch(`${OCR_SERVER_URL}/health`, {
          method: "GET",
          cache: "no-store",
          signal: AbortSignal.timeout(3000)
        });
        if (!response.ok) return false;
        const result = await response.json();
        return Boolean(result?.ok);
      } catch {
        return false;
      }
    }

    async function extractTextWithServer(file) {
      if (!file) {
        throw new Error("Please choose a document first.");
      }

      setUploadProgress(
        15,
        "Connecting to OCR Server..."
      );

      const serverOnline = await checkOcrServer();

      if (!serverOnline) {
        const ext = getFileExtension(file.name);

        if (ext === "txt" || ext === "csv") {
          setUploadProgress(
            50,
            "Reading local text file..."
          );

          const text = await file.text();

          setUploadProgress(
            100,
            "Text read successfully."
          );

          return {
            text: text.trim(),
            metadata: {}
          };
        }

        throw new Error(
          "PGENRO OCR Server is offline. Please start it by running: python OCR.py"
        );
      }

      setUploadProgress(
        35,
        `Scanning ${file.name}...`
      );

      const formData = new FormData();
      formData.append("file", file, file.name);

      let response;

      try {
        response = await fetch(
          `${OCR_SERVER_URL}/ocr`,
          {
            method: "POST",
            body: formData
          }
        );
      } catch {
        throw new Error(
          "Cannot connect to PGENRO OCR Server at http://127.0.0.1:5000"
        );
      }

      setUploadProgress(
        75,
        "Analyzing source office, subject and document particulars..."
      );

      let result;

      try {
        result = await response.json();
      } catch {
        throw new Error(
          "OCR Server returned an invalid response."
        );
      }

      if (!response.ok || !result.success) {
        throw new Error(
          result?.error ||
          `OCR processing failed with status ${response.status}.`
        );
      }

      const text = String(
        result?.text || ""
      ).trim();

      if (!text) {
        throw new Error(
          "Document was scanned, but no readable text was detected."
        );
      }

      setUploadProgress(
        100,
        "Document extracted successfully."
      );

      return {
        text,
        metadata: result?.metadata || {}
      };
    }

    let ocrRunToken = 0;

    function setOcrButtonState(reading = false) {
      if (!runOcrBtn) return;
      runOcrBtn.disabled = reading || !selectedFile;

      if (reading) {
        runOcrBtn.innerHTML = `<i data-lucide="loader-2" class="spin-icon"></i><span>Reading Document...</span>`;
        if (ocrActionSubtext) ocrActionSubtext.textContent = "OCR is running automatically. Please wait...";
      } else {
        runOcrBtn.innerHTML = `<i data-lucide="scan-text"></i><span>Run OCR Text Reader</span>`;
        if (ocrActionSubtext) {
          ocrActionSubtext.textContent = selectedFile
            ? "OCR completed automatically. Click to re-scan."
            : "Select a document to extract OCR text.";
        }
      }
      refreshIcons();
    }

    async function runAutomaticOcr(file) {
      if (!file) return;

      const currentToken = ++ocrRunToken;
      setOcrButtonState(true);

      try {
        setUploadProgress(
          10,
          `Preparing ${file.name}...`
        );

        const extracted = await extractTextWithServer(file);
        const extractedText = String(
          extracted?.text || ""
        ).trim();
        const serverMetadata = extracted?.metadata || {};

        if (
          currentToken !== ocrRunToken ||
          file !== selectedFile
        ) {
          return;
        }

        if (!extractedText) {
          throw new Error(
            "Document was scanned, but no readable text was detected."
          );
        }

        if (ocrTextInput) {
          ocrTextInput.value = extractedText;
          ocrTextInput.dispatchEvent(
            new Event("input", { bubbles: true })
          );

          if (ocrStatsChip) {
            ocrStatsChip.style.display = "inline-flex";
            ocrStatsChip.textContent =
              `${extractedText.length.toLocaleString()} characters extracted`;
          }
        }

        const detected = autofillCommunicationFields(
          extractedText,
          serverMetadata
        );

        const filled = [
          detected.sourceOffice &&
            `Source: ${detected.sourceOffice}`,
          detected.recipient &&
            `To: ${detected.recipient}`,
          detected.controlNo &&
            `Control No: ${detected.controlNo}`,
          detected.subject &&
            `Subject: ${detected.subject}`,
          detected.date &&
            `Date: ${detected.date}`
        ].filter(Boolean);

        showToast(
          filled.length
            ? `Extracted: ${filled.join(" | ")}`
            : "OCR complete.",
          "success"
        );
      } catch (error) {
        console.error("OCR Error:", error);
        setUploadProgress(
          0,
          "OCR scan failed."
        );
        showToast(
          error.message || "Failed to read document.",
          "error"
        );
      } finally {
        if (currentToken === ocrRunToken) {
          setOcrButtonState(false);
        }
      }
    }

    runOcrBtn?.addEventListener("click", async (e) => {
      e.preventDefault();
      const file = selectedFile || documentFileInput?.files?.[0];
      if (file) await runAutomaticOcr(file);
    });

    /* ---------------- 9. LIVE PREVIEW & FILE ATTACHMENT ---------------- */
    function clearPreviewBlob() {
      if (activePreviewBlobUrl) {
        URL.revokeObjectURL(activePreviewBlobUrl);
        activePreviewBlobUrl = null;
      }
    }

    function renderFilePreview(file, fallbackUrl = "") {
      if (!filePreviewContainer || !filePreviewBody) return;
      clearPreviewBlob();

      if (!file && !fallbackUrl) {
        filePreviewContainer.style.display = "none";
        filePreviewBody.innerHTML = "";
        if (previewOpenExternalBtn) previewOpenExternalBtn.style.display = "none";
        return;
      }

      filePreviewContainer.style.display = "block";
      const filename = file ? file.name : (existingEditFileName || "Document");
      const ext = getFileExtension(filename);

      if (file) {
        activePreviewBlobUrl = URL.createObjectURL(file);
      }
      const activeUrl = activePreviewBlobUrl || fallbackUrl;

      if (previewOpenExternalBtn) {
        if (activeUrl) {
          previewOpenExternalBtn.href = activeUrl;
          previewOpenExternalBtn.style.display = "inline-flex";
        } else {
          previewOpenExternalBtn.style.display = "none";
        }
      }

      if (previewBadge) previewBadge.textContent = ext.toUpperCase() || "ATTACHMENT";

      if (["png", "jpg", "jpeg", "webp", "bmp", "tif", "tiff"].includes(ext)) {
        filePreviewBody.innerHTML = `
          <div class="image-preview-wrapper">
            <img src="${escapeHtml(activeUrl)}" alt="Preview" class="file-preview-image"/>
            <div class="preview-caption">
              <span>${escapeHtml(filename)}</span>
              ${file ? `<span>(${formatFileSize(file.size)})</span>` : ""}
            </div>
          </div>
        `;
        refreshIcons();
        return;
      }

      if (ext === "pdf") {
        filePreviewBody.innerHTML = `
          <div class="pdf-preview-wrapper">
            <iframe src="${escapeHtml(activeUrl)}#toolbar=0" class="file-preview-iframe" title="PDF Viewer"></iframe>
            <div class="preview-caption">
              <span><i data-lucide="file-text"></i> ${escapeHtml(filename)}</span>
              <a href="${escapeHtml(activeUrl)}" target="_blank" rel="noopener noreferrer" class="preview-link">
                Open in new tab <i data-lucide="external-link"></i>
              </a>
            </div>
          </div>
        `;
        refreshIcons();
        return;
      }

      let docIcon = "file-text";
      if (ext === "xlsx" || ext === "csv") docIcon = "file-spreadsheet";
      if (ext === "pptx") docIcon = "presentation";

      filePreviewBody.innerHTML = `
        <div class="document-preview-card">
          <div class="doc-preview-icon"><i data-lucide="${docIcon}"></i></div>
          <div class="doc-preview-info">
            <strong>${escapeHtml(filename)}</strong>
            <p>${ext.toUpperCase()} File • ${file ? formatFileSize(file.size) : "Ready for OCR"}</p>
            <span class="preview-note"><i data-lucide="circle-check"></i> Document verified. Downloadable directly upon saving.</span>
          </div>
        </div>
      `;
      refreshIcons();
    }

    function updateFileUI(file = null, existingName = "") {
      const hasFile = Boolean(file);
      const hasExisting = Boolean(existingName);

      filePickerState?.classList.toggle("has-file", hasFile || hasExisting);

      if (fileNameDisplay) {
        fileNameDisplay.textContent = hasFile ? file.name : (hasExisting ? existingName : "Choose a document file");
      }

      if (fileMetaDisplay) {
        if (hasFile) {
          fileMetaDisplay.textContent = `${getFileExtension(file.name).toUpperCase()} • ${formatFileSize(file.size)} • Ready for OCR`;
        } else if (hasExisting) {
          fileMetaDisplay.textContent = "Current registered document";
        } else {
          fileMetaDisplay.textContent = "PDF, PNG, JPG, JPEG, WEBP, DOCX, TXT • Max 50 MB";
        }
      }

      if (filePickerIcon) {
        const ext = hasFile ? getFileExtension(file.name) : getFileExtension(existingName);
        filePickerIcon.innerHTML = `<i data-lucide="${(hasFile || hasExisting) ? getFileIcon(ext) : "file-up"}"></i>`;
      }

      if (runOcrBtn) {
        runOcrBtn.disabled = !hasFile;
      }

      if (removeDocumentBtn) {
        removeDocumentBtn.style.display = hasFile ? "inline-flex" : "none";
      }

      if (hasFile) {
        renderFilePreview(file);
      } else if (hasExisting && existingEditDriveLink) {
        renderFilePreview(null, existingEditDriveLink);
      } else {
        renderFilePreview(null);
      }

      refreshIcons();
    }

    browseDocumentBtn?.addEventListener("click", (e) => {
      e.preventDefault();
      documentFileInput?.click();
    });

    removeDocumentBtn?.addEventListener("click", (e) => {
      e.preventDefault();
      selectedFile = null;
      if (documentFileInput) documentFileInput.value = "";
      updateFileUI(null, existingEditFileName);
      resetProgress();
      setOcrButtonState(false);
    });

    async function acceptSelectedDocument(file) {
      if (!file) return;
      const validation = validateFile(file);
      if (validation) {
        selectedFile = null;
        if (documentFileInput) documentFileInput.value = "";
        updateFileUI(null, existingEditFileName);
        showToast(validation, "error");
        return;
      }

      selectedFile = file;
      updateFileUI(file);
      resetProgress();
      showToast(`Document selected. Running smart OCR...`, "success");
      await runAutomaticOcr(file);
    }

    documentFileInput?.addEventListener("change", async (event) => {
      await acceptSelectedDocument(event.target.files?.[0] || null);
    });

    // Drag-and-drop support for the visible upload workspace.
    ["dragenter", "dragover"].forEach(eventName => {
      filePickerState?.addEventListener(eventName, (event) => {
        event.preventDefault();
        event.stopPropagation();
        filePickerState.classList.add("is-dragover");
      });
    });
    ["dragleave", "drop"].forEach(eventName => {
      filePickerState?.addEventListener(eventName, (event) => {
        event.preventDefault();
        event.stopPropagation();
        filePickerState.classList.remove("is-dragover");
      });
    });
    filePickerState?.addEventListener("drop", async (event) => {
      const file = event.dataTransfer?.files?.[0] || null;
      if (file) await acceptSelectedDocument(file);
    });

    function setUploadProgress(percent, message) {
      const val = Math.max(0, Math.min(100, Number(percent) || 0));
      if (encodingUploadProgressBox) encodingUploadProgressBox.style.display = "flex";
      if (encodingProgressBar) encodingProgressBar.style.width = `${val}%`;
      if (encodingUploadStatusText) encodingUploadStatusText.textContent = message || "Processing...";
    }

    function resetProgress() {
      if (encodingUploadProgressBox) encodingUploadProgressBox.style.display = "none";
      if (encodingProgressBar) encodingProgressBar.style.width = "0%";
      if (encodingUploadStatusText) encodingUploadStatusText.textContent = "Ready";
    }

    function getFileExtension(filename = "") {
      return filename.includes(".") ? filename.split(".").pop().toLowerCase() : "";
    }

    function formatFileSize(bytes = 0) {
      if (!bytes) return "0 B";
      if (bytes < 1024) return `${bytes} B`;
      if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
      return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
    }

    function validateFile(file) {
      if (!file) return "";
      const ext = getFileExtension(file.name);
      if (!SUPPORTED_DOCUMENT_TYPES.has(ext)) {
        return "Unsupported format. Use PDF, Images (PNG/JPG), Word, Excel, or Text.";
      }
      if (file.size > MAX_FILE_SIZE) return "File exceeds 50 MB limit.";
      return "";
    }

    function getFileIcon(ext) {
      if (ext === "pdf") return "file-text";
      if (["png", "jpg", "jpeg", "webp", "bmp", "tif", "tiff"].includes(ext)) return "file-image";
      if (ext === "docx" || ext === "doc") return "file-text";
      if (ext === "xlsx" || ext === "csv") return "file-spreadsheet";
      if (ext === "pptx") return "presentation";
      return "file";
    }

    /* ---------------- 10. TABLE RENDERING ---------------- */
    function renderRecords() {
      if (!communicationTableBody) return;
      const filtered = getFilteredRecords();
      updateKPIs();
      updateNotifications();

      // Remove stale selections when records were deleted or reloaded.
      const validKeys = new Set(records.map((record, index) => getRecordKey(record, index)));
      [...selectedRecordIds].forEach(key => { if (!validKeys.has(key)) selectedRecordIds.delete(key); });

      if (filtered.length === 0) {
        communicationTableBody.innerHTML = `
          <tr>
            <td colspan="8" class="empty-table-cell">
              ${records.length ? "No records match your filter." : "No communications registered."}
            </td>
          </tr>
        `;
        if (tablePaginationInfo) tablePaginationInfo.textContent = "Showing 0 entries";
        updateSelectionUI(filtered);
        return;
      }

      communicationTableBody.innerHTML = filtered.map(record => {
        const index = records.indexOf(record);
        const recordKey = getRecordKey(record, index);
        const isSelected = selectedRecordIds.has(recordKey);
        let fileMarkup = `<span class="text-muted">No attachment</span>`;

        if (record.fileName) {
          fileMarkup = `
            <div class="file-cell-wrapper">
              <span class="file-name-meta" title="${escapeHtml(record.fileName)}">
                <i data-lucide="${getFileIcon(getFileExtension(record.fileName))}"></i>
                <span>${escapeHtml(record.fileName)}</span>
              </span>
              <div class="file-cell-actions">
                <button type="button" class="btn-file-pill view-pill" data-action="view-doc" data-index="${index}" title="Preview Document">
                  <i data-lucide="eye"></i> View
                </button>
                <button type="button" class="btn-file-pill download-pill" data-action="download-doc" data-index="${index}" title="Download Soft Copy">
                  <i data-lucide="download"></i> Download
                </button>
              </div>
            </div>
          `;
        }

        const type = record.type || "—";
        const documentType = record.documentType || "Document";
        const date = record.date || "—";
        const office = record.office || "—";
        const subject = record.subject || "—";
        const status = record.status || "Pending";

        return `
          <tr data-record-id="${escapeHtml(record.id ?? index)}" class="${isSelected ? "is-selected" : ""}">
            <td>
              <input type="checkbox" class="row-checkbox" value="${index}" data-record-key="${escapeHtml(recordKey)}" aria-label="Select ${escapeHtml(record.controlNo || "communication record")}" ${isSelected ? "checked" : ""}>
            </td>
            <td>
              <strong>${escapeHtml(record.controlNo || "N/A")}</strong>
              <div style="margin-top:4px; font-size:10px; color:#64748b;">
                ${escapeHtml(type)} &bull; ${escapeHtml(documentType)}
              </div>
            </td>
            <td>${escapeHtml(date)}</td>
            <td>${escapeHtml(office)}</td>
            <td style="max-width:260px; white-space:normal;">${escapeHtml(subject)}</td>
            <td>${fileMarkup}</td>
            <td>
              <span class="badge status-badge ${getStatusClass(status)}">
                ${escapeHtml(status)}
              </span>
            </td>
            <td style="text-align:right; white-space:nowrap;">
              <button type="button" class="btn-action" data-action="edit" data-index="${index}" title="Edit Record">
                <i data-lucide="pencil"></i>
              </button>
              <button type="button" class="btn-action" data-action="ocr" data-index="${index}" title="View OCR Text">
                <i data-lucide="file-scan"></i>
              </button>
              <button type="button" class="btn-action delete" data-action="delete" data-index="${index}" title="Delete Record">
                <i data-lucide="trash-2"></i>
              </button>
            </td>
          </tr>
        `;
      }).join("");

      if (tablePaginationInfo) {
        tablePaginationInfo.textContent = `Showing ${filtered.length} of ${records.length} total entries`;
      }
      updateSelectionUI(filtered);
      refreshIcons();
    }

    function getRecordKey(record, index = -1) {
      return String(record?.id || record?.controlNo || `row-${index}`);
    }

    function updateSelectionUI(filtered = getFilteredRecords()) {
      const visibleKeys = filtered.map((record) => getRecordKey(record, records.indexOf(record)));
      const selectedVisible = visibleKeys.filter(key => selectedRecordIds.has(key)).length;

      if (selectAllRows) {
        selectAllRows.checked = visibleKeys.length > 0 && selectedVisible === visibleKeys.length;
        selectAllRows.indeterminate = selectedVisible > 0 && selectedVisible < visibleKeys.length;
        selectAllRows.setAttribute("aria-label", selectedVisible ? `${selectedVisible} visible records selected` : "Select all visible records");
      }

      const totalSelected = selectedRecordIds.size;
      if (bulkSelectionBar) bulkSelectionBar.hidden = totalSelected === 0;
      if (selectedCountText) selectedCountText.textContent = `${totalSelected} record${totalSelected === 1 ? "" : "s"} selected`;
    }

    function clearSelection() {
      selectedRecordIds.clear();
      renderRecords();
    }

    function updateNotifications() {
      if (!notificationList) return;
      const pending = records
        .map((record, index) => ({ record, index }))
        .filter(({ record }) => String(record.status || "").toLowerCase() === "pending")
        .slice(0, 8);

      if (notifBadgeCount) notifBadgeCount.textContent = `${pending.length} Pending`;
      if (notifPing) notifPing.style.display = pending.length ? "block" : "none";

      if (!pending.length) {
        notificationList.innerHTML = `<div class="empty-notif-state">No pending communication actions</div>`;
        return;
      }

      notificationList.innerHTML = pending.map(({ record, index }) => `
        <button type="button" class="communication-notification-item" data-notification-index="${index}">
          <span class="communication-notification-icon"><i data-lucide="clock-3"></i></span>
          <span class="communication-notification-copy">
            <strong>${escapeHtml(record.controlNo || "Pending communication")}</strong>
            <span>${escapeHtml(record.subject || record.documentType || "Requires action")}</span>
            <small>${escapeHtml(record.office || "PGENRO")}</small>
          </span>
        </button>
      `).join("");
      refreshIcons();
    }

    function csvEscape(value) {
      return `"${String(value ?? "").replaceAll('"', '""')}"`;
    }

    function exportFilteredRecords() {
      const filtered = getFilteredRecords();
      if (!filtered.length) {
        showToast("There are no communication records to export.", "warning");
        return;
      }
      const headers = ["Control No.", "Type", "Document Type", "Date", "Office / Recipient", "Subject", "Status", "Action Taken", "Remarks", "File Name"];
      const lines = [headers, ...filtered.map(record => [
        record.controlNo, record.type, record.documentType, record.date, record.office,
        record.subject, record.status, record.actionTaken || record.dateForwarded,
        record.remarks, record.fileName
      ])].map(row => row.map(csvEscape).join(","));
      const blob = new Blob(["\uFEFF" + lines.join("\n")], { type: "text/csv;charset=utf-8" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `pgenro_communications_${new Date().toISOString().slice(0, 10)}.csv`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
      showToast(`Exported ${filtered.length} communication record${filtered.length === 1 ? "" : "s"}.`, "success");
    }

    async function syncCommunications() {
      if (!syncCommunicationsBtn) return;
      const original = syncCommunicationsBtn.innerHTML;
      syncCommunicationsBtn.disabled = true;
      syncCommunicationsBtn.innerHTML = `<i data-lucide="loader-2" class="spin-icon"></i><span>Syncing...</span>`;
      refreshIcons();
      try {
        await loadRecords();
        showToast(cloudRecordsAvailable ? "Communications synced with Supabase." : "Local communication cache refreshed.", cloudRecordsAvailable ? "success" : "warning");
      } catch (error) {
        console.error("Manual sync failed:", error);
        showToast("Could not refresh communications right now.", "error");
      } finally {
        syncCommunicationsBtn.disabled = false;
        syncCommunicationsBtn.innerHTML = original;
        refreshIcons();
      }
    }

    async function archiveSelectedRecords() {
      const keys = new Set(selectedRecordIds);
      if (!keys.size) return;
      const targets = records.filter((record, index) => keys.has(getRecordKey(record, index)));
      if (!targets.length) return clearSelection();

      bulkArchiveBtn && (bulkArchiveBtn.disabled = true);
      try {
        for (const record of targets) {
          const updated = { ...record, status: "Archived" };
          if (supabaseConfigured) await saveRecordToCloud(updated);
          const index = records.indexOf(record);
          if (index >= 0) records[index] = updated;
        }
        saveLocalRecords();
        selectedRecordIds.clear();
        renderRecords();
        showToast(`${targets.length} record${targets.length === 1 ? "" : "s"} archived.`, "success");
      } catch (error) {
        console.error("Bulk archive failed:", error);
        showToast("Bulk archive could not be completed. No additional records were changed.", "error");
        await loadRecords();
      } finally {
        if (bulkArchiveBtn) bulkArchiveBtn.disabled = false;
      }
    }

    async function deleteSelectedRecords() {
      const keys = new Set(selectedRecordIds);
      if (!keys.size) return;
      const targets = records.filter((record, index) => keys.has(getRecordKey(record, index)));
      if (!targets.length) return clearSelection();
      if (!confirm(`Delete ${targets.length} selected communication record${targets.length === 1 ? "" : "s"}? This cannot be undone.`)) return;

      bulkDeleteBtn && (bulkDeleteBtn.disabled = true);
      try {
        for (const record of targets) {
          if (supabaseConfigured && record.id) await deleteRecordFromCloud(record.id);
          if (record.id) await deleteStoredFile(record.id);
          if (record.controlNo) await deleteStoredFile(record.controlNo);
        }
        records = records.filter((record, index) => !keys.has(getRecordKey(record, index)));
        saveLocalRecords();
        selectedRecordIds.clear();
        renderRecords();
        showToast(`${targets.length} record${targets.length === 1 ? "" : "s"} deleted.`, "success");
      } catch (error) {
        console.error("Bulk delete failed:", error);
        showToast("Bulk delete stopped because a cloud operation failed. Records were refreshed.", "error");
        await loadRecords();
      } finally {
        if (bulkDeleteBtn) bulkDeleteBtn.disabled = false;
      }
    }

    function getStatusClass(status) {
      const val = String(status || "").toLowerCase();
      if (val === "received" || val === "released") return "success";
      if (val === "pending") return "amber";
      if (val === "forwarded") return "info";
      return "neutral";
    }

    function getFilteredRecords() {
      const tableSearch = (tableSearchInput?.value || "").trim().toLowerCase();
      const globalSearch = (globalSearchInput?.value || "").trim().toLowerCase();
      const search = tableSearch || globalSearch;

      return records.filter(record => {
        const matchesType = currentTypeFilter === "All" || String(record.type || "").toLowerCase() === currentTypeFilter.toLowerCase();
        const matchesStatus = currentStatusFilter === "All" || String(record.status || "").toLowerCase() === currentStatusFilter.toLowerCase();

        const searchable = [
          record.controlNo, record.type, record.documentType, record.date,
          record.office, record.subject, record.status, record.fileName,
          record.ocrText
        ].filter(Boolean).join(" ").toLowerCase();

        return matchesType && matchesStatus && (!search || searchable.includes(search));
      });
    }

    function updateKPIs() {
      const total = records.length;
      const incoming = records.filter(r => String(r.type || "").toLowerCase() === "incoming").length;
      const outgoing = records.filter(r => String(r.type || "").toLowerCase() === "outgoing").length;
      const pending = records.filter(r => String(r.status || "").toLowerCase() === "pending").length;

      if (kpiTotalRecords) kpiTotalRecords.textContent = total.toLocaleString();
      if (kpiIncomingCount) kpiIncomingCount.textContent = incoming.toLocaleString();
      if (kpiOutgoingCount) kpiOutgoingCount.textContent = outgoing.toLocaleString();
      if (kpiPendingCount) kpiPendingCount.textContent = pending.toLocaleString();
    }

    /* ---------------- 11. DOWNLOAD & VIEWER ---------------- */
    async function downloadRecordFile(index) {
      const record = records[index];
      if (!record || !record.fileName) {
        showToast("No attached document for this record.", "warning");
        return;
      }

      showToast(`Preparing download for ${record.fileName}...`, "info");

      const stored = await getStoredFile(record.id || record.controlNo);
      if (stored && stored.blob) {
        triggerBrowserDownload(stored.blob, record.fileName);
        return;
      }

      if (record.driveLink) {
        const a = document.createElement("a");
        a.href = record.driveLink;
        a.download = record.fileName;
        a.target = "_blank";
        document.body.appendChild(a);
        a.click();
        a.remove();
        showToast(`Download started: ${record.fileName}`, "success");
        return;
      }

      showToast("File data not found in local cache.", "error");
    }

    function triggerBrowserDownload(blob, filename) {
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      setTimeout(() => {
        a.remove();
        URL.revokeObjectURL(url);
      }, 1000);
      showToast(`Downloaded: ${filename}`, "success");
    }

    async function viewDocument(index) {
      const record = records[index];
      if (!record || !record.fileName || !viewDocumentModal) return;

      if (docViewerTitle) docViewerTitle.textContent = record.fileName;
      if (docViewerSubtitle) docViewerSubtitle.textContent = `${record.controlNo || "Doc"} • ${record.documentType || "Communication"}`;

      if (docViewerIframe) docViewerIframe.style.display = "none";
      if (docViewerImage) docViewerImage.style.display = "none";
      if (docViewerFallback) docViewerFallback.style.display = "none";

      let fileBlob = null;
      const stored = await getStoredFile(record.id || record.controlNo);
      if (stored && stored.blob) {
        fileBlob = stored.blob;
      }

      const ext = getFileExtension(record.fileName);
      const fileUrl = fileBlob ? URL.createObjectURL(fileBlob) : (record.driveLink || "");

      if (docViewerDownloadBtn) {
        docViewerDownloadBtn.onclick = (e) => {
          e.preventDefault();
          downloadRecordFile(index);
        };
      }

      if (docViewerExternalBtn) {
        if (fileUrl) {
          docViewerExternalBtn.href = fileUrl;
          docViewerExternalBtn.style.display = "inline-flex";
        } else {
          docViewerExternalBtn.style.display = "none";
        }
      }

      if (ext === "pdf" && fileUrl) {
        docViewerIframe.src = `${fileUrl}#toolbar=1`;
        docViewerIframe.style.display = "block";
      } else if (["png", "jpg", "jpeg", "webp", "bmp", "tif", "tiff"].includes(ext) && fileUrl) {
        docViewerImage.src = fileUrl;
        docViewerImage.style.display = "block";
      } else {
        docViewerFallback.innerHTML = `
          <div style="padding: 30px; text-align: center;">
            <i data-lucide="${getFileIcon(ext)}" style="width: 48px; height: 48px; color: #059669; margin-bottom: 12px;"></i>
            <h3>${escapeHtml(record.fileName)}</h3>
            <p style="color: #94a3b8; font-size: 13px;">Direct preview is not supported for .${ext} files.</p>
            <button type="button" class="btn btn-primary" id="fallbackDownloadBtn" style="margin-top: 15px;">
              <i data-lucide="download"></i> Download File to View
            </button>
          </div>
        `;
        docViewerFallback.style.display = "block";
        $("#fallbackDownloadBtn", docViewerFallback)?.addEventListener("click", () => {
          downloadRecordFile(index);
        });
        refreshIcons();
      }

      viewDocumentModal.classList.add("open");
      viewDocumentModal.setAttribute("aria-hidden", "false");
      document.body.classList.add("admin-modal-open");
      refreshIcons();
    }

    closeDocViewerBtn?.addEventListener("click", () => {
      viewDocumentModal?.classList.remove("open");
      viewDocumentModal?.setAttribute("aria-hidden", "true");
      document.body.classList.remove("admin-modal-open");
      if (docViewerIframe) docViewerIframe.src = "";
      if (docViewerImage) docViewerImage.src = "";
    });

    /* ---------------- 12. SAVE RECORD ---------------- */
    async function saveCommunicationRecord(event) {
      event.preventDefault();
      if (
        !typeSelect?.value ||
        !docTypeSelect?.value ||
        !dateInput?.value ||
        !statusSelect?.value ||
        !officeInput?.value.trim() ||
        !subjectInput?.value.trim()
      ) {
        showToast("Please fill in all required fields (*).", "warning");
        return;
      }

      setSaveButton(true, "Saving record & file...");

      const editIndex = editIndexInput?.value ?? "";
      const editing = editIndex !== "";
      const existing = editing ? records[Number(editIndex)] : null;
      const recordId = existing?.id || (crypto.randomUUID?.() || `communication-${Date.now()}`);

      const recordPayload = {
        id: recordId,
        controlNo: controlNoInput.value || generateControlNumber(typeSelect.value),
        type: typeSelect.value,
        documentType: docTypeSelect.value,
        date: dateInput.value || null,
        status: statusSelect.value || "Pending",
        office: officeInput.value.trim() || null,
        subject: subjectInput.value.trim() || null,
        actionTaken: actionTakenInput?.value.trim() || null,
        dateForwarded: actionTakenInput?.value.trim() || null,
        remarks: remarksInput?.value.trim() || null,
        ocrText: ocrTextInput?.value.trim() || null,
        fileName: selectedFile?.name || existing?.fileName || null,
        fileSize: Number(selectedFile?.size || existing?.fileSize || 0) || null,
        driveLink: existing?.driveLink || null
      };

      const editingRecordIndex = editing ? Number(editIndex) : -1;
      const duplicateControl = records.some((record, index) =>
        index !== editingRecordIndex &&
        String(record.controlNo || "").trim().toLowerCase() === String(recordPayload.controlNo || "").trim().toLowerCase()
      );
      if (recordPayload.controlNo && duplicateControl) {
        setSaveButton(false, editing ? "Update Record" : "Encode & Save Record");
        showToast(`Control number ${recordPayload.controlNo} already exists.`, "warning");
        controlNoInput?.focus();
        return;
      }

      try {
        if (selectedFile) {
          await storeFileLocally(recordId, selectedFile);
          await storeFileLocally(recordPayload.controlNo, selectedFile);
        }

        let cloudSaved = false;
        let cloudSaveError = null;
        try {
          cloudSaved = await saveRecordToCloud(recordPayload);
        } catch (error) {
          cloudSaveError = error;
          console.warn("Cloud save fallback:", error);
        }

        if (editing) {
          records[Number(editIndex)] = { ...existing, ...recordPayload };
        } else {
          records.unshift(recordPayload);
        }

        saveLocalRecords();
        renderRecords();

        if (cloudSaveError) {
          showToast("Saved to this browser, but cloud sync failed. Check the Supabase connection.", "warning");
        } else {
          showToast(
            editing
              ? (cloudSaved ? "Record updated and synced successfully!" : "Record updated locally.")
              : (cloudSaved ? "Communication saved and synced successfully!" : "Communication saved locally."),
            "success"
          );
        }
        closeEncodingModal();
      } catch (err) {
        console.error("Save error:", err);
        showToast(`Save failed: ${err.message}`, "error");
      } finally {
        setSaveButton(false, editing ? "Update Record" : "Encode & Save Record");
      }
    
    }

    communicationForm?.addEventListener("submit", saveCommunicationRecord);

    function setSaveButton(loading, label) {
      if (!saveRecordBtn) return;
      saveRecordBtn.disabled = Boolean(loading);
      saveRecordBtn.innerHTML = loading
        ? `<i data-lucide="loader-2" class="spin-icon"></i><span>${escapeHtml(label)}</span>`
        : `<i data-lucide="upload-cloud"></i><span>${escapeHtml(label)}</span>`;
      refreshIcons();
    }

    /* ---------------- 13. CLOUD + LOCAL CACHE PERSISTENCE ---------------- */
    function loadLocalRecords() {
      try {
        const saved = JSON.parse(localStorage.getItem("communicationRecords") || "[]");
        records = Array.isArray(saved) ? saved : [];
      } catch {
        records = [];
      }
    }

    function saveLocalRecords() {
      try {
        localStorage.setItem("communicationRecords", JSON.stringify(records));
      } catch (e) {
        console.warn("Storage warning:", e);
      }
    }

    function cloudRowToRecord(row) {
      return {
        id: String(row.id),
        ...(row.data || {}),
        createdAt: row.data?.createdAt || row.created_at || null,
        updatedAt: row.data?.updatedAt || row.updated_at || null
      };
    }

    async function loadRecords() {
      loadLocalRecords();
      const cachedRecords = [...records];

      if (supabaseConfigured) {
        try {
          const { data, error } = await supabaseClient
            .from(COMMUNICATIONS_TABLE)
            .select("id,data,created_at,updated_at")
            .order("created_at", { ascending: false });
          if (error) throw error;

          const cloudRecords = (data || []).map(cloudRowToRecord);
          const merged = new Map(cloudRecords.map(record => [String(record.id), record]));
          const cachedOnly = [];

          cachedRecords.forEach(record => {
            const key = String(record.id || record.controlNo || "");
            if (!key) return;
            if (!merged.has(key)) {
              const normalized = { ...record, id: key };
              merged.set(key, normalized);
              cachedOnly.push(normalized);
            }
          });

          records = Array.from(merged.values()).sort((a, b) => {
            const aDate = new Date(a.updatedAt || a.createdAt || a.date || 0).getTime() || 0;
            const bDate = new Date(b.updatedAt || b.createdAt || b.date || 0).getTime() || 0;
            return bDate - aDate;
          });

          cloudRecordsAvailable = true;
          saveLocalRecords();
          renderRecords();

          if (cachedOnly.length) {
            const migrations = await Promise.allSettled(cachedOnly.map(record => saveRecordToCloud(record)));
            const failed = migrations.filter(result => result.status === "rejected").length;
            if (failed) {
              console.warn(`${failed} cached communication record(s) could not be migrated to Supabase.`);
            }
          }
          return;
        } catch (error) {
          cloudRecordsAvailable = false;
          console.warn("Communications cloud sync fallback:", error);
        }
      }

      renderRecords();
    }

    async function saveRecordToCloud(record) {
      if (!supabaseConfigured) return false;
      const payload = { ...record, updatedAt: new Date().toISOString() };
      delete payload.id;
      const { error } = await supabaseClient
        .from(COMMUNICATIONS_TABLE)
        .upsert({
          id: String(record.id),
          data: payload,
          updated_at: new Date().toISOString()
        }, { onConflict: "id" });
      if (error) throw error;
      cloudRecordsAvailable = true;
      return true;
    }

    async function deleteRecordFromCloud(id) {
      if (!supabaseConfigured || !id) return false;
      const { error } = await supabaseClient
        .from(COMMUNICATIONS_TABLE)
        .delete()
        .eq("id", String(id));
      if (error) throw error;
      cloudRecordsAvailable = true;
      return true;
    }

    function generateControlNumber(type) {
      if (!type) return "";
      const year = new Date().getFullYear();
      const prefix = type === "Incoming" ? "INC" : "OUT";
      let highest = 0;

      records.filter(r => r.type === type).forEach(r => {
        const match = String(r.controlNo || "").match(/-(\d+)$/);
        if (match) highest = Math.max(highest, Number(match[1]) || 0);
      });

      return `${prefix}-${year}-${String(highest + 1).padStart(4, "0")}`;
    }

    typeSelect?.addEventListener("change", () => {
      if (editIndexInput?.value === "") {
        controlNoInput.value = generateControlNumber(typeSelect.value);
      }
    });

    /* ---------------- 14. MODAL ACTIONS & DISPATCHER ---------------- */
    function openEncodingModal() {
      encodingModal?.classList.add("open");
      encodingModal?.setAttribute("aria-hidden", "false");
      document.body.classList.add("admin-modal-open");
      refreshIcons();
    }

    function closeEncodingModal() {
      encodingModal?.classList.remove("open");
      encodingModal?.setAttribute("aria-hidden", "true");
      document.body.classList.remove("admin-modal-open");
      resetForm();
    }

    function resetForm() {
      communicationForm?.reset();
      if (editIndexInput) editIndexInput.value = "";
      if (modalTitle) modalTitle.textContent = "Encoding Communication Record";
      if (controlNoInput) controlNoInput.value = "";
      if (dateInput) dateInput.value = new Date().toISOString().slice(0, 10);
      if (documentFileInput) documentFileInput.value = "";
      if (ocrTextInput) ocrTextInput.value = "";
      if (ocrStatsChip) ocrStatsChip.style.display = "none";

      selectedFile = null;
      existingEditFileName = "";
      existingEditDriveLink = "";
      clearPreviewBlob();
      updateFileUI();
      resetProgress();
      setSaveButton(false, "Encode & Save Record");
    }

    openEncodingModalBtn?.addEventListener("click", () => {
      resetForm();
      openEncodingModal();
    });

    closeEncodingModalBtn?.addEventListener("click", closeEncodingModal);
    cancelEncodingBtn?.addEventListener("click", closeEncodingModal);

    encodingModal?.addEventListener("click", (event) => {
      if (event.target === encodingModal) closeEncodingModal();
    });
    viewOcrModal?.addEventListener("click", (event) => {
      if (event.target === viewOcrModal) {
        viewOcrModal.classList.remove("open");
        viewOcrModal.setAttribute("aria-hidden", "true");
        document.body.classList.remove("admin-modal-open");
      }
    });
    viewDocumentModal?.addEventListener("click", (event) => {
      if (event.target === viewDocumentModal) {
        viewDocumentModal.classList.remove("open");
        viewDocumentModal.setAttribute("aria-hidden", "true");
        document.body.classList.remove("admin-modal-open");
        if (docViewerIframe) docViewerIframe.src = "";
        if (docViewerImage) docViewerImage.src = "";
      }
    });

    async function editRecord(index) {
      const record = records[index];
      if (!record) return;

      resetForm();
      editIndexInput.value = String(index);
      typeSelect.value = record.type || "";
      controlNoInput.value = record.controlNo || "";
      docTypeSelect.value = record.documentType || "";
      dateInput.value = record.date || "";
      statusSelect.value = record.status || "";
      officeInput.value = record.office || "";
      subjectInput.value = record.subject || "";
      actionTakenInput.value = record.actionTaken || record.dateForwarded || "";
      remarksInput.value = record.remarks || "";
      ocrTextInput.value = record.ocrText || "";

      existingEditFileName = record.fileName || "";
      existingEditDriveLink = record.driveLink || "";

      const stored = await getStoredFile(record.id || record.controlNo);
      if (stored && stored.blob) {
        try {
          selectedFile = new File(
            [stored.blob],
            stored.name || record.fileName || "document",
            { type: stored.type || stored.blob.type || "application/octet-stream" }
          );
        } catch {
          selectedFile = stored.blob;
          try {
            Object.defineProperty(selectedFile, "name", { value: stored.name || record.fileName || "document" });
          } catch {}
        }
      }

      updateFileUI(selectedFile, existingEditFileName);
      if (modalTitle) modalTitle.textContent = "Edit Communication Record";
      setSaveButton(false, "Update Record");
      openEncodingModal();
    }

    function viewOCR(index) {
      const record = records[index];
      if (!record || !viewOcrModal) return;
      if (viewOcrFileName) viewOcrFileName.textContent = record.fileName ? `File: ${record.fileName}` : "No file";
      if (viewOcrContent) viewOcrContent.value = record.ocrText || "No OCR text extracted.";
      viewOcrModal.classList.add("open");
      viewOcrModal.setAttribute("aria-hidden", "false");
      document.body.classList.add("admin-modal-open");
    }

    closeViewOcrModalBtn?.addEventListener("click", () => {
      viewOcrModal?.classList.remove("open");
      viewOcrModal?.setAttribute("aria-hidden", "true");
      document.body.classList.remove("admin-modal-open");
    });

    async function deleteRecord(index) {
      const record = records[index];
      if (!record) return;
      if (!confirm(`Delete record ${record.controlNo || ""}?`)) return;

      try {
        if (supabaseConfigured && record.id) {
          await deleteRecordFromCloud(record.id);
        }
      } catch (error) {
        console.error("Cloud delete failed:", error);
        showToast("Could not delete the cloud record. Nothing was removed.", "error");
        return;
      }

      if (record.id) await deleteStoredFile(record.id);
      if (record.controlNo) await deleteStoredFile(record.controlNo);

      records.splice(index, 1);
      saveLocalRecords();
      renderRecords();
      showToast("Record and local soft copy deleted.", "success");
    }

    communicationTableBody?.addEventListener("click", (e) => {
      const btn = e.target.closest("[data-action]");
      if (!btn) return;
      const index = Number(btn.dataset.index);
      if (Number.isNaN(index)) return;

      const action = btn.dataset.action;
      if (action === "edit") editRecord(index);
      if (action === "ocr") viewOCR(index);
      if (action === "delete") deleteRecord(index);
      if (action === "view-doc") viewDocument(index);
      if (action === "download-doc") downloadRecordFile(index);
    });

    communicationTableBody?.addEventListener("change", (e) => {
      const checkbox = e.target.closest(".row-checkbox");
      if (!checkbox) return;
      const key = String(checkbox.dataset.recordKey || "");
      if (!key) return;
      if (checkbox.checked) selectedRecordIds.add(key);
      else selectedRecordIds.delete(key);
      checkbox.closest("tr")?.classList.toggle("is-selected", checkbox.checked);
      updateSelectionUI();
    });

    selectAllRows?.addEventListener("change", () => {
      const filtered = getFilteredRecords();
      filtered.forEach(record => {
        const key = getRecordKey(record, records.indexOf(record));
        if (selectAllRows.checked) selectedRecordIds.add(key);
        else selectedRecordIds.delete(key);
      });
      renderRecords();
    });

    clearSelectionBtn?.addEventListener("click", clearSelection);
    bulkArchiveBtn?.addEventListener("click", archiveSelectedRecords);
    bulkDeleteBtn?.addEventListener("click", deleteSelectedRecords);
    exportCommunicationsBtn?.addEventListener("click", exportFilteredRecords);
    syncCommunicationsBtn?.addEventListener("click", syncCommunications);

    notificationList?.addEventListener("click", (event) => {
      const item = event.target.closest("[data-notification-index]");
      if (!item) return;
      const index = Number(item.dataset.notificationIndex);
      if (!Number.isFinite(index)) return;
      notificationDropdown?.classList.remove("open");
      if (notificationDropdown) notificationDropdown.style.display = "none";
      editRecord(index);
    });

    /* ---------------- 15. FILTERS & SEARCH ---------------- */
    filterTabs.forEach(tab => {
      tab.addEventListener("click", () => {
        filterTabs.forEach(t => t.classList.remove("active"));
        tab.classList.add("active");
        currentTypeFilter = tab.dataset.type || "All";
        renderRecords();
      });
    });

    statusFilter?.addEventListener("change", (e) => {
      currentStatusFilter = e.target.value || "All";
      renderRecords();
    });

    tableSearchInput?.addEventListener("input", renderRecords);
    globalSearchInput?.addEventListener("input", renderRecords);

    function showToast(message, type = "success") {
      let stack = $(".admin-ui-toast-stack");
      if (!stack) {
        stack = document.createElement("div");
        stack.className = "admin-ui-toast-stack";
        document.body.appendChild(stack);
      }
      const toast = document.createElement("div");
      toast.className = "admin-ui-toast";
      toast.dataset.type = type;
      const icon = type === "error" ? "alert-circle" : (type === "warning" ? "alert-triangle" : "circle-check");
      toast.innerHTML = `<i data-lucide="${icon}"></i><span>${escapeHtml(message)}</span>`;
      stack.appendChild(toast);
      refreshIcons();
      setTimeout(() => {
        toast.style.opacity = "0";
        setTimeout(() => toast.remove(), 250);
      }, 3500);
    }

    /* ---------------- 16. INITIALIZATION ---------------- */
    resetForm();
    await loadRecords();
    refreshIcons();

    if (supabaseConfigured) {
      try {
        supabaseClient
          .channel("admin:communications")
          .on("postgres_changes", { event: "*", schema: "public", table: COMMUNICATIONS_TABLE }, () => loadRecords())
          .subscribe();
      } catch (error) {
        console.warn("Communications realtime notice:", error);
      }
    }

    const serverOk = await checkOcrServer();
    if (dbStatusDot) {
      dbStatusDot.classList.toggle("online", cloudRecordsAvailable);
      dbStatusDot.classList.toggle("offline", !cloudRecordsAvailable);
    }
    if (dbStatusText) {
      const databaseState = cloudRecordsAvailable ? "Supabase Live" : "Local Cache";
      const ocrState = serverOk ? "OCR Online" : "OCR Offline";
      dbStatusText.textContent = `${databaseState} · ${ocrState}`;
    }
  }
})();